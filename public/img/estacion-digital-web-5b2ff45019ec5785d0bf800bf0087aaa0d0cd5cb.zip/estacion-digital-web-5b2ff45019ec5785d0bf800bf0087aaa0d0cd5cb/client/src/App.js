import React, { useState, useEffect, useRef } from 'react';
import classNames from 'classnames';
import { Route, useLocation } from 'react-router-dom';
import { CSSTransition } from 'react-transition-group';
import { addLocale } from 'primereact/api';
import { AppTopbar } from './AppTopbar';
import { AppFooter } from './AppFooter';
import { AppMenu } from './AppMenu';
import { AppConfig } from './AppConfig';
import { Tooltip } from 'primereact/tooltip';
import PrimeReact from 'primereact/api';
import './App.scss';

import axios from 'axios';
//random script please work damm it
import VideoList from './pages/VideoList';
import EditorMedia from './pages/EditorMedia';
import EmptyPage from './pages/EmptyPage';
import ProgramationPage from './pages/ProgramationPage';
import EditionPage from './pages/EditionPage';
import ExcelModule from './pages/ExcelModule';
import MonitorModule from './pages/MonitorModule';
import TxtGenerator from "./pages/TxtGeneratorModule";
import ArchivosCargaS3 from "./pages/ArchivosCargaS3";
import cuePointsEditor from './pages/ListAsignarCP';
import JsonGenerator from "./pages/JsonGeneratorModule";
import Carta from "./cartas/Carta";
import DataUno from "./cartas/TableUno";
import DataSiete from "./cartas/TableSiete";
import DataAmas from "./cartas/TableAmas";
import DataAdn40 from "./cartas/TableAdn40";

import 'primereact/resources/primereact.css';
import 'primeicons/primeicons.css';
import 'primeflex/primeflex.css';
import 'primereact/resources/themes/lara-light-blue/theme.css'

import './assets/layout/layout.scss';
//import dotenv from "dotenv"

//dotenv.config()

const App = () => {



  const [layoutMode, setLayoutMode] = useState('static');
  const [layoutColorMode, setLayoutColorMode] = useState('light')
  const [inputStyle, setInputStyle] = useState('outlined');
  const [ripple, setRipple] = useState(true);
  const [staticMenuInactive, setStaticMenuInactive] = useState(false);
  const [overlayMenuActive, setOverlayMenuActive] = useState(false);
  const [mobileMenuActive, setMobileMenuActive] = useState(false);
  const [mobileTopbarMenuActive, setMobileTopbarMenuActive] = useState(false);
  const copyTooltipRef = useRef();
  const location = useLocation();
  console.log(process)
  addLocale('es', {
    firstDayOfWeek: 1,
    dayNames: ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'],
    dayNamesShort: ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'],
    dayNamesMin: ['D', 'L', 'M', 'X', 'J', 'V', 'S'],
    monthNames: ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'],
    monthNamesShort: ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'],
    today: 'Hoy',
    clear: 'Limpiar',
    //...
  });

  //Comentario prueba
  //comienza codigo de OKTA
  //Variable donde se obtiene el username de okta
  const [user, setUser] = useState()
  const [loading, setLoading] = useState(true)
  //   const [user, setUser] = useState('')
  //   const [loading, setLoading] = useState(true)

  const RedirectToLogin = () => {
    window.location.replace('/login');
  }


  useEffect(() => {
      if(process.env.NODE_ENV==='production'){

    const estacion = ('; ' + document.cookie).split(`; estacion=`).pop().split(';')[0];
    if (estacion === undefined || estacion === "") {
      axios({
        method: 'GET',
        url: '/whoami',
        withCredentials: true,
      })
        .then(response => {
          console.log(response)
          if (response.data.user.nameID) {
            console.log(user)
            setUser(response.data.user.Nombre)

          }
          else {
            RedirectToLogin();
          }
        }).catch(error => {
          RedirectToLogin();
        })
    }
    else {
      const nombre = ('; ' + document.cookie).split(`; nombre=`).pop().split(';')[0];
      setUser(nombre)
      setLoading(false)
      console.log("cargar datos desde cookie")
    }


      }
    }, []);
  //termina codigo de OKTA

  PrimeReact.ripple = true;

  let menuClick = false;
  let mobileTopbarMenuClick = false;

  useEffect(() => {
    if (mobileMenuActive) {
      addClass(document.body, "body-overflow-hidden");
    } else {
      removeClass(document.body, "body-overflow-hidden");
    }
  }, [mobileMenuActive]);

  useEffect(() => {
    copyTooltipRef && copyTooltipRef.current && copyTooltipRef.current.updateTargetEvents();
  }, [location]);

  const onInputStyleChange = (inputStyle) => {
    setInputStyle(inputStyle);
  }

  const onRipple = (e) => {
    PrimeReact.ripple = e.value;
    setRipple(e.value)
  }

  const onLayoutModeChange = (mode) => {
    setLayoutMode(mode)
  }

  const onColorModeChange = (mode) => {
    setLayoutColorMode(mode)
  }

  const onWrapperClick = (event) => {
    if (!menuClick) {
      setOverlayMenuActive(false);
      setMobileMenuActive(false);
    }

    if (!mobileTopbarMenuClick) {
      setMobileTopbarMenuActive(false);
    }

    mobileTopbarMenuClick = false;
    menuClick = false;
  }

  const onToggleMenuClick = (event) => {
    menuClick = true;

    if (isDesktop()) {
      if (layoutMode === 'overlay') {
        if (mobileMenuActive === true) {
          setOverlayMenuActive(true);
        }

        setOverlayMenuActive((prevState) => !prevState);
        setMobileMenuActive(false);
      }
      else if (layoutMode === 'static') {
        setStaticMenuInactive((prevState) => !prevState);
      }
    }
    else {
      setMobileMenuActive((prevState) => !prevState);
    }

    event.preventDefault();
  }

  const onSidebarClick = () => {
    menuClick = true;
  }

  const onMobileTopbarMenuClick = (event) => {
    mobileTopbarMenuClick = true;

    setMobileTopbarMenuActive((prevState) => !prevState);
    event.preventDefault();
  }

  const onMobileSubTopbarMenuClick = (event) => {
    mobileTopbarMenuClick = true;

    event.preventDefault();
  }

  const onMenuItemClick = (event) => {
    if (!event.item.items) {
      setOverlayMenuActive(false);
      setMobileMenuActive(false);
    }
  }
  const isDesktop = () => {
    return window.innerWidth >= 992;
  }

  const menu = [
    {
      label: 'Video On Demand',
      icon: 'pi pi-fw pi-clone',
      items: [
        { label: 'Captura Metadata', icon: 'pi pi-pencil', to: '/VideoList' },
        { label: 'Generar TXT', icon: 'pi pi-bars', to: '/TxtGenerator' },
        { label: 'Captura de Media Order', icon: 'pi pi-copy', to: '/ExcelModule' },
        { label: 'Cargar Archivos S3', icon: 'pi pi-cloud-upload', to: '/ArchivosCargaS3' }
      ]
    },
    {
      label: 'Live', icon: 'pi pi-fw pi-clone',
      items: [
        { label: 'Programación', icon: 'pi pi-fw pi-circle-off', to: '/programming' },
        { label: 'Ordenes de Bloqueo', icon: 'pi pi-fw pi-circle-off', to: '/edition-page' }
      ]
    },
    {
      label: "Digital",
      items: [
        {
          label: "Cartas de Programación",
          icon: "pi pi-fw pi-bookmark",
          items: [
            { label: "Todas", icon: "pi pi-fw pi-bars", to: "/carta/canales" },
            { label: "Uno", icon: "pi pi-fw pi-bars", to: "/carta/uno/" },
            { label: "Siete", icon: "pi pi-fw pi-bars", to: "/carta/siete/" },
            { label: "Amas", icon: "pi pi-fw pi-bars", to: "/carta/amas/" },
            { label: "Adn40", icon: "pi pi-fw pi-bars", to: "/carta/adn40/" },
          ],
        }
      ]
    },
    {
      label: 'EDITORES', icon: 'pi pi-fw pi-clone',
      items: [
        { label: 'Editor de Metadata/ CuePoints', icon: 'pi pi-desktop', to: '/EditorMedia' }
      ]
    },
    {
      label: 'ADMINISTRACIÓN', icon: 'pi pi-wrench',
      items: [
        { label: 'Monitor de Carga', icon: 'pi pi-sort-alt', to: '/MonitorModule' },
      ]
    },
  ];

  const addClass = (element, className) => {
    if (element.classList)
      element.classList.add(className);
    else
      element.className += ' ' + className;
  }

  const removeClass = (element, className) => {
    if (element.classList)
      element.classList.remove(className);
    else
      element.className = element.className.replace(new RegExp('(^|\\b)' + className.split(' ').join('|') + '(\\b|$)', 'gi'), ' ');
  }

  const wrapperClass = classNames('layout-wrapper', {
    'layout-overlay': layoutMode === 'overlay',
    'layout-static': layoutMode === 'static',
    'layout-static-sidebar-inactive': staticMenuInactive && layoutMode === 'static',
    'layout-overlay-sidebar-active': overlayMenuActive && layoutMode === 'overlay',
    'layout-mobile-sidebar-active': mobileMenuActive,
    'p-input-filled': inputStyle === 'filled',
    'p-ripple-disabled': ripple === false,
    'layout-theme-light': layoutColorMode === 'light'
  });
  //if(!loading){

  return (

    <div className={wrapperClass} onClick={onWrapperClick}>
      <Tooltip ref={copyTooltipRef} target=".block-action-copy" position="bottom" content="Copied to clipboard" event="focus" />
      <AppTopbar userName={user} onToggleMenuClick={onToggleMenuClick} layoutColorMode={layoutColorMode}
        mobileTopbarMenuActive={mobileTopbarMenuActive} onMobileTopbarMenuClick={onMobileTopbarMenuClick} onMobileSubTopbarMenuClick={onMobileSubTopbarMenuClick} />
      <div className="layout-sidebar" onClick={onSidebarClick}>
        <AppMenu model={menu} onMenuItemClick={onMenuItemClick} layoutColorMode={layoutColorMode} />
      </div>

      <div className="layout-main-container">
        <div className="layout-main">

          <Route path="/ExcelModule" component={ExcelModule} />
          <Route path="/VideoList" component={VideoList} />
          <Route path="/TxtGenerator" component={TxtGenerator} />
          <Route path="/JsonGenerator" component={JsonGenerator} />
          <Route path="/MonitorModule" component={MonitorModule} />
          <Route path="/EmptyPage" component={EmptyPage} />
          <Route path="/programming" component={ProgramationPage} />
          <Route path="/ArchivosCargaS3" component={ArchivosCargaS3} />
          <Route path="/ListAsignarCP" component={cuePointsEditor} />
          <Route path="/EditorMedia" component={EditorMedia} />
          <Route path="/edition-page" component={EditionPage} />
          <Route path="/carta/canales" exact render={() => <Carta />} />
          <Route path="/carta/uno" exact render={() => <DataUno />} />
          <Route path="/carta/siete" exact render={() => <DataSiete />} />
          <Route path="/carta/amas" exact render={() => <DataAmas />} />
          <Route path="/carta/adn40" exact render={() => <DataAdn40 />} />

        </div>
        <AppFooter layoutColorMode={layoutColorMode} />
      </div>
      <AppConfig rippleEffect={ripple} onRippleEffect={onRipple} inputStyle={inputStyle} onInputStyleChange={onInputStyleChange}
        layoutMode={layoutMode} onLayoutModeChange={onLayoutModeChange} layoutColorMode={layoutColorMode} onColorModeChange={onColorModeChange} />
      <CSSTransition classNames="layout-mask" timeout={{ enter: 200, exit: 200 }} in={mobileMenuActive} unmountOnExit>
        <div className="layout-mask p-component-overlay"></div>
      </CSSTransition>
    </div>
  );
// }else{
//   return(
//     <h2>
//       Cargando...

//     </h2>
//   )
// }

}

export default App;
