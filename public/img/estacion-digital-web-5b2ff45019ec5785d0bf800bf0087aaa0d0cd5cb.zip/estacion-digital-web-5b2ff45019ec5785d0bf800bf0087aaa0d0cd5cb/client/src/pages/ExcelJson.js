import React, { useState, useEffect } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';

import { FileUpload } from 'primereact/fileupload';

import readXlsxFile from 'read-excel-file'
const ExcelToJson = () => {
    const [order, setOrder] = useState([])
    const [dynamicColumns, setDynamicColumns] = useState()
    const [selectedFile, setSelectedFile] = useState(null)

    useEffect(() => {

        let index = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]
        if (selectedFile != null) {
            let data = []
            readXlsxFile(selectedFile).then(function (rows) {

                let header_index = 0
                let rows_length = rows.length
                for (var i = 0; i < rows.length; i++) {
                    // eslint-disable-next-line eqeqeq
                    if (rows[i][0] == "Partner Due Date to Lab") {
                        header_index = i;
                        break
                    }
                }
                let data_first_row = header_index + 1;
                let data_last_row = rows_length - 1
                for (let i = data_first_row; i <= data_last_row; i++) {
                    var aux = {};
                    for (let j = 0; j < index.length; j++) {

                        aux[rows[header_index][index[j]] ] = rows[i][index[j]]
                    }
                    data.push(aux)
                }

                setOrder(data)
                setDynamicColumns(index.map((col) => {

                    return <Column className='p-10' key={rows[header_index][col]} field={rows[header_index][col]} header={rows[header_index][col]} />;
                }))
                order.map((x)=>{
                    console.log(x[0])
                })

            })
        }

        console.log(selectedFile)
        console.log(order)
    }, [selectedFile]); // eslint-disable-line react-hooks/exhaustive-deps


    function changeHandler(event) {
        setSelectedFile(event.files[0])
    }
    return (
        <div>
            <div>
                <div className="card">
                    <div>
                        <FileUpload  name="file" url="./upload" chooseLabel="Seleccionar" uploadLabel="Cargar" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" mode="basic" onSelect={changeHandler} />
                    </div>  
                    <div>
                        <DataTable  value={order} responsiveLayout="scroll" >
                            {dynamicColumns}
                        </DataTable>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default ExcelToJson