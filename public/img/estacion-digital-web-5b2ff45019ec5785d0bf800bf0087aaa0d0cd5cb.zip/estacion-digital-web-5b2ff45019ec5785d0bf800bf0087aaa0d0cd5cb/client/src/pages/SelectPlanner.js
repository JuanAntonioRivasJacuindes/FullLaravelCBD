import React, { useState } from "react";
import Layout from '../components/Layout';
import SelectionPlanner from "../components/selectionScreen/selectionPlanner";

const SelectPlanner = () => {
  const [channel, setChannel] = useState("");
  const [day, setDay] = useState("");
  // eliminar posición de scroll guardada
  localStorage.removeItem('scrollPosition');
  return (
    <Layout>
      <SelectionPlanner channel={channel} setChannel={setChannel} day={day} setDay={setDay} />
    </Layout>
  );
};

export default SelectPlanner;
