import React from 'react';

import Layout from '../components/Layout';
import Confirm from '../components/schedule/confirmOrder';

const Confirmation = () => {
  return (
    <Layout>
      <Confirm />
    </Layout>
  );
};

export default Confirmation;
