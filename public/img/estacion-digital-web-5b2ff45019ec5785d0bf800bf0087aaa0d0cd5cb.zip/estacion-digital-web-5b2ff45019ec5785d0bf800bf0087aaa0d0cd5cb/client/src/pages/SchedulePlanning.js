import React, { useState, useEffect, useMemo } from 'react';
import Layout from '../components/Layout';
import Planning from '../components/schedule/planning';
import MediaSelect from '../components/media/mediaSelect';
import MediaConfirm from '../components/media/mediaConfirm';
import styles from './styles.module.scss';

import { getCarta, getCatalog } from '../service/EstacionDigitalServices';

const SchedulePlanning = () => {
  const { localStorage } = window;
  const [selected, setSelected] = useState('');
  const [toConfirm, setToConfirm] = useState([]);
  const [programs, setPrograms] = useState('');
  const [catalog, setCatalog] = useState('');
  const channelID = localStorage.getItem('channelID');
  const channelName = localStorage.getItem('channelName');
  const date = localStorage.getItem('selectedDate');
  // obtener carta de programación con los valores obtenidos en la selección de canal y fecha
  useEffect(() => {
    async function getData() {
      setPrograms(await getCarta(channelID, date));
    }
    getData();
  }, [channelID, date]);
  // obtener y memorizar catálogo de programas disponibles
  useMemo(() => {
    async function getData() {
      setCatalog(await getCatalog());
    }
    getData();
  }, []);
  return (
    <Layout>
      <div className={styles.container}>
        <Planning data={programs?.programming} channel={channelName} date={date} day={programs?.dia} selected={selected} setSelected={setSelected} toConfirm={toConfirm} setToConfirm={setToConfirm} />
        {selected !== '' && <MediaSelect catalog={catalog} />}
        {toConfirm.length > 0 && <MediaConfirm toConfirm={toConfirm} />}
      </div>
    </Layout>
  );
}

export default SchedulePlanning;
