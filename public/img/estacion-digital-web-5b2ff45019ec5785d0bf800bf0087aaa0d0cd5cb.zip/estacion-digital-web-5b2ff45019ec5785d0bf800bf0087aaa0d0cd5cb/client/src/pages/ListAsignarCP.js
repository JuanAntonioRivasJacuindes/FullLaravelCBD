import React, { useState, useEffect, useRef } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { VideoService } from '../service/VideoService';
import { Toast } from 'primereact/toast';
import { Fieldset } from 'primereact/fieldset';
import PlayFront from '../components/Player';
import {FormatService} from '../components/format';
import ReactPlayer from "react-player";

const AsignarCP = () => {
        let emptyVideo = {
            id_video: '',
            nombre: '',
            nombre_archivo: '',
            duration: ''
        };
       
        const [videos, setVideos] = useState(null);
        const [playerDialog, setPlayerDialog] = useState(false);
        const [video, setVideo] = useState(emptyVideo);
        const [selectedVideos, setSelectedVideos] = useState(null);
        const [globalFilter, setGlobalFilter] = useState(null);
        const toast = useRef(null);
        const [cuePoints, setCuePoints]=useState([]);
        //Servicios de conexion al API REST
        const formatService = new FormatService();
        
        useEffect(() => {
            const videoService = new VideoService();
            videoService.getBibliotecaMedia().then(response => {
                const datav = response.data;
                //console.log(datav);
                setVideos(datav)});
                setCuePoints(video.cue_points);
        }, []);
    
        const hidePlayer = () =>{
            setPlayerDialog(false);
        }

        const Player = (video) =>{
            setCuePoints(video.cue_points);
            setVideo({ ...video});
            setPlayerDialog(true);
        }
        
        const onError = (event) => {
            console.log(event.xhr);
            toast.current.show({severity: 'error', summary: 'Error!', detail: 'Ha ocurrido un error, intentalo mas tarde.', life: 5000});
        }  

        const thumbBodyTemplate=(rowData)=>{
            if (rowData['nombre_archivo']){
                return(
                    <div className='w-10% p-0 m-0'>
                        {/* <Image  width="80" height="60"  src={rowData['thumbnails'][0]['url']} alt="Image Text" /> */}
                        {//<video className='p-0 m-0' width={200} controls={true} src={"https://video1.socio.gs/EstacionDigital/_definist_/proxy/mp4:"+rowData.nombre_archivo+"/playlist.m3u8"}></video>
                        }
                        <ReactPlayer
                            onMouseOver={(e)=>{try{ e.target.play()} catch{console.log("No se puede")} }}
                            onMouseOut={(e)=>{try{ e.target.pause()} catch{console.log("No se puede")} }}
                            url={"https://video1.socio.gs/EstacionDigital/_definist_/proxy/mp4:"+rowData.nombre_archivo+"/playlist.m3u8"}
                            width="200px"
                            height="120px"
                            controls={true}
                            playing ={false}/>
                    </div>
               )
                
            }
            else {
                return(
                    <div className='w-10% p-0 m-0'>
                        {/* <Image  width="80" height="60"  src={rowData['thumbnails'][0]['url']} alt="Image Text" /> */}
                        <p>No preview</p>
                        {/* <Image  width="80" height="60"  src={rowData['thumbnails'][0]['url']} alt="Image Text" /> */}
                    </div>
               )
            }        
        }
       
        const idVideoBodyTemplate = (rowData) => {
            return (
                <>
                    <span className="p-column-title">Id Video</span>
                    {rowData.id_video}
                </>
            );
        }
    
        const nombreBodyTemplate = (rowData) => {
            return (
                <>
                    <span className="p-column-title">Nombre</span>
                    {rowData.nombre}
                </>
            );
        }
    
        const nombreArchivoBodyTemplate = (rowData) => {
            return (
                <>
                    <span className="p-column-title">Nombre Archivo</span>
                    {rowData.nombre_archivo}
                </>
            );
        }
    
        const duracionBodyTemplate = (rowData) => {
            return (
                <>
                    <span className="p-column-title">Duración</span>
                    {formatService.formatTimeMediaStream(rowData.duration)}
                </>
            );
        }
    
        const actionBodyTemplate = (rowData) => {
            return (
                    <div className="actions">
                        <Button icon="pi pi-play" className="p-button-rounded p-button-info mr-2" onClick={() => Player(rowData)} />
                    </div>               
                
            );
        }

        const header = (
            <div className="flex flex-column md:flex-row md:justify-content-between md:align-items-center">
                <h5 className="m-0">Videos Disponibles</h5>
                <span className="block mt-2 md:mt-0 p-input-icon-left">
                    <i className="pi pi-search" />
                    <InputText type="search" onInput={(e) => setGlobalFilter(e.target.value)} placeholder="Buscar..." />
                </span>
            </div>
        );

        const passData = (array) =>{
            console.log("PARENT: "+array)
        }

    return (
        <div className="grid crud-demo" >
            <div className="col-12">
                <div className="card">
                    <Toast ref={toast} />
                    <DataTable  value={videos} selection={selectedVideos} onSelectionChange={(e) => setSelectedVideos(e.value)}
                        dataKey="id" paginator rows={10} rowsPerPageOptions={[5, 10, 25]} className="datatable-responsive"
                        paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
                        currentPageReportTemplate="Mostrando videos del {first} al {last} de un total de {totalRecords} videos"
                        globalFilter={globalFilter} emptyMessage="No se encontraron videos." header={header} responsiveLayout="scroll">
                        <Column field="previwe" header="Preview" sortable body={thumbBodyTemplate} headerStyle={{ width: '12%', minWidth: '10rem' }}></Column>
                        <Column field="id_video" header="Id Video" sortable body={idVideoBodyTemplate} headerStyle={{ width: '12%', minWidth: '10rem' }}></Column>
                        <Column field="nombre" header="Nombre Video" sortable body={nombreBodyTemplate} headerStyle={{ width: '12%', minWidth: '10rem' }}></Column>
                        <Column field="nombre_archivo" header="Nombre Archivo" body={nombreArchivoBodyTemplate} sortable headerStyle={{ width: '14%', minWidth: '8rem' }}></Column>
                        <Column field="duracion" header="Duración" sortable body={duracionBodyTemplate} headerStyle={{ width: '10%', minWidth: '9rem' }}></Column>
                        <Column body={actionBodyTemplate}></Column>
                    </DataTable>

                    
                    <Dialog visible={playerDialog} style={{ width:'1200px', height: '1500px' }} modal className="p-fluid" onHide={hidePlayer}>
                        <Fieldset legend="Mediainfo" style={{backgroundColor:'#EEEEEE'}}>
                            <div className="field">
                                <b><strong>Id Video: </strong></b>  <label>{video.id_video}</label><br/>
                                <b><strong>Nombre del Video: </strong></b>  <label>{video.nombre}</label><br/>
                                <b><strong>Nombre del archivo: </strong></b>  <label>{video.nombre_archivo}</label><br/>
                                <b><strong>Duración: </strong></b>  <label>{video.duration} segundos.</label>                              
                            </div>
                        </Fieldset><br/>
                            <div className="formgrid grid">
                                <div className="field col">
                                    {cuePoints}
                                    <PlayFront actualiza={true} passData={passData} tipo={true} cuePoints={cuePoints} nombre_archivo={video.nombre_archivo} id_video={video.id_video}></PlayFront>                         
                                </div><br/>                           
                            </div>
                    </Dialog>
                    
                </div>
            </div>
        </div>
    );
}

const comparisonFn = function (prevProps, nextProps) {
    return prevProps.location.pathname === nextProps.location.pathname;
};

export default React.memo(AsignarCP, comparisonFn);
