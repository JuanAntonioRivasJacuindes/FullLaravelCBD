import React from 'react';
import TxtGenerator from "../components/TxtGenerator";

const TxtModule = () => {


    return(
        <TxtGenerator></TxtGenerator>
    );


}

export default React.memo(TxtModule);