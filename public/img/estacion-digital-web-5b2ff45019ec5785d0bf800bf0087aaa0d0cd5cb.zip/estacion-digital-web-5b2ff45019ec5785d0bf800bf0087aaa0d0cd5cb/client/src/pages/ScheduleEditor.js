import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import Monitoring from '../components/schedule/monitoring';
import MediaMonitor from '../components/media/mediaMonitor';
import styles from './styles.module.scss';

import { getAllOrders, getOrdersByStatus } from '../service/EstacionDigitalServices';

const ScheduleEditor = () => {
  const { localStorage } = window;
  const [selected, setSelected] = useState('');
  const [list, setList] = useState([]);
  // obtener valores de localStorage
  const channelID = localStorage.getItem('channelID');
  const channelName = localStorage.getItem('channelName');
  const date = localStorage.getItem('selectedDate');
  const orderType = localStorage.getItem('orderType');
  // llamada para obtener la lista de bloqueos
  useEffect(() => {
    async function getData() {
      if (orderType === 'all') {
        // obtener todos los bloqueos
        setList(await getAllOrders(channelID));
      } else {
        // obtener bloqueos por status
        setList(await getOrdersByStatus(channelID, orderType));
      }
    }
    getData();
  }, [orderType, channelID]);
  return (
    <Layout>
      <div className={styles.container}>
        <Monitoring data={list} channel={channelName} date={date} selected={selected} setSelected={setSelected} isEditor={true} />
        {selected !== '' && <MediaMonitor />}
      </div>
    </Layout>
  );
}

export default ScheduleEditor;
