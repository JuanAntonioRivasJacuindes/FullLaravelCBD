import React, { useState, useEffect, useRef } from 'react';

import { Dropdown } from 'primereact/dropdown';
import { Card } from 'primereact/card';
import { Divider } from 'primereact/divider';
import StatusGuide from '../components/schedule/statusGuide';

import { ConfirmDialog } from 'primereact/confirmdialog';
import { Toast } from 'primereact/toast';

import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import MediaLibrary from '../components/media/mediaLibrary';


import { getCanales, getCarta, createOrder, getCatalog } from '../service/EstacionDigitalServices';

import { Calendar } from 'primereact/calendar';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';

const EmptyPage = () => {

  const [selectedPrograms, setSelectedPrograms] = useState([])
  const [editDialog, setEditDialog] = useState(false)
  const [date, setDate] = useState(new Date());
  const [formatDate, setFormatDate] = useState(date.getDate() + "/" + date.getMonth() + 1 + "/" + date.getFullYear());

  const [selectedEditProgram, setSelectedEditProgram] = useState()
  const [canales, setCanales] = useState([])
  const [selectedChannel, setSelectedChannel] = useState()
  const [confirmButtonDisable, setConfirmButtonDisable] = useState(true)
  const [confirmLabel, setConfirmLabel] = useState("Confirmar")
  const [confirmDialog, setConfirmDialog] = useState(false)
  const [tableLoading, setTableLoading] = useState(false)
  const [catalog, setCatalog] = useState([])


  const [carta, setCarta] = useState([])

  const toast = useRef(null);
  useEffect(() => {
    setFormatDate(date.getDate() + "/" + date.getMonth() + 1 + "/" + date.getFullYear())

  }, [date]);


  useEffect(() => {
    getCanales()
      .then((res) => {
        setCanales(res)
      })
      .catch((err) => console.log(err))
    getCatalog()
      .then((res) => {
        setCatalog(res);
      })
      .catch((err) => console.log(err))
  }, []);


  const rowClass = (data) => {
    return {
      'bg-blue-100 text-blue-800': data.confirmado,
    }
  }
  const programBodyTemplate = (rowData) => {

    if (rowData.prg_id === rowData.prg_id_sustituto) {
      return <strong>{rowData.programa}</strong>
    } else {
      return (
        <div>

          <strong>{rowData.programa_sustituto}</strong>-<strike>{rowData.programa}</strike>
        </div>
      )
    }
  }
  useEffect(() => {
    if (selectedEditProgram) {

      console.log(selectedEditProgram)
      setEditDialog(true)
    }

  }, [selectedEditProgram]);

  const editBodyTemplate = (rowData) => {

    return <Button icon="pi pi-pencil" onClick={() => setSelectedEditProgram(rowData)} ></Button>
  }

  const handleConfirmProgram = () => {
    selectedPrograms.map((item) => {

      createOrder(item.id_carta, item.prg_id_sustituto, '', false);
    })

    reloadTable()

  }

  useEffect(() => {

    setTableLoading(true)
    setSelectedPrograms([])
    setConfirmLabel("Confirmar")
    setConfirmButtonDisable(true)
    if (selectedChannel) {

      getCarta(selectedChannel.id, formatDate)
        .then((res) => {
          setCarta(res)
        })
        .catch((err) => console.log(err))
    }
  }, [selectedChannel, formatDate]);

  const reloadTable = () => {
    setTableLoading(true)
    setTimeout(function () {
      if (selectedChannel) {
        getCarta(selectedChannel.id, formatDate)
          .then((res) => {
            setCarta(res)
            toast.current.show({ severity: 'success', summary: 'Hecho', detail: 'Se ha confirmado exitosamente', life: 3000 });

          })
          .catch((err) => console.log(err))
      }
    }, 1000);
    setTableLoading(false)
  }

  useEffect(() => {
    setTableLoading(false)
  }, [carta]);

  const confirmMessage = () => {
    return selectedPrograms.map((k, i) => <h6 key={k.prg_id + i} >{k.prg_id}-{k.programa}</h6>
    )
  }

  const handleSelect = (data) => {
    if (data.value.length > 0) {
      setConfirmButtonDisable(false)
      setConfirmLabel("Confirmar " + data.value.length)
    } else {
      setConfirmLabel("Confirmar")
      setConfirmButtonDisable(true)

    }
    setSelectedPrograms(data.value)

  }
  const isRowSelectable = (event) => {
    const data = event.data;

    return !data.confirmado;
  }
  const onSubmitMedia = (recurrent, instruct, id_sustituto) => {

    console.log(selectedEditProgram)
    createOrder(selectedEditProgram.id_carta, id_sustituto, instruct, recurrent)
      .then(() => {
        
        toast.current.show({ severity: 'success', summary: 'Hecho', detail: 'Se ha actualizado la orden', life: 3000 });
        setEditDialog(false)
        
      })
      .catch((err) => console.log(err))

  }
  const editDialogHeader = (event) => {

    return (
      <div>
        <h6><strong>{selectedEditProgram?.programa_sustituto}</strong><br></br><strike>{selectedEditProgram?.programa}</strike></h6>

        <h6>{selectedEditProgram?.hora_inicio} - {selectedEditProgram?.hora_final}</h6>
        <hr></hr>

      </div>
    )
  }

  return (
    <div>

      <Dialog header={editDialogHeader} visible={editDialog} style={{ width: '50vw' }} onHide={() => setEditDialog(false)}>
        <MediaLibrary onSubmitMedia={onSubmitMedia} catalog={catalog} />
      </Dialog>

      <Button onClick={() => { setConfirmDialog(true) }} disabled={confirmButtonDisable} className="fixed z-1 bottom-0 mb-5 mr-5 right-0 " label={confirmLabel} />
      <Toast ref={toast} />
      <ConfirmDialog visible={confirmDialog} onHide={() => setConfirmDialog(false)} message={confirmMessage}
        header="Confirmar " accept={() => { handleConfirmProgram() }} acceptLabel="Confirmar" rejectLabel="Cancelar" reject={() => { setConfirmDialog(false) }} />

      <div className="card">

        <Card title="CARTA DE PROGRAMACIÓN" subTitle={<StatusGuide className="w-full" role={'editor'} />}>

          <div className="flex">
            <Dropdown id="ddsc" value={selectedChannel} options={canales} onChange={(e) => setSelectedChannel(e.value)} optionLabel="name" placeholder='Seleccione un canal' />
            <Divider layout="vertical" />
            <Calendar id="calendario" value={date} onChange={(e) => setDate(e.value)} />
          </div>
          <Divider></Divider>

          <DataTable loading={tableLoading} lazy dragSelection isDataSelectable={isRowSelectable} onSelectionChange={handleSelect} selection={selectedPrograms} filterDisplay="menu" value={carta.programming} emptyMessage="No hay registros disponibles." rowClassName={rowClass}  >
            <Column selectionMode="multiple" headerStyle={{ width: '3em' }} ></Column>
            <Column body={programBodyTemplate} header="Programa"></Column>
            <Column field="hora_inicio" sortable header="Inicio"></Column>
            <Column field="hora_final" sortable header="Fin"></Column>
            <Column body={editBodyTemplate} sortable header="Editar"></Column>
       
            <Column field="duracion" className='bg-blue-200 text-blue-800' sortable header="Duración"></Column>
          </DataTable>
        </Card>
      </div>

    </div>
  );
}

const comparisonFn = function (prevProps, nextProps) {
  return prevProps.location.pathname === nextProps.location.pathname;
};

export default React.memo(EmptyPage, comparisonFn);
