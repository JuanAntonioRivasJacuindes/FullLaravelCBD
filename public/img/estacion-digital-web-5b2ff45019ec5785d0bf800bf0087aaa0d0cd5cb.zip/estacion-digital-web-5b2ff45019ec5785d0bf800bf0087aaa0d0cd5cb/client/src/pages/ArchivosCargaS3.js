import React from 'react';
import ArchivosCarga from "../components/ArchivosCarga";

const ArchivosCargaS3 = () => {


    return(
        <ArchivosCarga></ArchivosCarga>
    );


}

export default React.memo(ArchivosCargaS3);