import React, { useState } from "react";
import Layout from '../components/Layout';
import SelectionEditor from "../components/selectionScreen/selectionEditor";

const SelectEditor = () => {
  const [channel, setChannel] = useState("");
  const [type, setType] = useState("");
  // eliminar posición de scroll guardada
  localStorage.removeItem('scrollPosition');
  return (
    <Layout>
      <SelectionEditor channel={channel} setChannel={setChannel} type={type} setType={setType} />
    </Layout>
  )
};

export default SelectEditor;
