import React from 'react';
import ExcelToJson  from '../components/ExcelToJson';

const ExcelModule = () => {


    return(
        <ExcelToJson></ExcelToJson>      
    );


}

export default React.memo(ExcelModule);