import React from 'react';
import Json from "../components/JsonGenerator";

const JsonModule = () => {


    return(
        <Json></Json>
    );


}

export default React.memo(JsonModule);