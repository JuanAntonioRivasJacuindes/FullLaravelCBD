import React, { useState, useEffect, useRef } from 'react';
import classNames from 'classnames';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { VideoService } from '../service/VideoService';
import { FileUpload } from 'primereact/fileupload';
import { Toast } from 'primereact/toast';
import { Fieldset } from 'primereact/fieldset';
import { InputTextarea } from 'primereact/inputtextarea';
import {FormatService} from '../components/format';
import axios from 'axios';
import ReactPlayer from "react-player";
import PlayFront from '../components/Player';
import { Chips } from "primereact/chips";
const Crud = () => {
        let emptyVideo = {
            id_video: '',
            prg_id: '',
            programa: '',
            nombre_video: '',
            duration: '',
            cue_points: '',
            nombre_archivo:''
        };
        //comentario prueba
        let emptydata = {
            'video_id_video': '',
            'video_nombre_archivo': '',
            'video_prg_id': '',
            'programa_id_programa': '',
            'programa_series_title': '',
            'programa_season_number': '',
            'programa_display_name': '',
            'programa_summary_programa': '',
            'programa_desription_serie': '',
            'programa_tags_programa': '',
            'episodio_id_programa': '',
            'episodio_id_video': '',
            'episodio_episode_name': '',
            'episodio_episode_number': '',
            'episodio_display_name': '',
            'episodio_summary_episodio': '',
            'episodio_actors': '',
            'episodio_author': '',
            'episodio_description_episode': '',
            'episodio_directors': '',
            'episodio_display_name_episode': '',
            'episodio_producers': '',
            'episodio_writers': ''
        }
        let key='';
        let minutosVideo=null;
        let url='';
        let ss='';
        let primero='';

        const [videos, setVideos] = useState(null);
        const [videoDialog, setVideoDialog] = useState(false);
        const [playerDialog, setPlayerDialog] = useState(false);
        const [video, setVideo] = useState(emptyVideo);
        const [selectedVideos, setSelectedVideos] = useState(null);
        const [globalFilter, setGlobalFilter] = useState(null);
        const toast = useRef(null);
        const [submitted, setSubmitted] = useState(false);
        const [programas, setProgramas]=useState([]);
        const [program, setProgram]=useState(null);
        const [cuePoints, setCuePoints]=useState([]);
        const [programa,setPrograma]=useState();
        const [episode, setEpisode]=useState(emptydata);
        // VARIABLES PARA GUARDAR LAS RUTAS DE LAS IMAGENES
        const [poster, setPoster]=useState(url);
        const [featuredImage, setFeaturedImage]=useState(url);
        const [tile, setTile]=useState(url);
        const [ss_4_3, setSS_4_3]=useState(url);
        const [ss_16_9, setSS_16_9]=useState(url);
        const [tags, setTags] = useState([]);
        const chooseOptions = {label: 'Escoger', icon: 'pi pi-fw pi-plus'};
        //Servicios de conexion al API REST
        const videoService = new VideoService();
        const formatService = new FormatService();

        useEffect(() => {
            const videoService = new VideoService();
            videoService.getBibliotecaMedia().then(response => {
                const datav = response.data;
                //console.log(datav);
                setVideos(datav)});

                videoService.getProgramas().then(response => {
                    const datap= response.data;
                    setProgramas(datap);
                });
        }, []);

        const hideDialog = () => {
            setVideoDialog(false);
        }

        const hidePlayer = () =>{
            setPlayerDialog(false);
        }

        const editVideo = (video) => {
            videoService.getVideoId(video.id_video).
                then(response => {
                    const datos= response.data;
                    //Consulta que hace el inner de programa y episodio con la tabla de sed_videos
                    if(datos===''){
                        setEpisode(emptydata);
                    }else{
                        setEpisode(datos);
                        let newTags = datos.programa_tags_programa
                        let arr = newTags.split(',');
                        //console.log(arr);
                        setTags(arr);
                        setPrograma(datos.episodio_id_programa+" - "+datos.programa_series_title)
                        setPoster(datos.programa_poster_path);
                        setFeaturedImage(datos.programa_featured_image_path);
                        setTile(datos.programa_tile_path);
                        setSS_4_3(datos.episodio_screenshot4_3_path);
                        setSS_16_9(datos.episodio_screenshot16_9_path);
                        } }
                    );
            setVideo({ ...video});
            setVideoDialog(true);
        }

        const Player = (video) =>{
            setCuePoints(video.cue_points);
            setVideo({ ...video});
            setPlayerDialog(true);
        }

        const saveProduct  = async () => {
            setSubmitted(true);
            if (episode.programa_display_name.trim() && episode.episodio_display_name.trim()) {

                    let dataVideo = { ...episode }
                    try {
                    console.log(programa);
                    //Se obtiene el PRG ID de la busqueda de programas
                    const splitString = programa.split(" - ");
                    let prg_id=splitString[0];
                    let PROGRAMA_=splitString[1]
                    console.log("PRG_ID: "+prg_id);
                    console.log("PROGRAMA: "+PROGRAMA_);

                    /*Se obtiene el AvailsID de la busqueda de AvailsID
                    const splitString2 = avails_id.split(" ");
                    let avails=splitString2[0];
                    console.log("Avails_ID: "+avails);*/

                    const episode_data={
                        episodio_id_programa: prg_id,
                        episodio_id_video: video.id_video,
                        //episodio_availsId: avails,
                        episodio_episode_name: dataVideo.episodio_display_name,
                        episodio_episode_number: dataVideo.episodio_episode_number,
                        episodio_display_name: dataVideo.episodio_display_name,
                        episodio_summary_episodio: dataVideo.episodio_summary_episodio,
                        episodio_actors: dataVideo.episodio_actors,
                        episodio_author: dataVideo.episodio_author,
                        episodio_description_episode: dataVideo.episodio_description_episode,
                        episodio_directors: dataVideo.episodio_directors,
                        episodio_display_name_episode: dataVideo.episodio_display_name_episode,
                        episodio_producers: dataVideo.episodio_producers,
                        episodio_writers: dataVideo.episodio_writers,
                        episodio_screenshot4_3_path: ss_4_3,
                        episodio_screenshot16_9_path: ss_16_9
                    }

                    const program_data={
                        programa_id_programa: prg_id,
                        programa_series_title: PROGRAMA_,
                        programa_season_number: dataVideo.programa_season_number,
                        programa_display_name: dataVideo.programa_display_name,
                        programa_summary_programa: dataVideo.programa_summary_programa,
                        programa_desription_serie: dataVideo.programa_summary_programa,
                        programa_tags_programa: tags.join(),
                        programa_poster_path: poster,
                        programa_featured_image_path: featuredImage,
                        programa_tile_path: tile
                    }

                    //Proceso para actualizar o insertar un programa a la tabla de programas
                    const existe_programa = await axios.get('https://10.126.65.29/vidig-vod/programaById/' + prg_id);
                    //const existe_programa = await axios.get('http://127.0.0.1:5000/programaById/' + prg_id);
                    console.log(existe_programa.data);
                    if (existe_programa.data === 'existe'){
                        const response = await axios.put('https://10.126.65.29/vidig-vod/actualiza_programaById/' + prg_id, program_data);
                        //const response = await axios.put('http://127.0.0.1:5000/actualiza_programaById/' + prg_id, program_data);
                        console.log(program_data);
                        console.log(response.data);
                    }
                    else{
                        const response_2 = await axios.post('https://10.126.65.29/vidig-vod/registra_programaById/' + prg_id, program_data);
                        //const response_2 = await axios.post('http://127.0.0.1:5000/registra_programaById/' + prg_id, program_data);
                        console.log(program_data);
                        console.log(response_2.data);
                    }
                    //Proceso para actualizar e insertar en la tabla de episodios la metadata capturada
                    const existe_episodio = await axios.get('https://10.126.65.29/vidig-vod/searchEpisode/' + video.id_video);
                    //const existe_episodio = await axios.get('http://127.0.0.1:5000/searchEpisode/' + video.id_video);
                    console.log(existe_episodio.data);
                    if (existe_episodio.data === 'existe'){
                        const response_ep = await axios.put('https://10.126.65.29/vidig-vod/actualiza_episodioById/' + video.id_video, episode_data);
                        //const response_ep = await axios.put('http://127.0.0.1:5000/actualiza_episodioById/' + video.id_video, episode_data);
                        console.log(episode_data);
                        console.log(response_ep.data);
                    }
                    else{
                        console.log(episode_data);
                        const response_2_ep = await axios.post('https://10.126.65.29/vidig-vod/registra_episodioById/' + video.id_video, episode_data);
                        //const response_2_ep = await axios.post('http://127.0.0.1:5000/registra_episodioById/' + video.id_video, episode_data);
                        console.log(episode_data);
                        console.log(response_2_ep.data);
                    }
                    toast.current.show({ severity: 'success', summary: 'Exito!', detail: 'Los datos se han actualizado!', life: 5000 });
                } catch (e) {
                    toast.current.show({ severity: 'error', summary: 'Error!', detail: 'Ha ocurrido un error, intentalo mas tarde.', life: 5000 });
                    console.log('something went wrong :(', e);
                }
            }
        }

        const onUpload = (event, key) => {
            if (event.xhr.readyState === 4) {
                let ruta=event.xhr.response;
                url=JSON.parse(ruta);
                if (key==="poster"){
                    setPoster(url["filename"]);}
                if(key==="featured_image"){
                    setFeaturedImage(url["filename"]);}
                if(key==="tile"){
                    setTile(url["filename"]);}
                if (key==="ss_4_3"){
                        setSS_4_3(url["filename"]);}
                if(key==="ss_16_9"){
                        setSS_16_9(url["filename"]);}
              }
            toast.current.show({severity: 'info', summary: 'Exito!', detail: 'El archivo se subio correctamente!', life: 5000});
        }

        const onError = (event) => {
            console.log(event.xhr);
            toast.current.show({severity: 'error', summary: 'Error!', detail: 'Ha ocurrido un error, intentalo mas tarde.', life: 5000});
        }

        const programaInfo = async (prg_id) =>{
            videoService.getProgramaInfo(prg_id).then(response => {
                const data= response.data;
                setProgram(data[0]);
            });
            console.log(program);
        }

        const onInputChange = (e, name) => {
            const val = (e.target && e.target.value) || '';
            let _video = { ...episode };
            _video[`${name}`] = val;
            setEpisode(_video);
        }

        const thumbBodyTemplate=(rowData)=>{
            if (rowData['nombre_archivo']){
                return(
                    <div className='w-10% p-0 m-0'>
                    {/* <Image  width="80" height="60"  src={rowData['thumbnails'][0]['url']} alt="Image Text" /> */}
                    {//<video className='p-0 m-0' width={200} controls={true} src={"https://video1.socio.gs/EstacionDigital/_definist_/proxy/mp4:"+rowData.nombre_archivo+"/playlist.m3u8"}></video>
                    }
                    <ReactPlayer
                        onMouseOver={(e)=>{try{ e.target.play()} catch{console.log("No se puede")} }}
                        onMouseOut={(e)=>{try{ e.target.pause()} catch{console.log("No se puede")} }}
                        url={"https://video1.socio.gs/EstacionDigital/_definist_/proxy/mp4:"+rowData.nombre_archivo+"/playlist.m3u8"}
                        width="200px"
                        height="120px"
                        controls={false}
                        muted={true}/>
                </div>
               )

            }
            else {
                return(
                    <div className='w-10% p-0 m-0'>
                        {/* <Image  width="80" height="60"  src={rowData['thumbnails'][0]['url']} alt="Image Text" /> */}
                        <p>No preview</p>
                        {/* <Image  width="80" height="60"  src={rowData['thumbnails'][0]['url']} alt="Image Text" /> */}
                    </div>
               )
            }
        }

        const idVideoBodyTemplate = (rowData) => {
            return (
                <>
                    <span className="p-column-title">Id Video</span>
                    {rowData.id_video}
                </>
            );
        }

        const nombreBodyTemplate = (rowData) => {
            return (
                <>
                    <span className="p-column-title">Nombre</span>
                    {rowData.nombre_video}
                </>
            );
        }

        const prgIdBodyTemplate = (rowData) => {
            return (
                <>
                    <span className="p-column-title">Nombre Archivo</span>
                    {rowData.prg_id}
                </>
            );
        }

        const programaBodyTemplate = (rowData) => {
            return (
                <>
                    <span className="p-column-title">Nombre Archivo</span>
                    {rowData.programa}
                </>
            );
        }

        const duracionBodyTemplate = (rowData) => {
            return (
                <>
                    <span className="p-column-title">Duración</span>
                    {formatService.formatTimeMediaStream(rowData.duration)}
                </>
            );
        }

        const actionBodyTemplate = (rowData) => {
            return (
                    <div className="actions">
                        <Button icon="pi pi-pencil" className="p-button-rounded p-button-success mr-2" onClick={() => editVideo(rowData)} />
                        <Button icon="pi pi-play" className="p-button-rounded p-button-info mr-2" onClick={() => Player(rowData)} />
                    </div>

            );
        }

        const header = (
            <div className="flex flex-column md:flex-row md:justify-content-between md:align-items-center">
                <h5 className="m-0">Biblioteca de Media</h5>
                <span className="block mt-2 md:mt-0 p-input-icon-left">
                    <i className="pi pi-search" />
                    <InputText type="search" onInput={(e) => setGlobalFilter(e.target.value)} placeholder="Buscar..." />
                </span>
            </div>
        );

        const productDialogFooter = (
            <>
                <Button label="Cancelar" icon="pi pi-times" className="p-button-text" onClick={hideDialog} />
                <Button label="Guardar" icon="pi pi-check" className="p-button-text"  onClick={saveProduct}/>
            </>
        );

    return (
        <div className="grid crud-demo" >
            <div className="col-12">
                <div className="card">
                    <Toast ref={toast} />
                    <DataTable  value={videos} selection={selectedVideos} onSelectionChange={(e) => setSelectedVideos(e.value)}
                        dataKey="id" paginator rows={10} rowsPerPageOptions={[5, 10, 25]} className="datatable-responsive"
                        paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
                        currentPageReportTemplate="Mostrando videos del {first} al {last} de un total de {totalRecords} videos"
                        globalFilter={globalFilter} emptyMessage="No se encontraron videos." header={header} responsiveLayout="scroll">
                        <Column field="preview" header="PREVIEW" sortable body={thumbBodyTemplate} headerStyle={{ width: '12%', minWidth: '10rem' }}></Column>
                        <Column field="prg_id" header="PRG ID" sortable body={prgIdBodyTemplate} headerStyle={{ width: '12%', minWidth: '10rem' }}></Column>
                        <Column field="programa" header="PROGRAMA" sortable body={programaBodyTemplate} headerStyle={{ width: '12%', minWidth: '10rem' }}></Column>
                        <Column field="id_video" header="ID VIDEO" sortable body={idVideoBodyTemplate} headerStyle={{ width: '12%', minWidth: '10rem' }}></Column>
                        <Column field="nombre" header="NOMBRE VIDEO" sortable body={nombreBodyTemplate} headerStyle={{ width: '14%', minWidth: '10rem' }}></Column>
                        <Column field="duracion" header="DURACIÓN" sortable body={duracionBodyTemplate} headerStyle={{ width: '10%', minWidth: '9rem' }}></Column>
                        <Column body={actionBodyTemplate}></Column>
                    </DataTable>

                    <Dialog visible={videoDialog} style={{ width:'1500px', height: '1500px' }} header="Metadata del video" modal className="p-fluid" footer={productDialogFooter} onHide={hideDialog}>
                        <Fieldset legend="Mediainfo" style={{backgroundColor:'#EEEEEE'}}>
                            <div className="field">
                                <b><strong>Id Video: </strong></b>  <label>{video.id_video}</label><br/>
                                <b><strong>Nombre del Video: </strong></b>  <label>{video.nombre_video}</label><br/>
                                <b><strong>Nombre del archivo: </strong></b>  <label>{video.nombre_archivo}</label><br/>
                                <b><strong>Duración: </strong></b>  <label>{formatService.formatTimeMediaStream(video.duration)}</label>
                            </div>
                        </Fieldset><br/>
                            <div className="formgrid grid">
                                <div className="field col">
                                    <Fieldset legend="Program Data" >
                                            <label>Programa:</label>
                                            <InputText key ="series_title" list="series_title" onBlur={(event)=>setPrograma(event.target.value)} placeholder={video.prg_id ? video.prg_id+" - "+video.programa : "Seleccione un programa"} />
                                            <datalist id="series_title">
                                                {programas.map((op)=><option key={op["prg_id"]}>{op["prg_id"]} - {op["nombre_programa"]}</option>)}
                                            </datalist>
                                            {/*<p>Programa Seleccionado: {programa} </p><br/>*/}<br/><br/>

                                            <label>Display Name:</label>
                                            <InputText id="programa_display_name" value={episode.programa_display_name} onChange={(e) => onInputChange(e, 'programa_display_name')} required className={classNames({ 'p-invalid': submitted && !episode.programa_display_name })} />
                                            {submitted && !episode.programa_display_name && <small className="p-invalid">Este campo es obligatorio.</small>}<br/><br/>

                                            <label htmlFor="programa_season_number">Temporada:</label>
                                            <InputText type="number" id="programa_season_number" value={episode.programa_season_number} onChange={(e) => onInputChange(e, 'programa_season_number')} required className={classNames({ 'p-invalid': submitted && !episode.programa_season_number })}/><br/><br/>
                                            {submitted && !episode.programa_season_number && <small className="p-invalid">Este campo es obligatorio.</small>}<br/>

                                            <label htmlFor="programa_summary_programa">Resumen:</label>
                                            <InputTextarea value ={episode.programa_summary_programa} placeholder="Ej. María Segovia fue condenada injustamente a 25 años de cárcel por haber asesinado a un hombre, crimen que ella no cometió. María ingresó embarazada del político más codiciado de México Ignacio Alcázar quién la abandonó y rechazó por su supuesto crimen." rows={5} cols={30} id="programa_summary_programa" onChange={(e) => onInputChange(e, 'programa_summary_programa') } />
                                            {/*submitted && !videoId.series_summary && <small className="p-invalid">Este campo es obligatorio.</small>*/}<br/><br/>

                                            <label htmlFor="programa_summary_programa">Descripción del programa:</label>
                                            <InputTextarea value ={episode.programa_summary_programa} placeholder="Ej. María Segovia fue condenada injustamente a 25 años de cárcel por haber asesinado a un hombre, crimen que ella no cometió. María ingresó embarazada del político más codiciado de México Ignacio Alcázar quién la abandonó y rechazó por su supuesto crimen." rows={5} cols={30} id="programa_summary_programa" onChange={(e) => onInputChange(e, 'programa_summary_programa')}/>
                                            {/*submitted && !videoId.series_description && <small className="p-invalid">Este campo es obligatorio.</small>*/}<br/><br/>

                                            <label htmlFor="programa_tags_programa">Tags:</label>
                                            {//<InputText id="programa_tags_programa" value={episode.programa_tags_programa} placeholder="Ej. Drama, Diversión, Romance, TvNovela, Tendencia" onChange={(e) => onInputChange(e, 'programa_tags_programa')} />
                                            }
                                            <Chips value={tags} onChange={(e) => setTags(e.value)} />
                                            {/*submitted && !videoId.series_tags && <small className="p-invalid">Este campo es obligatorio.</small>*/}<br/><br/>

                                            <label htmlFor="Poster">Poster</label>
                                            <FileUpload key="Poster" chooseOptions={chooseOptions} url="https://10.126.65.29/vidig-s3-gate/upload" name="file" onUpload={(event) => onUpload(event, key="poster")} onError={(event) => onError(event)} mode="basic"></FileUpload>
                                            <p>RUTA POSTER: {poster} </p><br/>

                                            <label htmlFor="featured_image">Featured Image</label>
                                            <FileUpload key="featured_image" chooseOptions={chooseOptions} url="https://10.126.65.29/vidig-s3-gate/upload" name="file" onUpload={(event) => onUpload(event, key="featured_image")} onError={(event) => onError(event)} mode="basic"></FileUpload>
                                            <p>RUTA FEATURED_IMAGE: {featuredImage} </p><br/>

                                            <label htmlFor="tile">Tile</label>
                                            <FileUpload key="tile" chooseOptions={chooseOptions} url="https://10.126.65.29/vidig-s3-gate/upload" name="file" onUpload={(event) => onUpload(event, key="tile")} onError={(event) => onError(event)} mode="basic"></FileUpload>
                                            <p>RUTA TILE: {tile} </p><br/>
                                    </Fieldset>
                                </div><br/>

                                <div className="field col">
                                    <Fieldset legend="Episode Data" >
                                            {/*<label>Avails Id:</label>
                                            <InputText list="AvailsIds" onChange={(e)=>setAvails_id(e.target.value)} placeholder="Selecciona un Avails Id" />
                                            <datalist id="AvailsIds">
                                                {AvailsIds.map((item)=><option key={item["pluto_avails_id"]}>{item["pluto_avails_id"]} - {item["episode_title"]}</option>)}
                                            </datalist>
                                            <p>Avails Id seleccionado: {avails_id} </p><br/>*/}

                                            <label htmlFor="episode_title">Nombre del Episodio:</label>
                                            <InputText value={episode.episodio_display_name} placeholder="Ej. Capítulo 166: Se cumple un gran sueño y un pacto de amor."id="episode_title" onChange={(e) => onInputChange(e, 'episodio_display_name')} required className={classNames({ 'p-invalid': submitted && !episode.episodio_display_name })} />
                                            {submitted && !episode.episodio_display_name && <small className="p-invalid">Este campo es obligatorio.</small>}<br/><br/>

                                            <label htmlFor="episode_number">Número de Episodio:</label>
                                            <InputText type="number" value={episode.episodio_episode_number} id="episode_number" onChange={(e) => onInputChange(e, 'episodio_episode_number')} required className={classNames({ 'p-invalid': submitted && !episode.episodio_episode_number })}/><br/><br/>
                                            {submitted && !episode.episodio_episode_number && <small className="p-invalid">Este campo es obligatorio.</small>}<br/><br/>

                                            <label htmlFor="summary_episode">Resumen Episodio: </label>
                                            <InputTextarea value={episode.episodio_summary_episodio} placeholder="Ej. María estaba embarazada de un político que la dejó después del supuesto crimen. Al dar a luz le quitaron a su hija diciéndole que había muerto, pero al cumplir su condena le confiesan que su hija nunca murió, por lo que María Segovia buscará a su hija y la venganza por el dolor que le causaron." rows={5} cols={30} id="episode_summary" onChange={(e) => onInputChange(e, 'episodio_summary_episodio')} />
                                            {/*submitted && !videoId.episode_summary && <small className="p-invalid">Este campo es obligatorio.</small>*/}<br/><br/>

                                            <label htmlFor="description_episode">Descripcion Episodio: </label>
                                            <InputTextarea value={episode.episodio_description_episode} placeholder="Ej. María estaba embarazada de un político que la dejó después del supuesto crimen. Al dar a luz le quitaron a su hija diciéndole que había muerto, pero al cumplir su condena le confiesan que su hija nunca murió, por lo que María Segovia buscará a su hija y la venganza por el dolor que le causaron." rows={5} cols={30} id="episode_description" onChange={(e) => onInputChange(e, 'episodio_description_episode')}/>
                                            {/*submitted && !videoId.episode_description && <small className="p-invalid">Este campo es obligatorio.</small>*/}<br/><br/>

                                            <label htmlFor="author">Autor: </label>
                                            <InputText value={episode.episodio_author} placeholder="Ej. Tv Azteca" id="clips_name_author" onChange={(e) => onInputChange(e, 'episodio_author')} />
                                            {/*submitted && !videoId.clips_name_author && <small className="p-invalid">Este campo es obligatorio.</small>*/}<br/><br/>

                                            <label htmlFor="directors">Directores: </label>
                                            <InputText value={episode.episodio_directors} placeholder="Ej. José Acosta, Lorena Maza" id="clips_direcotrs" onChange={(e) => onInputChange(e, 'episodio_directors')} />
                                            {/*submitted && !videoId.clips_direcotrs && <small className="p-invalid">Este campo es obligatorio.</small>*/}<br/><br/>

                                            <label htmlFor="actors">Actores: </label>
                                            <InputText value={episode.episodio_actors} placeholder="Ej. Ivonne Montero, Mauricio Islas, Regina Torné, Gabriela Roel, Omar Fierro, Anna Ciocchetti, Rossana Nájera " id="clips_actors" onChange={(e) => onInputChange(e, 'episodio_actors')}/>
                                            {/*submitted && !videoId.clips_actors && <small className="p-invalid">Este campo es obligatorio.</small>*/}<br/><br/>

                                            <label htmlFor="writers">Escritores: </label>
                                            <InputText value={episode.episodio_writers} placeholder="Ej. Patricia Palmer y Bethel Flores" id="clips_writers" onChange={(e) => onInputChange(e, 'episodio_writers')}/>
                                            {/*submitted && !videoId.clips_writers && <small className="p-invalid">Este campo es obligatorio.</small>*/}<br/><br/>

                                            <label htmlFor="producers">Productores: </label>
                                            <InputText value={episode.episodio_producers} placeholder="Ej. María del Carmen Marcos, José Solano Rodríguez y Maricarmen Marcos" id="clips_producers" onChange={(e) => onInputChange(e, 'episodio_producers')} />
                                            {/*submitted && !videoId.clips_producers && <small className="p-invalid">Este campo es obligatorio.</small>*/}<br/><br/>

                                            <label htmlFor="screenshot4_3">Screenshot 4_3</label>
                                            <FileUpload key="screenshot4_3" chooseOptions={chooseOptions} url="https://10.126.65.29/vidig-s3-gate/upload" name="file" onUpload={(event) => onUpload(event, key="ss_4_3")} onError={(event) => onError(event)} mode="basic"></FileUpload>
                                            <p>RUTA SCREENSHOT_4_3: {ss_4_3} </p><br/>

                                            <label htmlFor="screenshot16_9">Screenshot 16_9</label>
                                            <FileUpload key="screenshot16_9" chooseOptions={chooseOptions} url="https://10.126.65.29/vidig-s3-gate/upload" name="file" onUpload={(event) => onUpload(event, key="ss_16_9")} onError={(event) => onError(event)} mode="basic"></FileUpload>
                                            <p>RUTA SCREENSHOT_16_9: {ss_16_9} </p><br/>
                                        <br/>
                                    </Fieldset>
                                </div>
                            </div>
                    </Dialog>

                    <Dialog visible={playerDialog} style={{ width:'1200px', height: '1500px' }} modal className="p-fluid" onHide={hidePlayer}>
                       <Fieldset legend="Mediainfo" style={{backgroundColor:'#EEEEEE'}}>
                            <div className="field">
                                <b><strong>Id Video: </strong></b>  <label>{video.id_video}</label><br/>
                                <b><strong>Nombre del Video: </strong></b>  <label>{video.nombre_video}</label><br/>
                                <b><strong>Nombre del archivo: </strong></b>  <label>{video.nombre_archivo}</label><br/>
                                <b><strong>Duración: </strong></b>  <label>{formatService.formatTimeMediaStream(video.duration)}</label>
                            </div>
                        </Fieldset><br/>
                       <PlayFront actualiza={true} tipo={true} cuePoints={cuePoints} nombre_archivo={video.nombre_archivo} id_video={video.id_video}></PlayFront>
                    </Dialog>

                </div>
            </div>
        </div>
    );
}

const comparisonFn = function (prevProps, nextProps) {
    return prevProps.location.pathname === nextProps.location.pathname;
};

export default React.memo(Crud, comparisonFn);
