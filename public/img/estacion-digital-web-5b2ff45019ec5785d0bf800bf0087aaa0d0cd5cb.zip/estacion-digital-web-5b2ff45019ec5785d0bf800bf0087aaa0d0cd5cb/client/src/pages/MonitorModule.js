import React from 'react';
import UploadMonitor from "../components/UploadMonitor";

const Monitor = () => {


    return(
        <UploadMonitor></UploadMonitor>
    );


}

export default React.memo(Monitor);