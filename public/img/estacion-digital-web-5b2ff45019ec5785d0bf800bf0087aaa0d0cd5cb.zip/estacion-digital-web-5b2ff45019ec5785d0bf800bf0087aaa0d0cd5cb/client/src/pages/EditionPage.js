import React, { useState, useEffect, useRef } from 'react';
import { Dropdown } from 'primereact/dropdown';
import { Card } from 'primereact/card';
import { Divider } from 'primereact/divider';
import StatusGuide from '../components/schedule/statusGuide';
import { Steps } from 'primereact/steps';
import { Toast } from 'primereact/toast';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { getCanales, getAllOrders } from '../service/EstacionDigitalServices';
import { FilterMatchMode } from 'primereact/api';

import '../styles/EditionPage.css';

import BlockOrderComponent from '../components/edition/BlockOrderComponent';



const EditionPage = () => {
    const toast = useRef(null);
    const [activeIndex, setActiveIndex] = useState(0);
    const { localStorage } = window;

    const date = new Date()

    const [calendarDate, setCalendarDate] = useState(date)
    const [filterValue, setFilterValue] = useState()
    const filters = { 'id_estatus': { value: filterValue, matchMode: FilterMatchMode.EQUALS } }

    const [endDate, setEndDate] = useState(date.getFullYear() + "-" + (parseInt(date.getMonth()) + 1).toString()  + "-" + date.getDate());
    const statusFilters = [
        { label: 'Todos los bloqueos', value: null },
        { label: 'Bloqueo sin media', value: '0' },
        { label: 'Bloqueo en proceso', value: '1' },
        { label: 'Advertencia en media', value: '2' },
        { label: 'Bloqueos Completados', value: '3' },
        { label: 'Error de procesamiendo', value: '4' }
    ]
    const items = [
        { label: 'Detalle de la orden' },
        { label: 'Asignar Media' },
        { label: 'Verificar Media' },
        { label: 'Confirmar' },
    ];
    const [canales, setCanales] = useState([])
    const [orders, setOrders] = useState([])
    const [selectedChannel, setSelectedChannel] = useState()
    const [tableLoading, setTableLoading] = useState(false)
    const [selectedOrder, setSelectedOrder] = useState()
    const blockOrderComponent = useRef()
    const [displayMaximizable, setDisplayMaximizable] = useState(false);
    const [continueButtonStatus, setContinueButtonStatus] = useState();

    const updateOrderSuccess = () => {
        setDisplayMaximizable(false)
        getOrders(selectedChannel)
        toast.current.show({ severity: 'success', summary: 'Hecho', detail: 'Se ha actualizado la orden de bloqueo', life: 4000 });
    }

    const buttonFun = (rowData) => {
        setDisplayMaximizable(true)
        setSelectedOrder(rowData['id_bloqueo'])

    }
    const onCalendarChange = (event) => {

        setCalendarDate(event)
        const month = parseInt(event.getMonth()) + 1

        setEndDate(event.getFullYear() + "-" + month.toString()+ "-" + event.getDate())


    }
    const callback = (index) => {
        setActiveIndex(index)
    }
    useEffect(() => {

        if (!displayMaximizable) {
            setActiveIndex(0)
            localStorage.clear()
        }

    }, [displayMaximizable]);

    useEffect(() => {
        getCanales()
            .then((res) => {
                setCanales(res)
            })
            .catch((err) => console.log(err))
        return () => {
        }
    }, []);

    useEffect(() => {
        getOrders(selectedChannel)
        console.log(endDate)
    }, [endDate])

    const selectButtonTemplate = (rowData) => {
        return <Button label="Seleccionar" onClick={(e) => buttonFun(rowData)} />
    }
    const handleActiveIndexChange = (value) => {
        changeButtonStatus(true)
        setActiveIndex(value)
        blockOrderComponent.current.next(value)
    }

    const rowClass = (data) => {

        return {
            ' bg-red-100 text-red-800 hover-shadow ': data.id_estatus === 4,
            'bg-green-100 text-green-800': data.id_estatus === 3,
            'bg-orange-100 text-orange-800': data.id_estatus === 2,
            'bg-yellow-100 text-yellow-800': data.id_estatus === 1
        }
    }

    const footer = () => {
        if (activeIndex === 0) {
            return (

                <div className="mt-3 flex flex-row">


                    <Button className="p-button-secondary " onClick={() => setDisplayMaximizable(false)} > Cancelar</Button>
                    <Button onClick={() => handleActiveIndexChange(activeIndex + 1)} disabled={continueButtonStatus} >Continuar</Button>
                </div>
            );
        } else if (activeIndex === 1 || activeIndex === 2) {
            return (

                <div className="mt-3 flex flex-row">

                    <Button className="p-button-secondary " onClick={() => setDisplayMaximizable(false)} > Cancelar</Button>
                    <Button className="align-items-right" onClick={() => handleActiveIndexChange(activeIndex - 1)}  >Regresar</Button>
                    <Button onClick={() => handleActiveIndexChange(activeIndex + 1)} disabled={continueButtonStatus} >Continuar</Button>

                </div>
            );
        } else if (activeIndex === 3) {
            return (

                <div className="mt-3 flex flex-row">

                    <Button className="p-button-secondary    " onClick={() => setDisplayMaximizable(false)} > Cancelar</Button>
                    <Button onClick={() => handleActiveIndexChange(activeIndex - 1)}  >Regresar</Button>
                </div>
            );
        }
    }

    const header = (
        <div className='w-full'>
            <h2>Orden de Bloqueo</h2>
            <Steps model={items} activeIndex={activeIndex} onSelect={(e) => handleActiveIndexChange(e.index)} readOnly={true}></Steps>

        </div>
    );
    function getOrders(channel) {
        if (channel) {

            setOrders([])
            setTableLoading(true)
            setSelectedChannel(channel)

            getAllOrders(channel['id'], endDate, endDate).then((res) => {
                setOrders(res)
                setTableLoading(false)
            })
                .catch((err) => console.log(err))
        }
    }
    const changeButtonStatus = (status) => {
        setContinueButtonStatus(status)
    }

    return (

        <div className="card w-full">
            <Toast ref={toast} />

            <Card title="ORDENES DE BLOQUEO" subTitle={<StatusGuide className="w-full" role={'editor'} />}>

                <div className="flex">
                    <Dropdown id="ddsc" value={selectedChannel} options={canales} onChange={(e) => getOrders(e.value)} optionLabel="name" placeholder='Seleccione un canal' />
                    <Divider layout="vertical" />
                    <Calendar id="calendario" locale="es" value={calendarDate} onChange={(e) => onCalendarChange(e.value)} />
                    <Dropdown value={filterValue} options={statusFilters} onChange={(e) => setFilterValue(e.value)} placeholder="Filtrar" />
                </div>
                <div>

                    <Divider ></Divider>
                    <DataTable filters={filters} filterDisplay="menu" emptyMessage="No hay registros disponibles." value={orders} loading={tableLoading} rowClassName={rowClass} sort paginator rows={25} rowsPerPageOptions={[25, 50, 100, 200]}>
                        <Column field="programa_sustituto" header="Sustituto"></Column>
                        <Column field="fecha" sortable header="Fecha"></Column>
                        <Column field="instrucciones" header="Instrucciones"></Column>
                        <Column field="duracion" className='bg-blue-200 text-blue-800' sortable header="Duración"></Column>
                        <Column header="Editar" body={selectButtonTemplate}>|</Column>
                    </DataTable>

                </div>

                <div>
                    <Dialog className="bg-blue-200" header={header} footer={footer} visible={displayMaximizable} maximizable modal style={{ width: '70vw', height: '100%' }} onHide={() => setDisplayMaximizable(false)}>
                        <BlockOrderComponent updateOrderSuccess={updateOrderSuccess} changeButtonStatus={changeButtonStatus} ref={blockOrderComponent} activeIndex={activeIndex} callback={callback} order={selectedOrder}></BlockOrderComponent>
                    </Dialog>

                </div>


            </Card>


        </div>
    );
}



export default React.memo(EditionPage);
