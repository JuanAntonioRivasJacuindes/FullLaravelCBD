import "primeicons/primeicons.css";
import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primereact/resources/primereact.css";
import "primeflex/primeflex.css";
import "../cartas/TableStyle.css";

import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import React, { useEffect, useState } from "react";
import * as ApiAws from "../cartas/ApiAws";

// import CartaItem from "./CartaItem";
// import CartaItemAdn40 from "./CartaItemAdn40";
// import CartaItemAmas from "./CartaItemAmas";
// import CartaItemSiete from "./CartaItemSiete";
// import CartaItemUno from "./CartaItemUno";

const CartaList = () => {
    // const canales = ["UNO", "SIETE", "AMAS", "ADN40"];

    // const [eventos, setEventos] = useState([]);
    const [datosUno, setUno] = useState([]);
    const [datosSiete, setSiete] = useState([]);
    const [datosAmas, setAmas] = useState([]);
    const [datosAdn40, setAdn40] = useState([]);

    // Datos Carta Uno
    const listaUno = async () => {
        try {
            const resUno = await ApiAws.cartaUno();
            const dataUno = await resUno.json();
            setUno(dataUno);
            console.log(dataUno);
        } catch (error) {
            console.log(error);
        }
    };
    // Datos Carta Siete
    const listaSiete = async () => {
        try {
            const res = await ApiAws.cartaSiete();
            const dataSiete = await res.json();
            setSiete(dataSiete);
            console.log(dataSiete);
        } catch (error) {
            console.log(error);
        }
    };
    // Datos Carta Amas
    const listaAmas = async () => {
        try {
            const res = await ApiAws.cartaAmas();
            const dataAmas = await res.json();
            setAmas(dataAmas);
            console.log(dataAmas);
        } catch (error) {
            console.log(error);
        }
    };
    // Datos Carta Adn40
    const listaAdn40 = async () => {
        try {
            const res = await ApiAws.cartaAdn40();
            const dataAdn40 = await res.json();
            setAdn40(dataAdn40);
            console.log(dataAdn40);
        } catch (error) {
            console.log(error);
        }
    };

    // const f = new Date();

    useEffect(() => {
        listaUno();
        listaSiete();
        listaAmas();
        listaAdn40();
        console.log(new Date());
    }, []);

    const rowClass = (data) => {
        if (data.bloqueo === 1) {
            return {
                "row-live-ok": data.bloqueo === 1,
            };
        } else {
            return {
                'row-playout' : data.bloqueo === 0,
            }
        }
    }

    return (
        <div className="card">
            <div className="grid">
                <div className="col-12 lg:col-6 xl:col-3">
                    CANAL : UNO
                    <div className="col-sm-12 p-fluid formgrid grid">
                        <div className="card p-fluid">
                            <div className="datatable-style">
                                <DataTable value={datosUno} class="p-datatable-sm" rowClassName={rowClass} responsiveLayout="scroll">
                                    <Column field="programa" header="Programa"></Column>
                                    <Column field="hora" header="Hora"></Column>
                                    <Column field="bloqueo" header="Bloqueo"></Column>
                                </DataTable>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="col-12 lg:col-6 xl:col-3">
                    CANAL : SIETE
                    <div className="col-sm-12 p-fluid formgrid grid">
                        <div className="card p-fluid">
                            <div className="datatable-style">
                                <DataTable value={datosSiete} class="p-datatable-sm" rowClassName={rowClass} responsiveLayout="scroll">
                                    <Column field="programa" header="Programa"></Column>
                                    <Column field="hora" header="Hora"></Column>
                                    <Column field="bloqueo" header="Bloqueo"></Column>
                                </DataTable>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="col-12 lg:col-6 xl:col-3">
                    CANAL : AMAS
                    <div className="col-sm-12 p-fluid formgrid grid">
                        <div className="card p-fluid">
                            <div className="datatable-style">
                                <DataTable value={datosAmas} class="p-datatable-sm" rowClassName={rowClass}  responsiveLayout="scroll">
                                    <Column field="programa" header="Programa"></Column>
                                    <Column field="hora" header="Hora"></Column>
                                    <Column field="bloqueo" header="Bloqueo"></Column>
                                </DataTable>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="col-12 lg:col-6 xl:col-3">
                    CANAL : ADN40
                    <div className="col-sm-12 p-fluid formgrid grid">
                        <div className="card p-fluid">
                            <div className="datatable-style">
                                <DataTable value={datosAdn40} class="p-datatable-sm" rowClassName={rowClass}  responsiveLayout="scroll">
                                    <Column field="programa" header="Programa"></Column>
                                    <Column field="hora" header="Hora"></Column>
                                    <Column field="bloqueo" header="Bloqueo"></Column>
                                </DataTable>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CartaList;
