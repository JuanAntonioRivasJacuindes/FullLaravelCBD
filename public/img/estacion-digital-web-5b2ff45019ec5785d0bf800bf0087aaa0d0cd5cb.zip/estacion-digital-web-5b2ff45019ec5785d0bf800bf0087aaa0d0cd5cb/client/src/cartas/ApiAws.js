// API Estacion Digital Aws
const URL2 = "https://10.126.65.29/vidig-api/"; 

export const listCarta = async () => {
    return await fetch(URL2 + "carta/canales");
};

export const cartaUno = async () => {
    return await fetch(URL2 + "carta/canales/uno");
};

export const cartaSiete = async () => {
    return await fetch(URL2 + "carta/canales/siete");
};

export const cartaAmas = async () => {
    return await fetch(URL2 + "carta/canales/amas");
};

export const cartaAdn40 = async () => {
    return await fetch(URL2 + "carta/canales/adn40");
};

export const programasUno = async () => {
    return await fetch(URL2 + "carta/programa/uno");
};

export const programasSiete = async () => {
    return await fetch(URL2 + "carta/programa/siete");
};

export const programasAmas = async () => {
    return await fetch(URL2 + "carta/programa/amas");
};

export const programasAdn40 = async () => {
    return await fetch(URL2 + "carta/programa/adn40");
};

