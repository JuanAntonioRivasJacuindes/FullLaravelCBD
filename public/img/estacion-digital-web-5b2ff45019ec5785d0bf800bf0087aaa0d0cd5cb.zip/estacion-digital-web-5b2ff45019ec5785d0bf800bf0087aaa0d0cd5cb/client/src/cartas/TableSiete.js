import "primeicons/primeicons.css";
import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primereact/resources/primereact.css";
import "primeflex/primeflex.css";
import "./TableStyle.css";

import React, { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import * as ApiAws from "./ApiAws";



const TableSiete = () => {
    const [siete, setSiete] = useState([]);

    const programasSiete = async () => {
        try {
            const resSiete = await ApiAws.programasSiete();
            const dataSiete = await resSiete.json();
            setSiete(dataSiete);
            // console.log(dataSiete);
        } catch (error) {
            console.log(error);
        }
    };

    useEffect(() => {
        setTimeout(() => {
            programasSiete();
            //console.log(new Date());
        }, 20000);
    }, [siete]);;

    const rowClass = (data) => {
        let actual = new Date().getTime();
        let inicio = new Date(data.fecha + " " + data.hora_inicio + " GMT-0600").getTime();

        if (actual >= inicio) {
            return {
                "row-ok" : "ok"
            };
        } else {
            if (data.bloqueo === 1) {
                if (data.prg_id === data.prg_sustituto) {
                    return {
                        "row-live-ok": data.bloqueo === 1,
                    };
                } else {
                    if (data.status_video === 5) {
                        if (data.ads === "null" || data.ads === "false") {
                            return {
                                "row-live-ok": data.bloqueo === 1,
                            };
                        } else {
                            return {
                                "row-live-ads": data.bloqueo === 1,
                            };
                        }
                    } else {
                        if (data.prg_sustituto === 0) {
                            return {
                                "row-2": data.bloqueo === 1,
                            };
                        } else {
                            return {
                                "row-live": data.bloqueo === 1,
                            };
                        }
                    }
                }
            } else if (data.bloqueo === 0) {
                if (data.prg_id === data.prg_sustituto) {
                    return {
                        "row-playout-fail": data.bloqueo === 0,
                    };
                } else {
                    if (data.status_video === 6) {
                        return {
                            "row-processing": data.bloqueo === 0,
                        };
                    } else if (data.status_video === 5) {
                        if (data.ads === "null" || data.ads === "false") {
                            return {
                                "row-live-ok": data.bloqueo === 0,
                            };
                        } else {
                            return {
                                "row-live-ads": data.bloqueo === 0,
                            };
                        }
                    } else {
                        return {
                            row: data.bloqueo === 0,
                        };
                    }
                }
            }
        }
    };

    // console.log(siete);
    return (
        <div className="datatable-style">
            <div className="card">
                <DataTable value={siete} rowClassName={rowClass} responsiveLayout="scroll">
                    <Column field="canal" header="Canal"></Column>
                    <Column field="fecha" header="Fecha"></Column>
                    <Column field="hora_inicio" header="Horario"></Column>
                    <Column field="duracion" header="Duracion"></Column>
                    <Column field="original" header="Programa"></Column>
                    <Column field="remplazo" header="Programa2"></Column>
                    <Column field="bloqueo" header="Bloqueo"></Column>
                </DataTable>
            </div>
        </div>
    );
};

export default React.memo(TableSiete);
