import React from "react";
import CartaList from "./CartaList";

const Carta = (props) => {
    return (
        <div>
            <CartaList />
        </div>
    );
};

export default React.memo(Carta);
