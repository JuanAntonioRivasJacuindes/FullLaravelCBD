import axios from 'axios';


export class ComponentService{

    getMenus(){

    }
    getComponents(user_id = 1) {  
        return  [
            {
              label: 'Video On Demand', icon: 'pi pi-fw pi-clone',
              items: [
                { label: 'Captura Metadata', icon: 'pi pi-pencil', to: '/VideoList' },
                { label: 'Generar TXT', icon: 'pi pi-bars', to: '/TxtGenerator' },
                { label: 'Captura de Media Order', icon: 'pi pi-copy', to: '/ExcelModule' },
                { label: 'Cargar Archivos S3', icon: 'pi pi-cloud-upload', to: '/ArchivosCargaS3' }
              ]
            },
            {
              label: 'Live', icon: 'pi pi-fw pi-clone',
              items: [
                { label: 'Programación', icon: 'pi pi-fw pi-circle-off', to: 'programming' },
                { label: 'Edición', icon: 'pi pi-fw pi-circle-off', to: '/edition-page' }
              ]
            },
            {
              label: "Digital",
              items: [
                {
                  label: "Cartas de Programacion",
                  icon: "pi pi-fw pi-bookmark",
                  items: [
                    { label: "Todas", icon: "pi pi-fw pi-bars", to: "/carta/canales" },
                    { label: "Uno", icon: "pi pi-fw pi-bars", to: "/carta/uno/" },
                    { label: "Siete", icon: "pi pi-fw pi-bars", to: "/carta/siete/" },
                    { label: "Amas", icon: "pi pi-fw pi-bars", to: "/carta/amas/" },
                    { label: "Adn40", icon: "pi pi-fw pi-bars", to: "/carta/adn40/" },
                  ],
                }
              ]
            },
            {
              label: 'EDITORES', icon: 'pi pi-fw pi-clone',
              items: [
                { label: 'Editor de CuePoints', icon: 'pi pi-video', to: '/ListAsignarCP' },
                { label: 'Editor de Metadata', icon: 'pi pi-desktop', to: '/EditorMedia' }
              ]
            },
            {
              label: 'ADMINISTRACIÓN', icon: 'pi pi-wrench',
              items: [
                { label: 'Monitor de Carga', icon: 'pi pi-sort-alt', to: '/MonitorModule' },
              ]
            },
          ];
    }
}