import axios from 'axios';

//Servicios aL EC2

export class VideoService {

    getVideos() {  
        return axios({
            method: 'GET',
            url:"https://10.126.65.29/vidig-vod/videos",
            //url:"http://localhost:5000/videos",
        }).then(res => res.data);
    }

    getBibliotecaMedia() {  
        return axios({
            method: 'GET',
            //url: url_base+"videos",
            url:"https://10.126.65.29/vidig-vod/biblioteca",
        }).then(res => res.data);
    }

    getVideoId(id_video) {  
        return axios({
            method: 'GET',
            url:"https://10.126.65.29/vidig-vod/videoById/"+id_video,
            
        }).then(res => res.data);
    }


    getProgramas() {  
        return axios({
            method: 'GET',
            url:"https://10.126.65.29/vidig-vod/programas",
            //url:"http://127.0.0.1:5000/programas",
        }).then(res => res.data);
    }

    getAvailsId() {  
        return axios({
            method: 'GET',
            //url:"https://10.126.65.29/vidig-vod/programas",
            url:"https://10.126.65.29/vidig-vod/availsID",
        }).then(res => res.data);
    }

    getProgramaInfo(prg_id) {  
        return axios({
            method: 'GET',
            url:"https://10.126.65.29/vidig-vod/programasInfo/" + prg_id,
        }).then(res => res.data);
        
    }

    
}
