import axios from 'axios';
import config from './EstacionDigitalConfig';

const { urlBase, api } = config;

//Se agregan cabeceras
const options = {
     mode: 'cors',
    headers: {
      'content-type': 'application/json',
      'x-api-key': 'feG2rrGcGjaSXh9Qv3woo7LPBQxjcpKi4IfglZ7S'
    }
}

// obtener info del usuario
export const getUser = async (id) => {
  const data = await axios.get(`${urlBase}${api.user}${id}`, options)
    .then(res => res.data)
    .catch(error => console.log(error));
  return data;
}

// obtener lista de canales
export const getCanales = async () => {
  const data = await axios.get(`${urlBase}${api.canales}`, options)
    .then(res => res.data)
    .catch(error => console.log(error));
  return data;
}

// obtener carta de programación
export const getCarta = async (channel, date) => {
  const data = await axios.get(`${urlBase}${api.carta}id-canal=${channel}&fecha=${date}`, options)
    .then(res => res.data)
    .catch(error => console.log(error));
  return data;
}

// obtener info de un programa específico
export const getPrograma = async (idCarta, user) => {
  const data = await axios.get(`${urlBase}${api.programa}id-carta=${idCarta}&id-user=${user}`, options)
    .then(res => res.data)
    .catch(error => console.log(error));
  return data;
}

// obtener catálogo de media existente
export const getCatalog = async () => {
  const data = await axios.get(`${urlBase}${api.catalog}`, options)
    .then(res => res.data)
    .catch(error => console.log(error));
  return data;
}

// obtener todas las ordenes de bloqueo
export const getAllOrders = async (channel ,fecha) => {

  if(fecha){
    const data = await axios.get(`${urlBase}${api.bloqueos}${channel}&fecha='${fecha}'`, options)
    .then(res => res.data)
    .catch(error => console.log(error));
  return data;

  }else{
    const data = await axios.get(`${urlBase}${api.bloqueos}${channel}`, options)
    .then(res => res.data)
    .catch(error => console.log(error));
  return data;
  }

}

// obtener ordenes de bloqueo filtradas por status
export const getOrdersByStatus = async (channel, status) => {
  const data = await axios.get(`${urlBase}${api.status}?id-canal=${channel}&id-estatus=${status}`, options)
    .then(res => res.data)
    .catch(error => console.log(error));
  return data;
}

// obtener info de una orden de bloqueo específica
export const getOrderID = async (id) => {
  const data = await axios.get(`${urlBase}${api.bloqueoInfo}${id}`, options)
    .then(res => res.data)
    .catch(error => console.log(error));
  return data;
}

// obtener buscar media existente por filtros
export const searchMedia = async (words, date, id, max, min) => {
  const data = await axios.get(`${urlBase}${api.searchMedia}${words ? 'palabras=' + words : ''}${words ? '&' : ''}${date ? 'fecha=' + date : ''}${date ? '&' : ''}${id ? 'prg-id=' + id : ''}${id ? '&' : ''}${max ? 'duracion-maxima=' + max : ''}${max ? '&' : ''}${min ? 'duracion-minima=' + min : ''}`, options)
    .then(res => res.data)
    .catch(error => console.log(error));
  return data;
}

// obtener info de un mediastream
export const searchMediastream = async (id) => {
  const data = await axios.get(`${urlBase}${api.mediastream}${id}`, options)
    .then(res => res.data)
    .catch(error => console.log(error));
  return data;
}

// crear una orden de bloqueo
export const createOrder =  (id, pgr, comment, recurrent) => {
 return axios.put(`${urlBase}${api.actualizarCarta}`, {
    id_carta: id,
    prg_id_sustituto: pgr,
    id_user: '60031395',
    confirmado: true,
    instrucciones: comment,
    prg_recurrente: recurrent
  });
}

// actualizar una orden de bloqueo
export const updateOrder = async (id, newID) => {
  await axios.put(`${urlBase}${api.actualizarBloqueo}`, {
    id_bloqueo: id,
    Comentario: 'El bloqueo ha sido actualizado',
    id_video: newID,
  })
    .then(res => res)
    .catch(error => console.log(error));
}

// guardar cue points asignados a un mediatream específico
export const addCuePoints = async (id, pgr, points,nombre_archivo) => {
  console.log(nombre_archivo)
  const id_ms = nombre_archivo.split(".")
  await axios.put(`${urlBase}${api.cuepoints}`, {
    id_mediastream: id_ms[0],
    prg_id: pgr,
    cue_points: points,
    id_video:id
  })
    .then(res => res)
    .catch(error => console.log(error));
}

// solicitar media de un programa específico
export const requestMedia =  (id_bloqueo, prg_id) => {
  return axios.post(`${urlBase}${api.requestMedia}`, {
    id_bloqueo: id_bloqueo,
    prg_id: prg_id,
  })

}


