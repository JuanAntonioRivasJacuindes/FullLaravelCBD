export default {
  domain: 'https://dgtdy9j9d7.execute-api.us-east-1.amazonaws.com',
        //'https://dgtdy9j9d7.execute-api.us-east-1.amazonaws.com',
  urlBase: 'https://dgtdy9j9d7.execute-api.us-east-1.amazonaws.com/prod/EstacionDigital',
          //'https://dgtdy9j9d7.execute-api.us-east-1.amazonaws.com/prod/EstacionDigital',
  api: {
    // Obtener el usuario
    // Method: GET
    // Params: 60031395
    user: '/Usuario?id-user=',

    // Obtener lista de canales
    // Method: GET
    canales: '/Canal/Catalogo',

    // Obtener el catalogo de programas disponibles
    // Method: GET
    catalog: '/Programa/Catalogo',

    // Obtener la carta de programacion
    // Method: GET
    // Params: ?id-canal=3&fecha=15/10/2022
    carta: '/Carta/Programacion?',

    // Obtener la informacion de un programa de la carta
    // Method: GET
    // Params: id-carta=2022311091&id-user=60031395
    programa: '/Carta/Programa?',

    // Obtener los estatus del video
    // Method: GET
    orderStatus: '/Orden/Estatus',

    // Obtener todos los bloqueos
    // Method: GET
    // Params: ?id-canal=5
    bloqueos: '/Orden/Bloqueos?id-canal=',

    // Obtener los bloqueos por estatus
    // Method: GET
    // Params: ?id-canal=3&id-estatus=0
    status: '/Orden/Bloqueos',

    // Obtener la informacion de un bloqueo
    // Method: GET
    // Params: id-bloqueo=2022313888
    bloqueoInfo: '/Orden/Bloqueo?id-bloqueo=',

    // Buscar una mediastream
    // Method: GET
    // Params: id-mediastream=634445452d9c1d08a1be8a4d
    mediastream: '/Orden/Mediastream?id-mediastream=',

    // Buscar una media existente
    // Method: GET
    // Params: ?fecha=13/10/2022&prg-id=4239&duracion-maxima=00:15:00&duracion-minima=00:30:00
    searchMedia: '/Orden/Media?',

    // Actualizar programa de la carta
    // Method: PUT
    actualizarCarta: '/Carta/Programa',

    // Actualizar un bloqueo
    // Method: PUT
    actualizarBloqueo: '/Orden/Bloqueo',

    // Actualizar cue points
    // Method: PUT
    cuepoints: '/Orden/Mediastream',

    // Solicitar una media nueva
    // Method: POST
    requestMedia: '/Orden/Media',

  }
}
