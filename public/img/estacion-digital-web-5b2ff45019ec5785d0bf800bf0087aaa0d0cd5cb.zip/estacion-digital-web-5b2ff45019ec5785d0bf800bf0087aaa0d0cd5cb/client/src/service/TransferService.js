import axios from 'axios'

const baseUrl = "https://10.126.65.29/vidig-s3-gate/"

export class TransferService {
    getPlutoLoads() {
        return axios.get(baseUrl + "/loader")

    }
    getPlutoLoader(avails_id) {
        return axios.get(baseUrl + "/loader/" + avails_id)

    }
    getPlutoLoad(avails_id, index_id) {
        return axios.get(baseUrl + "/loader/" + avails_id + "/" + index_id)
    }


    getDownloads(){
        return axios.get(baseUrl + "/file/download")
    }
    getLoads(){
        return axios.get(baseUrl + "/playout/load")
    }


}