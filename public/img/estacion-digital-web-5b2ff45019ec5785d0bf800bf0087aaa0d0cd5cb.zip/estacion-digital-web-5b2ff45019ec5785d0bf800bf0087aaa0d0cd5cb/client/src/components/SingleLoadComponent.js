
import React, { useState, useEffect, useRef } from 'react';
import { ProgressBar } from 'primereact/progressbar';
import { TransferService } from '../service/TransferService';

import { Accordion, AccordionTab } from 'primereact/accordion';

const SingleLoadComponent = (vars) => {

    const interval = useRef(null);
    const [loads, setLoads] = useState([])
    const transferService = new TransferService();
    const [activeIndex, setActiveIndex] = useState()

    useEffect(() => {
        let mounted = true
        
        interval.current = setInterval(() => {
            transferService.getLoads()
                .then((res) => {
                    if(mounted){

                       
                        setLoads(res.data.loads)
                    }
                   

                })
                .catch((err) => console.log(err))

        }, 5000);

        return () => {
          
            clearInterval(interval.current)
            mounted = false

        }
    });

    return (

        <Accordion activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>

            {loads.map((key, i) =>
                <AccordionTab key={"acorT" + key.key} header={key.filename}>

                    <div>



                        <h6>Nombre del archivo : {key.filename}</h6>

                        <small>Tamaño: {key.key}</small>
                        <br></br>

                        <small>Status: {key.status}</small>
                        <br></br>
                        <small>Progreso:</small>
                        <ProgressBar key={"singleLo" + key.id} value={key.progress}>d</ProgressBar>
                        <hr>
                        </hr>
                    </div>
                </AccordionTab>


            )}
        </Accordion>

    );
}

export default SingleLoadComponent