import { InputText } from 'primereact/inputtext';
import React from 'react';
import axios from "axios";

class TextComplete extends React.Component {

    constructor(props){
        super (props)
        this.state = {programa: ''}
        this.state ={programs: []}
    }
    
    handleChange=(event)=> {
        this.setState({ programa: event.target.value})
        
      }

    componentDidMount() {
        axios
            .get("https://10.126.65.29/vidig-vod/programas")
            .then(res => {
                const programs = res.data.data;
                //console.log(programs)
                this.setState({ programs });
            })
            .catch(console.log);   
    };

    render() {
        const {handleChange}=this.props
        const {programa}=this.state
        return (
            <div>
                <InputText placeholder="Selecciona un programa" list="list"  value={this.state.value} onChange={this.handleChange} onBlur={()=>handleChange(programa)}></InputText>
                <datalist id="list" >
                    {this.state.programs.map((item) => 
                        <option key={item["prg_id"]} value={item["prg_id"]+ " - " +item["nombre_programa"]} label={item["prg_id"]} ></option>
                    )}
                </datalist>
            </div>
        );
    }
}



export default TextComplete