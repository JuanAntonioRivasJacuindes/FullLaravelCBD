import React from 'react';
import { Link } from 'react-router-dom';
import styles from './header.module.scss';

import StatusGuide from './statusGuide';

const Header = ({ title, backLink, channel, date, day, isEditor }) => {
  const { localStorage } = window;
  // eliminar todos los valores almacenados en localStorage
  const clear = () => {
    localStorage.clear();
  }
  // traducción de nomre del día seleccionado
  let weekday = '';
  if (day === 'MONDAY') {
    weekday = 'LUNES'
  } else if (day === 'TUESDAY') {
    weekday = 'MARTES'
  } else if (day === 'WEDNESDAY') {
    weekday = 'MIÉRCOLES'
  } else if (day === 'THURSDAY') {
    weekday = 'JUEVES'
  } else if (day === 'FRIDAY') {
    weekday = 'VIERNES'
  } else if (day === 'SATURDAY') {
    weekday = 'SÁBADO'
  } else if (day === 'SUNDAY') {
    weekday = 'DOMINGO'
  }
  return (
    <div className={styles.header}>
      <div className={styles.headerTop}>
        <h3>{title}</h3>
        <Link to={backLink} className={styles.headerBack} onClick={clear}>
          <span>REGRESAR A SELECCIÓN</span>
          <i className="pi pi-angle-right" />
        </Link>
      </div>
      <div className={styles.headerBottom}>
        <div className={styles.headerInfo}>
          {date ? <span>{`${channel} - ${weekday} ${date}`}</span> : <span>{channel}</span>}
        </div>
        <StatusGuide role={isEditor ? 'editor' : 'planner'} />
      </div>
    </div>
  );
};

export default Header;

