import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { Button } from 'primereact/button';
import styles from './confirmMedia.module.scss';

import Completed from './completed';
import { createOrder } from '../../service/EstacionDigitalServices';

const ConfirmMedia = () => {
  const { localStorage } = window;
  const [completed, setCompleted] = useState(false);
  const channel = localStorage.getItem('channelName');
  const date = localStorage.getItem('selectedDate');
  const allRecurrent = localStorage.getItem('allRecurrent');
  const toConfirm = JSON.parse(localStorage.getItem('toConfirm'));
  const history = useHistory();
  // crear orden de bloqueo por cada bloque seleccionado e indicar proceso finalizado
  const onSubmit = () => {
    // detectar si hay solicitud de recurrencia
    const recurrent = allRecurrent === 'true' ? true : false;
    toConfirm.forEach(item => {
      createOrder(item.id_carta, item.prg_id_sustituto, '', recurrent);
    });
    setCompleted(true);
  };
  // eliminar la lista de programas seleccionados y regresar a la carta de programación
  const goBack = () => {
    localStorage.removeItem('toConfirm');
    localStorage.removeItem('allRecurrent');
    history.push('/schedule');
  };
  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h3>CONFIRMAR PROGRAMACIÓN</h3>
        <div className={styles.headerInfo}>
          <div>
            <b>Canal:</b>
            <p>{channel}</p>
          </div>
          <div>
            <b>Fecha:</b>
            <p>{date}</p>
          </div>
        </div>
      </div>
      <div className={styles.blockInfo}>
        {toConfirm.map((item, key) => (
          <div key={key}>
            <p>{`${item?.prg_id_sustituto} - ${item?.programa_sustituto}`}</p>
          </div>
        ))}
      </div>
      {!completed && (
        <div className={styles.button}>
          <Button label="Cancelar" onClick={goBack} />
          <Button label="Asignar" onClick={onSubmit} />
        </div>
      )}
      {completed && <Completed />}
    </div>
  );
};

export default ConfirmMedia;
