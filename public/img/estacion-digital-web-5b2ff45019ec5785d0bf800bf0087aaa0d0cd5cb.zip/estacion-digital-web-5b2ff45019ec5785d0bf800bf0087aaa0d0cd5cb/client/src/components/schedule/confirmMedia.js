import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { Button } from 'primereact/button';
import styles from './confirmMedia.module.scss';

import Completed from './completed';
import { getPrograma, createOrder } from '../../service/EstacionDigitalServices';

const ConfirmMedia = () => {
  const { localStorage } = window;
  const [completed, setCompleted] = useState(false);
  const channel = localStorage.getItem('channelName');
  const date = localStorage.getItem('selectedDate');
  const blockStart = localStorage.getItem('blockStart');
  const blockEnd = localStorage.getItem('blockEnd');
  const selectedBlock = localStorage.getItem('selectedBlock');
  const replacementID = localStorage.getItem('replacementID');
  const replacementName = localStorage.getItem('replacementName');
  const comment = localStorage.getItem('comment');
  const singleRecurrent = localStorage.getItem('singleRecurrent');
  const [programOriginal, setProgramOriginal] = useState('');
  // obtener información del programa seleccionado
  useEffect(() => {
    async function getData() {
      setProgramOriginal(await getPrograma(selectedBlock, '60031395'));
    }
    getData();
  }, [selectedBlock]);
  const history = useHistory();
  // crear orden de bloqueo e indicar proceso finalizado
  const onSubmit = () => {
    // enviar string vación si no se registraron indicaciones para el bloqueo
    const indicaciones = comment !== null ? comment : '';
    // detectar si hay solicitud de recurrencia
    const recurrent = singleRecurrent === 'true' ? true : false;
    // si no hay is de programa sustituto, usar el original
    if (replacementID === null) {
      createOrder(selectedBlock, programOriginal?.prg_id_original, indicaciones, recurrent)
      // enviar id del programa sustituto
    } else {
      createOrder(selectedBlock, replacementID, indicaciones, recurrent)
    }
    setCompleted(true);
  };
  // eliminar todos los valores que requieren ser resetados y regresar a la carta de programación
  const goBack = () => {
    localStorage.removeItem('blockStart');
    localStorage.removeItem('blockEnd');
    localStorage.removeItem('selectedBlock');
    localStorage.removeItem('replacementID');
    
    localStorage.removeItem('replacementName');
    localStorage.removeItem('comment');
    localStorage.removeItem('singleRecurrent');
    history.push('/schedule');
  };
  // Condición para habilitar el botón de asignar
  const allowContinue = programOriginal && programOriginal.prg_descripcion_original && programOriginal.prg_id_original;
  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h3>CONFIRMAR ORDEN DE BLOQUEss</h3>
        <div className={styles.headerInfo}>
          <div>
            <b>Canal:</b>
            <p>{channel}</p>
          </div>
          <div>
            <b>Fecha:</b>
            <p>{date}</p>
          </div>
          <div>
            <b>Horario:</b>
            <p>{`${blockStart} - ${blockEnd}`}</p>
          </div>
        </div>
      </div>
      <div className={styles.blockInfo}>
        <div>
          <b>Programa:</b>
          <p>{programOriginal?.prg_descripcion_original}</p>
        </div>
        <div>
          <b>ID:</b>
          <p>{programOriginal?.prg_id_original}</p>
        </div>
      </div>
      {(replacementID && replacementName) && <div className={styles.icon}>
        <i className="pi pi-chevron-right" />
      </div>}
      {(replacementID && replacementName) && <div className={styles.mediaInfo}>
        <div>
          <b>Programa:</b>
          <p>{replacementName}</p>
        </div>
        <div>
          <b>ID:</b>
          <p>{replacementID}</p>
        </div>
        {comment && comment !== '' && (
          <div>
            <b>Indicaciones:</b>
            <p>{comment}</p>
          </div>
        )}
      </div>}
      {!completed && (
        <div className={styles.button}>
          <Button label="Cancelar" onClick={goBack} />
          <Button label="Asignar" onClick={onSubmit} disabled={!allowContinue} />
        </div>
      )}
      {completed && <Completed />}
    </div>
  );
};

export default ConfirmMedia;
