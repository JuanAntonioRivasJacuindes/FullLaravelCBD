import React from 'react';
import { useHistory } from 'react-router-dom';
import { Button } from 'primereact/button';
import styles from './completed.module.scss';

const Completed = () => {
  const history = useHistory();
  // obtener role del usuario
  const isEditor = localStorage.getItem('isEditor')
  // eliminar todos los valores que requieren ser resetados
  localStorage.removeItem('blockStart');
  localStorage.removeItem('blockEnd');
  localStorage.removeItem('selectedBlock');
  localStorage.removeItem('selectedOrder');
  localStorage.removeItem('replacementID');
  localStorage.removeItem('replacementName');
  localStorage.removeItem('comment');
  localStorage.removeItem('videoID');
  localStorage.removeItem('orderDate');
  localStorage.removeItem('orderPgrName');
  localStorage.removeItem('orderPgrID');
  localStorage.removeItem('orderDuration');
  localStorage.removeItem('orderMinDuration');
  localStorage.removeItem('orderMaxDuration');
  localStorage.removeItem('orderComments');
  localStorage.removeItem('msName');
  localStorage.removeItem('msDuration');
  localStorage.removeItem('msVideoID');
  localStorage.removeItem('cuePoints');
  localStorage.removeItem('toConfirm');
  localStorage.removeItem('singleRecurrent');
  // regresar a la lista de ordenes acorde al role del usuario
  const goBack = () => {
    // const roleRoute = isEditor === 'true' ? '/edition-page' : '/schedule';
    history.push("/edition-page");
  };
  return (
    <div className={styles.completed}>
      <div>
        <i className="pi pi-check-circle" />
        <p>ORDEN COMPLETADA</p>
      </div>
      <div>
        <Button label="Finalizar" onClick={goBack} />
      </div>
    </div>
  );
}

export default Completed;
