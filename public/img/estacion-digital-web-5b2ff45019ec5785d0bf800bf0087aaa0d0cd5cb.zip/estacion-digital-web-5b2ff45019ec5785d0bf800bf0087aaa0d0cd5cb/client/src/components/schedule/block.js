import React, { useState } from 'react';
import { Checkbox } from 'primereact/checkbox';
import styles from './block.module.scss';

const Block = ({ item, selected, setSelected, toConfirm, setToConfirm }) => {
  const { localStorage } = window;
  const [itemIsChecked, setItemIsChecked] = useState(false);
  // desabilitar la opción de selección de un bloque cuando otro ya ha sido seleccionado
  const showAsDisabled = (selected !== '' && selected !== item?.id_carta) || itemIsChecked;
  // ocultar la opción de editar cuando se ha seleccionado la opción de confirmar
  const showEditOption = toConfirm.length === 0;
  // ocultar la opción de confirmar cuando se ha seleccionado la opción de editar o el bloqueo viene ya como confirmado
  const showConfirmOption = !item?.confirmado && selected === '';
  // manejear opción de editar
  const handleEditCheck = () => {
    // no no hay selección, o la selección es diferente a la actual
    if (selected === '' || selected !== item?.id_carta) {
      setSelected(item?.id_carta)
      localStorage.setItem('selectedBlock', item?.id_carta);
      // remover si la opción está seleccionada
    } else if (selected === item?.id_carta) {
      setSelected('')
      localStorage.removeItem('selectedBlock');
    }
  };
  // agregar a la lista de bloques a confirmar
  const addItem = (id) => {
    setToConfirm(prev => [...prev, id])
  }
  // eliminar de la lista de bloques a confirmar
  const removeItem = (id) => {
    setToConfirm(prev => prev.filter(i => i !== id))
  }
  // manejat selección de items a confirmar
  const handleConfirmCheck = (id) => {
    // si el bloque está seleccionado, retirar selección
    if (itemIsChecked) {
      removeItem(id)
      setItemIsChecked(false);
      // agregar bloque seleccionado a la lista
    } else {
      addItem(id)
      setItemIsChecked(true);
    }
  };
  // cambiar color del bloque acorde a su status
  let statusBg = 'var(--gray-100)'
  if (item?.confirmado) {
    statusBg = 'var(--cyan-100)'
  }
  // detectar si el programa sustituto es diferente al original ya designado
  const hasReplacement = item?.prg_id !== item?.prg_id_sustituto && item?.programa !== item?.programa_sustituto
  // mostrar id sustituto si es diferente al original
  const showID = item?.prg_id === item?.prg_id_sustituto ? item?.prg_id : item?.prg_id_sustituto;
  // mostrar título sustituto si es diferente al original
  const showTitle = item?.programa === item?.programa_sustituto ? item?.programa : item?.programa_sustituto;
  return (
    <div className={`${styles.container} ${showAsDisabled ? styles.showAsDisabled : ''}`}
      style={{ backgroundColor: statusBg }}>
      <div className={styles.header}>
        <p className={styles.time}>{`${item?.hora_inicio} - ${item?.hora_final} (Duración: ${item?.duracion})`}</p>
        <div className={styles.labels}>
          {showConfirmOption && (
            <label className={styles.label}>
              <span>Confirmar</span>
              <Checkbox value="confirm" onChange={() => handleConfirmCheck(item)} checked={itemIsChecked} disabled={selected !== ''} />
            </label>
          )}
          {showEditOption && (
            <label className={styles.label}>
              <span>Editar</span>
              <Checkbox value="id" onChange={handleEditCheck} checked={selected === item?.id_carta} disabled={showAsDisabled} />
            </label>
          )}
        </div>
      </div>
      <div className={styles.info}>
        <p>{`${showID === 0 ? 'SIN ID' : showID} - ${showTitle === '' ? 'SIN PROGRAMA' : showTitle}`}</p>
        {hasReplacement && <p>{`Original: ${item?.prg_id} - ${item?.programa}`}</p>}
        {item?.prg_recurrente && (
          <div className={styles.recurrent}>
            <i className="pi pi-refresh" />
            <span>Bloqueo recurrente</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default Block;
