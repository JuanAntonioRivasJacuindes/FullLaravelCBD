import React from 'react';
import { Checkbox } from 'primereact/checkbox';
import styles from './block.module.scss';

const Block = ({ item, selected, setSelected }) => {
  const { localStorage } = window;
  // desabilitar los bloques que no estén seleccionados
  const showAsDisabled = selected !== '' && selected !== item?.id_bloqueo;
  // manejar selección de bloques
  const handleCheck = () => {
    // si no hay selección o es diferente a la actual, asignar la selección más reciente y guardar valores
    if (selected === '' || selected !== item?.id_bloqueo) {
      setSelected(item?.id_bloqueo)
      localStorage.setItem('selectedOrder', item?.id_bloqueo)
      localStorage.setItem('orderDate', item?.fecha)
      // si el bloque está seleccionado, remover selección y remover valores
    } else if (selected === item?.id_bloqueo) {
      setSelected('')
      localStorage.removeItem('selectedOrder')
      localStorage.removeItem('orderDate')
    }
  };
  // asignar color del bloque acorde a su status
  let statusBg = 'var(--gray-100)'
  if (item?.id_estatus === 0) {
    statusBg = 'var(--gray-100)'
  } else if (item?.id_estatus === 1) {
    statusBg = 'var(--yellow-100)'
  } else if (item?.id_estatus === 2) {
    statusBg = 'var(--orange-100)'
  } else if (item?.id_estatus === 3) {
    statusBg = 'var(--green-100)'
  } else if (item?.id_estatus === 4) {
    statusBg = 'var(--pink-100)'
  }
  return (
    <div className={`${styles.container} ${showAsDisabled ? styles.showAsDisabled : ''}`}
      style={{ backgroundColor: statusBg }}>
      <div className={styles.header}>
        <p className={styles.time}>{`${item?.fecha} - Duración: ${item?.duracion}`}</p>
        <label className={styles.label}>
          <span>Seleccionar</span>
          <Checkbox value="id" onChange={handleCheck} checked={selected === item?.id_bloqueo} disabled={showAsDisabled} />
        </label>
      </div>
      <div className={styles.info}>
        <p>{`${item?.id_video !== '' ? item?.id_video : 'SIN ID'} - ${item?.programa_sustituto}`}</p>
      </div>
    </div>
  );
};

export default Block;
