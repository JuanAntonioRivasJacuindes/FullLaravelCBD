import React from 'react';
import styles from './statusGuide.module.scss';

const StatusGuide = ({ role }) => (
  <div className={styles.statusGuide}>
    <div className={styles.statusGuideButton}>
      <span>Guía de status</span>
      <i className="pi pi-info-circle" />
    </div>
    <div className={styles.statusGuideContent}>
      <div className={styles.statusGuideInnerContent}>
        {role === 'editor' ? (
          <>
            <div>
              <span style={{ backgroundColor: 'var(--gray-200)' }} />
              <p>Bloqueo sin media</p>
            </div>
            <div>
              <span style={{ backgroundColor: 'var(--yellow-200)' }} />
              <p>Bloqueo en proceso</p>
            </div>
            <div>
              <span style={{ backgroundColor: 'var(--orange-200)' }} />
              <p>Advertencia en media</p>
            </div>
            <div>
              <span style={{ backgroundColor: 'var(--green-200)' }} />
              <p>Bloqueo completado</p>
            </div>
            <div>
              <span style={{ backgroundColor: 'var(--pink-200)' }} />
              <p>Error en procesamiento</p>
            </div>
          </>
        ) : (
          <>
            <div>
              <span style={{ backgroundColor: 'var(--gray-200)' }} />
              <p>Sin confirmación</p>
            </div>
            <div>
              <span style={{ backgroundColor: 'var(--cyan-200)' }} />
              <p>Confirmado</p>
            </div>
          </>
        )}
      </div>
    </div>
  </div>
);

export default StatusGuide;
