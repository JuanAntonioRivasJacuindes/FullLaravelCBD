import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { Button } from 'primereact/button';
import styles from './confirmMedia.module.scss';

import Completed from './completed';
import { updateOrder } from '../../service/EstacionDigitalServices';

const ConfirmMedia = (props) => {
  const { localStorage } = window;

  const [completed, setCompleted] = useState(false);
  const selectedOrder = parseFloat(localStorage.getItem('selectedOrder'));
  const orderDate = localStorage.getItem('orderDate');
  const msVideoID = localStorage.getItem('videoID');
  const [loading, setLoading] = useState(false);
  const cuePoints = JSON.parse(localStorage.getItem('cuePoints'));
  const channelName = localStorage.getItem('channelName');
  const orderPgrName = localStorage.getItem('orderPgrName');
  const orderPgrID = localStorage.getItem('orderPgrID');
  const orderDuration = localStorage.getItem('orderDuration');
  const orderComments = localStorage.getItem('orderComments');
  const msName = localStorage.getItem('msName');
  const msDuration = localStorage.getItem('msDuration');

  // eliminar todos los valores que requieren ser resetados y regresar a la lista de bloqueos

  // actualizar la orden e indicar proceso finalizado
  const onSubmit = () => {
    setLoading(true);
    updateOrder(selectedOrder, msVideoID).
    then(()=>{
      setLoading(false);
      props.updateOrderSuccess()
    });

  };
  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h3>CONFIRMAR BLOQUEO</h3>
        <div className={styles.headerInfo}>
          <div>
            <b>Canal:</b>
            <p>{channelName}</p>
          </div>
          <div>
            <b>Fecha:</b>
            <p>{orderDate}</p>
          </div>
          <div>
            <b>Orden:</b>
            <p>{selectedOrder}</p>
          </div>
        </div>
      </div>

      <div className={styles.mediaInfo}>
        <div>
          <b>Programa:</b>
          <p>{orderPgrName}</p>
        </div>
        <div>
          <b>Programa ID:</b>
          <p>{orderPgrID}</p>
        </div>
        <div>
          <b>Duración del bloqueo:</b>
          <p>{orderDuration}</p>
        </div>
        <div>
          <b>Indicaciones:</b>
          <p>{orderComments}</p>
        </div>
      </div>


      <div className={styles.icon}>
        <i className="pi pi-chevron-right" />
      </div>

      <div className={styles.blockInfo}>
        <div>
          <b>Título:</b>
          <p>{msName}</p>
        </div>
        <div>
          <b>ID:</b>
          <p>{msVideoID}</p>
        </div>
        <div>
          <b>Duración:</b>
          <p>{`${msDuration} segundos`}</p>
        </div>
        <div>
          <b>Cue Points:</b>
          <p>
            {cuePoints?.map((item, key) => (
              <span key={key}>{`${item}${key + 1 === cuePoints.length ? '' : ' - '}`}</span>
            ))}
          </p>
        </div>
      </div>

      {!completed && (
        <div className={styles.button}>
          <Button  label="Asignar" onClick={onSubmit} loading={loading} />
        </div>
      )}

    </div>
  );
};

export default ConfirmMedia;
