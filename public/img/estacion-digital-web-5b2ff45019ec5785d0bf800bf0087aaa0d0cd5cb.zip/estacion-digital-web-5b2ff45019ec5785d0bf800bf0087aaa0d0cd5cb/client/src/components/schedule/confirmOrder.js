import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { Button } from 'primereact/button';
import styles from './confirmMedia.module.scss';

import Completed from './completed';
import { updateOrder } from '../../service/EstacionDigitalServices';

const ConfirmMedia = (props) => {
  const { localStorage } = window;
  const [completed, setCompleted] = useState(false);
  const [loading, setLoading] = useState(false);
  const channel = localStorage.getItem('channelName');
  const selectedOrder = parseFloat(localStorage.getItem('selectedOrder'));
  const orderDate = localStorage.getItem('orderDate');
  const videoID = localStorage.getItem('videoID');
  const orderPgrName = localStorage.getItem('orderPgrName');
  const orderPgrID = localStorage.getItem('orderPgrID');
  const history = useHistory();
  // eliminar todos los valores que requieren ser resetados y regresar a la lista de bloqueos

  // actualizar orden e indicar proceso finalizado
  const onSubmit = () => {
    setLoading(true);
    updateOrder(selectedOrder, videoID).
    then(()=>{
      setLoading(false);
      props.updateOrderSuccess()
    });

  };
  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h3>CONFIRMAR ORDEN DE BLOQUEO</h3>
        <div className={styles.headerInfo}>
          <div>
            <b>Canal:</b>
            <p>{channel}</p>
          </div>
          <div>
            <b>Fecha:</b>
            <p>{orderDate}</p>
          </div>
          <div>
            <b>Orden:</b>
            <p>{selectedOrder}</p>
          </div>
        </div>
      </div>
      <div className={styles.blockInfo}>
        <div>
          <b>Video ID:</b>
          <p>{videoID}</p>
        </div>
        <div>
          <b>Programa:</b>
          <p>{orderPgrName}</p>
        </div>
        <div>
          <b>Programa ID:</b>
          <p>{orderPgrID}</p>
        </div>
      </div>

      {!completed && (
        <div className={styles.button}>
         
          <Button  label="Asignar" onClick={onSubmit} loading={loading} />
        </div>
      )}
    
    </div>
  );
};

export default ConfirmMedia;
