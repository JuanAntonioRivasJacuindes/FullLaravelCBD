import React from 'react';
import styles from './planning.module.scss';

import Header from './header';
import Block from './block';

const List = ({ data, selected, setSelected, selectedForConfirmation, toConfirm, setToConfirm }) => {
  return (
    <div className={styles.list}>
      {data?.map((item, key) => <Block item={item} key={key} selected={selected} setSelected={setSelected} selectedForConfirmation={selectedForConfirmation} toConfirm={toConfirm} setToConfirm={setToConfirm} />)}
    </div>
  );
}

const Planning = ({ data, channel, date, day, selected, setSelected, toConfirm, setToConfirm }) => {
  const title = 'CARTA DE PROGRAMACIÓN';
  const backLink = '/select';
  return (
    <div className={styles.container}>
      <Header title={title} backLink={backLink} channel={channel} date={date} day={day} />
      {data && data.length ? <List data={data} selected={selected} setSelected={setSelected} toConfirm={toConfirm} setToConfirm={setToConfirm} /> : <p>No hay programación</p>}
    </div>
  );
};

export default Planning;
