import React from 'react';
import styles from './monitoring.module.scss';

import Header from './header';
import Block from './blockEditor';

const List = ({ data, selected, setSelected }) => {
  return (
    <div className={styles.list}>
      {data?.map((item, key) => <Block item={item} key={key} selected={selected} setSelected={setSelected} />)}
    </div>
  );
};

const Monitoring = ({ data, channel, selected, setSelected, isEditor }) => {
  const title = 'ORDENES DE BLOQUEO';
  const backLink = '/select-editor';
  return (
    <div className={styles.container}>
      <Header title={title} backLink={backLink} channel={channel} isEditor={isEditor} />
      <List data={data} selected={selected} setSelected={setSelected} />
    </div>
  );
};

export default Monitoring;
