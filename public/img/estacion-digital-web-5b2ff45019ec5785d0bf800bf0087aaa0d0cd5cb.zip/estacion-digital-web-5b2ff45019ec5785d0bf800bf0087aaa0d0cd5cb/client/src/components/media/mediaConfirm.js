import React from 'react';
import { useHistory } from 'react-router-dom';
import styles from './mediaConfirm.module.scss';

import { Button } from 'primereact/button';


const MediaConfirm = ({ toConfirm }) => {
  const { localStorage } = window;
  const history = useHistory();
  // obtener y almacenar en array de objetos la lista de programas a  confirmar 
  const getData = toConfirm.map(item => {
    // si no hay un sustituto definido,  tomar el original
    const id = item?.prg_id_sustituto === 0 ? item?.prg_id : item?.prg_id_sustituto;
    const name = item?.prg_id_sustituto === 0 ? item?.programa : item?.programa_sustituto;
    return (
      {
        id_carta: item.id_carta,
        prg_id_sustituto: id,
        programa_sustituto: name,
      }
    );
  });
  
  // comenzar proceso de confirmación
  const onSubmit = () => {
    // guardar lista de programas a confirmar
    localStorage.setItem('toConfirm', JSON.stringify(getData));
    // guardar posición de scroll actual
    localStorage.setItem('scrollPosition', window.pageYOffset);
    // redirigir a confirmación
    history.push('/confirmation-multiple');
  }
  return (
    <div className={styles.container}>
      <h4>Programas a confirmar</h4>
      <div className={styles.content}>
        {toConfirm.map((item, key) => (
          <div key={key} className={styles.item}>
            <p>{`${item?.prg_id_sustituto === 0 ? item?.prg_id : item?.prg_id_sustituto} - ${item?.prg_id_sustituto === 0 ? item?.programa : item?.programa_sustituto}`}</p>
          </div>
        ))}
        <div className={styles.button}>
          <Button label="Confirmar" onClick={onSubmit} />
        </div>
      </div>
    </div>
  );
};

export default MediaConfirm;
