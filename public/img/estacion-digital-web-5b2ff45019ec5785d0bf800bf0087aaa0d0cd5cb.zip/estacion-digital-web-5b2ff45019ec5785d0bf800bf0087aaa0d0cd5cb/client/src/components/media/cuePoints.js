import React, { useState } from 'react';
import { InputMask } from 'primereact/inputmask';
import { Button } from 'primereact/button';
import styles from './cuePoints.module.scss';
//intent de subida

export const CuePointInput = ({ addCuePoint, setCuePointInput }) => {
  const [item, setItem] = useState('');
  // agregar cue point a la lista y ocultar el input al gurdarlo
  const handleCuePoint = () => {
    addCuePoint(item);
    setCuePointInput(false);
  };
  return (
    <div className={styles.cueInput}>
      <label>
        <InputMask mask="99:99:99;99" value={item} onChange={(e) => setItem(e.target.value)} placeholder="00:00:00;00" />
      </label>
      <Button label="Salvar" onClick={handleCuePoint} disabled={item === ''} />
    </div>
  );
};

export const CuePoint = ({ item, index, removeCuePoint, duration, minutesToSeconds }) => {
  // eliminar milñesimas de segundo para el cálculo del límite
  const cleanItem = item.replace(/(;\d\d)/, '');
  // se convierte el valor del cue point a segundos
  const cuePointSeconds = minutesToSeconds(cleanItem);
  // se compara con la duración de la media para determinar si excede o no el límite
  let limit = false
  if (cuePointSeconds > duration) {
    limit = true;
  }
  return (
    <div className={styles.cuePoint}>
      <div className={limit ? styles.cuePointRed : ''}>
        <b>Cue Point {index + 1}</b>
        <p>{` - ${item}`}</p>
      </div>
      {limit && <div className={styles.cuePointAlert}>Este Cue Point excede el tiempo de duración de la media.</div>}
      <button type="button" onClick={() => removeCuePoint(item)} className={styles.cueButton}>
        <i className="pi pi-trash" />
        <span>eliminar</span>
      </button>
    </div>
  );
};
