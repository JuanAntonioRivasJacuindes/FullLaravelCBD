import React, { useState, useEffect, useRef } from 'react';
import { Button } from 'primereact/button';
import { ConfirmPopup } from 'primereact/confirmpopup';
import { requestMedia } from '../../service/EstacionDigitalServices';
import { Toast } from 'primereact/toast';
const NewMedia = (props) => {

    const toast = useRef(null);
    const [videoId, setVideoId] = useState("hehe")
    const [visible, setVisible] = useState(false);
    const [buttonDisable, setButtonDisable] = useState(false)
    const [endButtonStatus, setEndButtonStatus] = useState(true)
    const copyText = () => {


        navigator.clipboard.writeText(videoId)
        toast.current.show({ severity: 'success', summary: 'Hecho', detail: 'Se ha copiado el texto en el portapapeles .', life: 3000 });

    }
    const solicitarId = () => {

        requestMedia(props.id_bloqueo, props.prg_id)
            .then((res) => {
                toast.current.show({ severity: 'success', summary: 'Hecho', detail: 'Se ha asignado el nuevo ID .', life: 3000 });
                setVideoId(res.data['id_video'])
                setButtonDisable(true)
                setEndButtonStatus(false)
            })
            .catch(error => alert(error));
            // setTimeout(() => {
            //     document.location.reload();
            //   }, 2000);



    }

    useEffect(() => {

        setVideoId(props.videoId)
    }, []);
    return (
        <div >
            <Toast ref={toast} />
            <strong>Media Nueva</strong >
            <h5>ID de programa : {props.prg_id}</h5>
            <h5>ID de video : {videoId} <Button onClick={copyText} icon="pi pi-copy" className="p-button-rounded p-button-text" aria-label="copy" /></h5>
            <ConfirmPopup target={document.getElementById('button')} visible={visible} onHide={() => setVisible(false)} message="¿Desea asignar un nuevo ID?"
                icon="pi pi-exclamation-triangle" accept={solicitarId} />
            <Button id="button" disabled={buttonDisable} onClick={() => setVisible(true)} label="Asignar nueva media" />
            <br/>
            <Button id="buttonEnd" disabled={endButtonStatus} onClick={() => props.updateOrderSuccess()} label="Finalizar" />

        </div>
    );
};

export default NewMedia;
