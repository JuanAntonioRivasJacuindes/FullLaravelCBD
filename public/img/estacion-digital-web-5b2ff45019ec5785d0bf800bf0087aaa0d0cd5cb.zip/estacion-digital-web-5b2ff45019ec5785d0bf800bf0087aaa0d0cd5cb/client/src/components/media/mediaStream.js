import React, { useState, useEffect } from 'react';

import { Button } from 'primereact/button';
import styles from './mediaStream.module.scss';
import BuscadorMediaStream from '../BuscadorMediaStream';
import { searchMediastream, addCuePoints } from '../../service/EstacionDigitalServices';
import PlayFront from '../Player';
import Confirm from '../schedule/confirmOrder';

import ConfirmOrder from '../schedule/confirmCuePoints';
const Info = ({ data, setVideoIDms }) => {


  const { bitrate, duration, id_video, nombre, nombre_archivo, type, cue_points } = data;

  // convertir en array los cue points asignados
  const cuePoints = cue_points.split();
  // dar formato 00:00:00 a la duración
  const durationFormat = `${(duration / 60 / 60 | 0) <= 9 ? '0' : ''}${duration / 60 / 60 | 0}:${(duration / 60 % 60 | 0) <= 9 ? '0' : ''}${duration / 60 % 60 | 0}:${(duration % 60) <= 9 ? '0' : ''}${duration % 60}`;
  // guardar duraciín mínima y máxima
  const orderMinDuration = localStorage.getItem('orderMinDuration');
  const orderMaxDuration = localStorage.getItem('orderMaxDuration');
  // guardar valores del mediastream
  if (data) {

    localStorage.setItem('msVideoID', id_video);
    localStorage.setItem('videoID', id_video);
    localStorage.setItem('msName', nombre);
    localStorage.setItem('msDuration', durationFormat);
  }
  // convertir minutos a segundos para comparar el medistream contra la duración del bloque
  const minutesToSeconds = (value) => {
    const arr = value?.split(':');
    const arrInts = arr?.map(item => parseFloat(item));
    const seconds = arrInts[2];
    const minutes = arrInts[1] * 60;
    const hours = (arrInts[0] * 60) * 60;
    const total = hours + minutes + seconds;
    return total;
  }
  // detectar si duración del media stream es mayor o menor al tiempo del bloqueo y mostrar advertencia cprrespondiente
  const minDurationWarning = duration < minutesToSeconds(orderMinDuration);
  const maxDurationWarning = duration > minutesToSeconds(orderMaxDuration);
  let warningText = '';
  if (minDurationWarning) {
    warningText = 'La duración de esta media es menor a lo requerido'
  } else if (maxDurationWarning) {
    warningText = 'La duración de esta media es mayor a lo requerido'
  }
  return (
    <div className={styles.block}>
      <div className={`${styles.blockContent} ${minDurationWarning || maxDurationWarning ? styles.blockContentWarning : ''}`}>
        <div className={styles.blockInfo}>
          <div>
            <b>Video ID:</b>
            <p>{id_video}</p>
          </div>
          <div>
            <b>Nombre:</b>
            <p>{nombre}</p>
          </div>
          <div>
            <b>Archivo:</b>
            <p>{nombre_archivo}</p>
          </div>
          <div>
            <b>Formato:</b>
            <p>{type}</p>
          </div>
          <div>
            <b>Duración:</b>
            <p>{durationFormat}</p>
          </div>
          <div>
            <b>Bitrate:</b>
            <p>{bitrate}</p>
          </div>
          <div>
            <b>Cue Points:</b>
            <p>
              {cuePoints?.map((item, key) => (
                <span key={key}>{`${item}${key + 1 === cuePoints.length ? '' : ' - '}`}</span>
              ))}</p>
          </div>
          {(minDurationWarning || maxDurationWarning) ? (
            <div className={styles.warningDuration}>
              <i className="pi pi-exclamation-circle" />
              <p>{warningText}</p>
            </div>
          ) : ''}
        </div>
      </div>

    </div>
  );
};




const MediaStream = (props) => {

  const [msId, setMsId] = useState('');
  const orderPgrID = parseFloat(localStorage.getItem('orderPgrID'));
  const [videoIDms, setVideoIDms] = useState('');
  const [searchResult, setSearchResult] = useState(null);
  // obtener información del id mediatream ingresado en la búsqueda
  const handleSearch = async (value) => {
    setSearchResult(await searchMediastream(value));

  };


  const callback = (data) => {

    if (data) {
      props.changeButtonStatus(false)
      localStorage.setItem('msVideoID', data['_id']);
      localStorage.setItem('videoID', searchResult.id_video);

      setMsId(data['_id'])
    } else {
      props.changeButtonStatus(true)
    }
  }

  useEffect(() => {
    if (searchResult) {

      if (searchResult.id_video) {

        props.setConfirmationTab(
          <div>

            <Confirm updateOrderSuccess={props.updateOrderSuccess} />
          </div>

        )

        props.setVerificationTab(

          <div>
            {searchResult !== null && <Info data={searchResult} onSaveCuePoints={onSaveCuePoints} cuePointsExist={cuePointsExist} setVideoIDms={setVideoIDms} />}
            {console.log(searchResult.cue_points)}
            {searchResult && <PlayFront tipo={false} actualiza={true} cuePoints={searchResult.cue_points} nombre_archivo={searchResult.nombre_archivo} id_video={searchResult.id_video}></PlayFront>}
            <Button onClick={() => { props.changeButtonStatus(false) }} >Aceptar</Button>
          </div>

        )
      } else {
        props.setConfirmationTab(
          <div>
            <ConfirmOrder  updateOrderSuccess={props.updateOrderSuccess} />
          </div>
        )
        searchResult.id_video = Date.now()


        props.setVerificationTab(
          <div>
            
            {searchResult !== null && <Info data={searchResult} onSaveCuePoints={onSaveCuePoints} cuePointsExist={cuePointsExist} setVideoIDms={setVideoIDms} />}
            {searchResult && <PlayFront tipo={true} actualiza={false} passData={onSaveCuePoints} cuePoints="" nombre_archivo={searchResult.nombre_archivo} id_video={searchResult.nombre_archivo.replace('.mp4', "")}></PlayFront>}

          </div>
        )
      }
    }


  }, [searchResult]);

  useEffect(() => {
    handleSearch(msId)
  }, [msId]);
  // guardar la lista de cue points ingresados
  const onSaveCuePoints = (cuePoints) => {
    const points = JSON.stringify(cuePoints)
    // petición para gardar cue points en D    
    addCuePoints(searchResult.id_video, orderPgrID, cuePoints, searchResult['nombre_archivo']);
    // guardar la longitud del array de cue points

    // salvar la lista de cue points y id del video en localStorage
    localStorage.setItem('msVideoID', videoIDms);
    localStorage.setItem('cuePoints', points)
    // habilitar botón para guardar los cue points

    props.changeButtonStatus(false)
  };


  const formatCuePoints = (points) => {
    const formated = JSON.parse(points);
    return formated;
  };
  // detectar si la medistream tiene cue points previamente asignados
  const cuePointsExist = searchResult !== null && searchResult?.cue_points && searchResult?.cue_points !== '[]';
  return (

    <div >
      <BuscadorMediaStream passData={callback}></BuscadorMediaStream>
    </div>
  );
};

export default MediaStream;
// 
