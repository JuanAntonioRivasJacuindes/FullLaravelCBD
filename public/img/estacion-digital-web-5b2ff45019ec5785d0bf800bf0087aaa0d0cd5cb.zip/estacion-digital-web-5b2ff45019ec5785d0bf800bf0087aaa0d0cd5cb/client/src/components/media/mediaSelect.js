import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { RadioButton } from "primereact/radiobutton";
import styles from './mediaSelect.module.scss';

import MediaDefault from './mediaDefault';
import MediaLibrary from './mediaLibrary';

const sources = ['Confirmar original', 'Catálogo de programas'];

const MediaSelect = ({ catalog }) => {
  const [source, setSource] = useState('Confirmar original');
  const history = useHistory();
  // guardar posición de scroll y redirigir a confirmación
  const onSubmitMedia = () => {
    localStorage.setItem('scrollPosition', window.pageYOffset);
    history.push('/confirmation');
  };
  return (
    <div className={styles.container}>
      <div className={styles.selection}>
        <h4>Selección de programa</h4>
        <div>
          {sources?.map(item => (
            <label key={item}>
              <RadioButton name="source" value={item} onChange={(e) => setSource(e.value)} checked={source === item} required />
              <span>{item}</span>
            </label>
          ))}
        </div>
      </div>
      <div className={styles.content}>
        {source === 'Confirmar original' && <MediaDefault onSubmitMedia={onSubmitMedia} />}
        {source === 'Catálogo de programas' && <MediaLibrary onSubmitMedia={onSubmitMedia} catalog={catalog} />}
      </div>
    </div>
  );
};

export default MediaSelect;
