import React, { useState, useEffect } from 'react';
import styles from './mediaMonitor.module.scss';
import { getOrderID } from '../../service/EstacionDigitalServices';


const OrderDetail = (props) => {
  const { localStorage } = window;


  const selectedOrder = props.orderId;
  const [orderID, setOrderID] = useState({});

  localStorage.setItem('selectedOrder', props.orderId);
  useEffect(() => {
    if (selectedOrder) {
      async function getData() {
        setOrderID(await getOrderID(selectedOrder));
      }
      getData();

    }
    
  }, [selectedOrder]);
  useEffect(()=>{
    if(orderID.prg_id_sustituto){
      props.changeButtonStatus(false)
    }

    localStorage.setItem('videoID', orderID.id_video);
    localStorage.setItem('orderPgrName', orderID.prg_descripcion_sustituto);
    localStorage.setItem('orderPgrID', orderID.prg_id_sustituto);
    localStorage.setItem('orderDuration', orderID.duracion_bloqueo);
    localStorage.setItem('orderMinDuration', orderID.duracion_minima);
    localStorage.setItem('orderMaxDuration', orderID.duracion_maxima);
    localStorage.setItem('orderComments', orderID.instrucciones);    
  },[orderID]);


  
  return (
    <div className={styles.container} >

      <div className={styles.blockContent}>
        <div className={styles.blockInfo}>
          <p>
            <strong># Orden: </strong>
            <span>{selectedOrder}</span></p>
          <div>
            <b>Programa:</b>
            <p>{orderID? orderID.prg_descripcion_sustituto : "no disponible"}</p>
          </div>
          <div>
            <b>Programa ID:</b>
            <p>{orderID?.prg_id_sustituto}</p>
          </div>
          <div>
            <b>Fecha:</b>
            <p>{orderID?.fecha}</p>
          </div>
          <div>
            <b>Video ID:</b>
            <p>{orderID?.id_video !== '' ? orderID.id_video : 'SIN ID'}</p>
          </div>
          <div>
            <b>Duración del bloqueo:</b>
            <p>{orderID?.duracion_bloqueo}</p>
          </div>
          <div>
            <b>Duración mínima:</b>
            <p>{orderID?.duracion_minima}</p>
          </div>
          <div>
            <b>Duración máxima:</b>
            <p>{orderID?.duracion_maxima}</p>
          </div>
          <div>
            <b>Instrucciones:</b>
            <p>{orderID?.instrucciones}</p>
    
          </div>
        </div>
      </div>

    </div>

  );
};

export default OrderDetail;
