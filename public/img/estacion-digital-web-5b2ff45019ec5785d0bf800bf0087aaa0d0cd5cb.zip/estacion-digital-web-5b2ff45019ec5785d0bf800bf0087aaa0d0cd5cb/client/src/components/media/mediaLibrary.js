import React, { useState } from 'react';
import { InputText } from 'primereact/inputtext';
import { Checkbox } from 'primereact/checkbox';
import { Button } from 'primereact/button';
import { ProgressSpinner } from 'primereact/progressspinner';
import styles from './mediaLibrary.module.scss';

const Loading = () => (
  <div className={styles.loading}>
    <ProgressSpinner style={{ width: '50px', height: '50px' }} strokeWidth="3" animationDuration=".5s" />
    <p>Cargando</p>
  </div>
);


const MediaBlock = ({ item, selectedReplacement, handleSelectedReplacement, onSubmitMedia }) => {
  const { prg_id, programa } = item;
  const [recurrent, setRecurrent] = useState(false);
  // deshabilitar selección de otros bloques cuando uno ha sido seleccionado
  const isDisabled = selectedReplacement !== null && selectedReplacement !== prg_id;
  // detectar que bloque ha sido seleccionado
  const isSelected = selectedReplacement !== null && selectedReplacement === prg_id;
  const [comment, setComment] = useState('');
  // almacenar indicaciones
  const handleComment = (value) => {
    setComment(value)
    localStorage.setItem('comment', value);
  }
  // manejar recurrencia
  const handleRecurrent = () => {
    // solicitar recurrencia
    if (!recurrent) {
      setRecurrent(true);
      localStorage.setItem('singleRecurrent', 'true');
      // recurrencia no requerida
    } else {
      setRecurrent(false);
      localStorage.removeItem('singleRecurrent');
    }
  }
  return (
    <div className={`${styles.block} ${isDisabled ? styles.blockDisabled : ''}`}>
      <div className={styles.blockInfo}>
        <p>{`${prg_id} - ${programa}`}</p>
      </div>
      {isSelected && (
        <div className={styles.blockConfirmation}>
          <textarea value={comment} onChange={(e) => handleComment(e.target.value)} placeholder="Indicaciones (opcional)" maxLength={255} className={styles.blockTextarea} />
          <label className={styles.recurrent}>
            <Checkbox value="confirm" onChange={handleRecurrent} checked={recurrent} />
            <span>Bloqueo recurrente</span>
          </label>
          <Button label="Confirmar asignación" className={styles.blockButton} onClick={()=>{onSubmitMedia(recurrent,comment,prg_id)}} />
        </div>
      )}
      <label className={styles.blockLabel}>
        <span>Asignar</span>
        <Checkbox value="id" onChange={() => handleSelectedReplacement(prg_id, programa)} checked={isSelected} disabled={isDisabled} />
      </label>
    </div>
  );
};

const Search = ({ catalog, handleSearch }) => {
  const [value, setValue] = useState('');
  // manejar búsqueda
  const handleChange = (term) => {
    // almacenar el valor del input
    setValue(term)
    // detectar cuando una sugerencia ha sido seleccionada
    if (term.match(/(^\d.*\s-\s.*)/)) {
      // obtener solo del ID del valor seleccionado
      const val = parseFloat(term.replace(/(\s-.*)/, ''));
      // realizar búsqueda con el ID
      handleSearch(val);
      // limpiar texto de búsqueda
      setValue('');
    }
  }
  return (
    <form >
      <label className={`p-input-icon-right ${styles.searchBox}`}>
        <i className="pi pi-search" />
        <InputText list="catalog" value={value} onChange={(e) => handleChange(e.target.value)} placeholder="Buscar programa" name="catalog" />
      
      </label>
      <datalist id="catalog">
        {catalog?.map((item, key) => <option key={key} value={`${item.prg_id} - ${item.programa}`} />)}
      </datalist>
    </form>
  );
}

const MediaLibrary = ({ onSubmitMedia, catalog }) => {
  const { localStorage } = window;
  const [searchValue, setSearchValue] = useState('');
  const [searchResult, setSearchResult] = useState(null);
  const [selectedReplacement, setSelectedReplacement] = useState(null);
  // manejar programa sustituto
  const handleSelectedReplacement = (id, name) => {
    // si no hay valor asignado o es diferente al seleccionado, guardar el nuevo valor
    if (selectedReplacement === null || selectedReplacement !== id) {
      setSelectedReplacement(id);
      localStorage.setItem('replacementID', id);
      localStorage.setItem('replacementName', name);
    } else {
      // eliminar el valor seleccionado y regresar al estado inicial
      setSelectedReplacement(null);
      localStorage.removeItem('replacementID');
      localStorage.removeItem('replacementName');
      localStorage.removeItem('comment');
      localStorage.removeItem('singleRecurrent');
    }
  }
  // realizar bísqueda de programa
  const handleSearch = (value) => {
    // guardar el valor de la búsqueda
    setSearchValue(value);
    // filtrar el resultado
    const results = catalog?.filter(item => item?.prg_id === value);
    // guardar el objeto del resultado
    setSearchResult(results);
  };
  // limpiar la búsqueda
  const handleCleanSearch = () => {
    setSearchValue('');
    setSearchResult(null);
  };
  return (
    <div className={styles.container}>
      {catalog && catalog.length && catalog[0] ? <Search catalog={catalog} searchValue={searchValue} handleSearch={handleSearch} /> : <Loading />}
      <div className={styles.content}>
        {searchResult !== null && (
          <div className={styles.searchResult}>
            <h5>Resultado de búsqueda:</h5>
            <button type="button" onClick={handleCleanSearch}>
              <span>limpiar búsqueda</span>
              <i className="pi pi-trash" />
            </button>
            {searchResult !== undefined ? searchResult?.map((result, key) => (
              <MediaBlock key={key} item={result} selectedReplacement={selectedReplacement} handleSelectedReplacement={handleSelectedReplacement} onSubmitMedia={onSubmitMedia} searchResult={true} />
            )) : <div className={styles.noResult}><p>No hay resultados para ese término de búsqueda</p></div>}
          </div>
        )}
      </div>
    </div>
  );
};

export default MediaLibrary;
