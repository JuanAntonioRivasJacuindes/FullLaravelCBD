import React, { useState, useEffect } from 'react';
import { RadioButton } from "primereact/radiobutton";
import styles from './mediaMonitor.module.scss';

import MediaSearch from './mediaSearch';
import MediaStream from './mediaStream';
import { getOrderID } from '../../service/EstacionDigitalServices';

const Block = ({ item, selectedOrder }) => {
  const { localStorage } = window;
  // almacenar los valores necesarios
  localStorage.setItem('videoID', item?.id_video);
  localStorage.setItem('orderPgrName', item?.prg_descripcion_sustituto);
  localStorage.setItem('orderPgrID', item?.prg_id_sustituto);
  localStorage.setItem('orderDuration', item?.duracion_bloqueo);
  localStorage.setItem('orderMinDuration', item?.duracion_minima);
  localStorage.setItem('orderMaxDuration', item?.duracion_maxima);
  localStorage.setItem('orderComments', item?.instrucciones);
  const [option, setOption] = useState('');
  // opciones de búsqueda de media
  const options = ['Media existente', 'MediaStream'];
  return (
    <div className={styles.block}>
      <div className={styles.blockContent}>
        <div className={styles.blockInfo}>
          <p>
            <strong>Orden de bloqueo: </strong>
            <span>{selectedOrder}</span></p>
          <div>
            <b>Programa:</b>
            <p>{item?.prg_descripcion_sustituto}</p>
          </div>
          <div>
            <b>Programa ID:</b>
            <p>{item?.prg_id_sustituto}</p>
          </div>
          <div>
            <b>Fecha:</b>
            <p>{item?.fecha}</p>
          </div>
          <div>
            <b>Video ID:</b>
            <p>{item?.id_video !== '' ? item?.id_video : 'SIN ID'}</p>
          </div>
          <div>
            <b>Duración del bloqueo:</b>
            <p>{item?.duracion_bloqueo}</p>
          </div>
          <div>
            <b>Duración mínima:</b>
            <p>{item?.duracion_minima}</p>
          </div>
          <div>
            <b>Duración máxima:</b>
            <p>{item?.duracion_maxima}</p>
          </div>
          <div>
            <b>Instrucciones:</b>
            <p>{item?.instrucciones}</p>
          </div>
        </div>
        <div className={styles.radioOptions}>
          <p>Asignar media:</p>
          {options.map((optionItem, key) => (
            <label key={key}>
              <RadioButton name="type" value={optionItem} onChange={() => setOption(optionItem)} checked={option === optionItem} required />
              <span>{optionItem}</span>
            </label>
          ))}
        </div>
        <div className={styles.mediaOptions}>
          {option === 'Media existente' && <MediaSearch />}
          {option === 'MediaStream' && <MediaStream />}
        </div>
      </div>
    </div>
  );
};

const MediaMonitor = () => {
  const { localStorage } = window;
  const selectedOrder = localStorage.getItem('selectedOrder');
  const [orderID, setOrderID] = useState(null);
  // obtener y almacenar información de la orden de bloqueo
  useEffect(() => {
    async function getData() {
      setOrderID(await getOrderID(selectedOrder));
    }
    getData();
  }, [selectedOrder]);
  return (
    <div className={styles.container}>
      <h4>Detalle de la orden</h4>
      <div className={styles.content}>
        {orderID && <Block item={orderID} selectedOrder={selectedOrder} />}
      </div>
    </div>
  );
};

export default MediaMonitor;
