import React, { useState, useEffect } from 'react';
import { Button } from 'primereact/button';
import { Checkbox } from 'primereact/checkbox';
import styles from './mediaDefault.module.scss';

import { getPrograma } from '../../service/EstacionDigitalServices';

const MediaDefault = ({ onSubmitMedia }) => {
  const { localStorage } = window;
  const [program, setProgram] = useState({});
  const id = localStorage.getItem('selectedBlock')
  // obtener información del programa seleccionado
  useEffect(() => {
    async function getData() {
      setProgram(await getPrograma(id, '60031395'));
    }
    getData();
  }, [id]);
  // guardar hora de inicio y final del bloqueo
  if (program !== {} && program?.hora_inicio && program?.hora_final) {
    localStorage.setItem('blockStart', program?.hora_inicio);
    localStorage.setItem('blockEnd', program?.hora_final);
  }
  return (
    <div className={styles.container}>
      <div className={styles.info}>
        <p>{program?.confirmado ? program?.prg_descripcion_sustituto : program?.prg_descripcion_original}</p>
        <span>{program?.sinopsis}</span>
        <div>
          <b>ID:</b>
          <p>{program?.confirmado ? program?.prg_id_sustituto : program?.prg_id_original}</p>
        </div>
        {program?.confirmado ? (
          <div>
            <b>Programa original:</b>
            <p>{`${program?.prg_id_original} - ${program?.prg_descripcion_original}`}</p>
          </div>
        ) : ''}
        <div>
          <b>Hora de inicio:</b>
          <p>{program?.hora_inicio}</p>
        </div>
        <div>
          <b>Hora de final:</b>
          <p>{program?.hora_final}</p>
        </div>
        <div>
          <b>Instrucciones:</b>
          <p>{program?.instrucciones !== '' ? program?.instrucciones : 'Sin instrucciones'}</p>
        </div>
      </div>
      {!program?.prg_recurrente && (
        <div className={styles.button}>
          <Button label="Confirmar programa" onClick={onSubmitMedia} />
        </div>
      )}
      {program?.prg_recurrente && (
        <div className={styles.alert}>
          <i className="pi pi-exclamation-circle" />
          <p>El programa no tiene derechos y necesita ser reemplazado</p>
        </div>
      )}
    </div>
  );
};

export default MediaDefault;
