import React, { useState, useEffect } from 'react';
import MediaSearch from './mediaSearch';
import NewMedia from './newMedia';
import MediaStream from './mediaStream';
import { getOrderID } from '../../service/EstacionDigitalServices';
import { TabView, TabPanel } from 'primereact/tabview';
const Block = (props) => {


  const { localStorage } = window;
  const [tabActiveIndex, setTabActiveIndex] = useState(1)
  const selectedOrder = props.orderId;

  const [item, setItem] = useState(null);
  localStorage.setItem('selectedOrder', props.orderId);

  localStorage.setItem('selectedOrder', props.orderId);
  useEffect(() => {

    if (selectedOrder) {
      async function getData() {
        setItem(await getOrderID(selectedOrder));
      }
      getData();
    }else{

      props.changeButtonStatus(true)
    }
    props.changeButtonStatus(true)
  }, [selectedOrder]);
  useEffect(() => {
    localStorage.setItem('videoID', item?.id_video);
    localStorage.setItem('orderPgrName', item?.prg_descripcion_sustituto);
    localStorage.setItem('orderPgrID', item?.prg_id_sustituto);
    localStorage.setItem('orderDuration', item?.duracion_bloqueo);
    localStorage.setItem('orderMinDuration', item?.duracion_minima);
    localStorage.setItem('orderMaxDuration', item?.duracion_maxima);
    localStorage.setItem('orderComments', item?.instrucciones);

  }, [item]);


  return (

    <div className="w-full" >

      <TabView className="w-full" activeIndex={tabActiveIndex} onTabChange={(e) => setTabActiveIndex(e.index)}>
        <TabPanel className="w-full" header="Media Nueva">
          <NewMedia updateOrderSuccess={props.updateOrderSuccess} changeButtonStatus={props.changeButtonStatus}  prg_id={item?.prg_id_sustituto} id_bloqueo={selectedOrder} videoId={item?.id_video} />
        </TabPanel>
        <TabPanel className="w-full" header="Media existente">
          <MediaSearch updateOrderSuccess={props.updateOrderSuccess} changeButtonStatus={props.changeButtonStatus} setConfirmationTab={props.setConfirmationTab} setVerificationTab={props.setVerificationTab} />
        </TabPanel>
        <TabPanel className="w-full" header="MediaStream">
          <MediaStream updateOrderSuccess={props.updateOrderSuccess} changeButtonStatus={props.changeButtonStatus} setConfirmationTab={props.setConfirmationTab} setVerificationTab={props.setVerificationTab} />
        </TabPanel>
      </TabView>
    </div>

  );
};


export default Block;
