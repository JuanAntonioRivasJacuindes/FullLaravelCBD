import React, { useState, useEffect } from 'react';
import { Calendar } from 'primereact/calendar';
import { addLocale } from 'primereact/api';

import { InputText } from 'primereact/inputtext';
import { InputMask } from 'primereact/inputmask';
import { Fieldset } from 'primereact/fieldset';
import Confirm from '../schedule/confirmOrder';
import { Button } from 'primereact/button';
import styles from './mediaSearch.module.scss';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { searchMedia } from '../../service/EstacionDigitalServices';

import PlayFront from '../Player';
import ReactPlayer from "react-player/lazy";

const MediaSearch = (props) => {
  const [words, setWords] = useState('');
  const [date, setDate] = useState('');
  const [mediaID, setMediaID] = useState('');

  const [selectedRow, setSelectedRow] = useState()

  const [selectedVideo, setSelectedVideo] = useState({ cue_points: [], duration: '', nombre_archivo: "", id_video: "0", prg_id: 0, program: "" })

  const [minDur, setMinDur] = useState(localStorage.getItem('orderMinDuration'));
  const [maxDur, setMaxDur] = useState(localStorage.getItem('orderMaxDuration'));
  const [results, setResults] = useState(null);
  const [selectedMedia, setSelectedMedia] = useState('');
  // deshabilitar botón si ningún valor de búsuqueda ha sido ingresado
  const buttonDisabled = words === '' && date === '' && mediaID === '' && minDur === '' && maxDur === '';
  // idioma español en el componente de calendario
  function secondsToString(seconds) {
    var hour = Math.floor(seconds / 3600);
    hour = (hour < 10) ? '0' + hour : hour;
    var minute = Math.floor((seconds / 60) % 60);
    minute = (minute < 10) ? '0' + minute : minute;
    var second = seconds % 60;
    second = (second < 10) ? '0' + second : second;
    return hour + ':' + minute + ':' + second;
  }
  addLocale('es', {
    firstDayOfWeek: 1,
    dayNames: ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'],
    dayNamesShort: ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'],
    dayNamesMin: ['D', 'L', 'M', 'X', 'J', 'V', 'S'],
    monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
    monthNamesShort: ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'],
    today: 'Hoy',
    clear: 'Limpiar'
  });
  // dar formato al valor de fecha seleccionada
  const dateFormat = {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  };
  const formatDateValue = (value) => {
    const date = new Intl.DateTimeFormat('es-MX', dateFormat).format(value);
    return date;
  };
  // guardar valor de fecha formateado
  const handleSelectDate = (value) => {
    setDate(formatDateValue(value));
  };
  // realizar búsqueda con los valores proporcionados
  const handleSearch = async (e) => {


    e.preventDefault();
    const data = await searchMedia(words, date, mediaID, maxDur, minDur);
    setResults(data);

  };
  const infoBodyTemplate = (rowData) => {
   
    return (
      <div>

        <h5>{rowData['programa']}</h5>

        <p>

          <strong>Descripción:</strong> {rowData['nombre']}<br/>
          <strong>Duración:</strong> {secondsToString(rowData['duration'])}<br/>
          </p>
      </div>
    )

  }
  useEffect(() => {
    props.setConfirmationTab(
      <div>
        <Confirm updateOrderSuccess={props.updateOrderSuccess} />
      </div>
    )
    props.setVerificationTab(
      <div>

        <PlayFront tipo={false} actualiza={true} cuePoints={selectedVideo.cue_points} nombre_archivo={selectedVideo.nombre_archivo} id_video={selectedVideo.id_video}></PlayFront>
        <Button onClick={() => { props.changeButtonStatus(false) }} >Aceptar</Button>
      </div>
    )
  }, [selectedRow]);




  const handleSelect = (item) => {

    setSelectedRow(item.value)


    if (item.value) {
      props.changeButtonStatus(false)

      setSelectedVideo({ cue_points: formatCuePoints(item.value.cue_points).toString(), duration: item.value.duration, nombre_archivo: item.value.nombre_archivo, id_video: item.value.id_video, prg_id: item.value.prg_id, program: item.value.programa })
      item = item.value

      if (selectedMedia !== item?.id_video) {
        setSelectedMedia(item?.id_video);
        localStorage.setItem('videoID', item?.id_video);
        localStorage.setItem('orderPgrName', item?.programa);
        localStorage.setItem('orderPgrID', item?.prg_id);
        // remover selección de la media en cuestión
      } else {
        setSelectedMedia('');
        localStorage.removeItem('videoID');
        localStorage.removeItem('orderPgrName');
        localStorage.removeItem('orderPgrID');
      }
    } else {
      props.changeButtonStatus(true)
    }


    // si no hay media seleccionada o es diferente a la selección actual, actualizar y guardar el valor
  };

  const formatCuePoints = (points) => {
    let formated = [];
    try {
      formated = JSON.parse(points)
    } catch (error) {
      console.log("error intentando formatear " + points)

    }


    return formated;
  };


  const videoBodyTemplate = (rowData) => {
    const url = "https://video1.socio.gs/EstacionDigital/_definist_/proxy/mp4:" + rowData.nombre_archivo + "/playlist.m3u8";


    return (
    < div className='max-w-min bg-gray-900'  >

      <h6 className="absolute mx-3 my-7 ">Vista Previa No Disponible</h6>

        <ReactPlayer
    
          className="relative 0"
          onMouseOver={(e) => { try { e.target.play() } catch { } }}
          onMouseOut ={(e) => { try { e.target.pause() } catch { } }}

          url={url}
          width="200px"
          height="auto"
          controls={false}
        />
  
    </div >
    )

  }


  // limpiar búsqueda y todos sus valores
  const handleCleanSearch = () => {

    setDate('');
    setMediaID('');
    setMaxDur(localStorage.getItem('orderMaxDuration'));
    setMinDur(localStorage.getItem('orderMinDuration'));
    setSelectedMedia('')
    setResults(null);
  };
  return (
    <div className={styles.container}>
      <div className={styles.content}>
        <div className={styles.header}>

          {results === null ? '' : (
            <button type="button" onClick={handleCleanSearch}>
              <span>Limpiar búsqueda</span>
              <i className="pi pi-trash" />
            </button>
          )}
        </div>


        <span className="p-input-icon-left flex">
          <i className="pi pi-search" />
          <InputText name="words" onKeyPress={(e)=>{if(e.key==='Enter'){handleSearch(e)}}} value={words} onChange={(e) => setWords(e.target.value)} placeholder="Buscar  " />
          <Button icon="pi pi-search"  onClick={handleSearch} disabled={buttonDisabled} />
        </span>
        <Fieldset legend="Busqueda Avanzada" collapsed={true} toggleable>
          <label className={styles.formInput}>
            <span>Fecha:</span>
            <Calendar dateFormat="dd/mm/yy" onChange={e => handleSelectDate(e.value)} locale="es" placeholder="00/00/00" className={styles.calendar} showIcon required />
          </label>
          <label className={styles.formInput}>
            <span>ID del programa</span>
            <InputText name="mediaID" value={mediaID} onChange={(e) => setMediaID(e.target.value)} placeholder="ID del programa" />
          </label>
          <label className={styles.formInput}>
            <span>Duración mínima:</span>
            <InputMask mask="99:99:99" value={minDur} onChange={(e) => setMinDur(e.target.value)} placeholder="00:00:00" />
          </label>
          <label className={styles.formInput}>
            <span>Duración máxima:</span>
            <InputMask mask="99:99:99" value={maxDur} onChange={(e) => setMaxDur(e.target.value)} placeholder="00:00:00" />
          </label>
        </Fieldset>

        <div>


        </div>


        <div >

          <DataTable onSelectionChange={handleSelect} selection={selectedRow} paginator rows={10} value={results} responsiveLayout="stack" showGridlines>

            <Column selectionMode="single" headerStyle={{ width: '3em' }} ></Column>
            <Column  className='w-1 text-white' body={videoBodyTemplate}></Column>
            <Column body={infoBodyTemplate}></Column>

          </DataTable>


        </div>
      </div>
    </div>
  );
};

export default MediaSearch;
