import ReactPlayer from "react-player";
import { Button } from 'primereact/button';
import React, { useEffect, useState, useRef } from "react";
import { FormatService } from "./format";
import { Fieldset } from 'primereact/fieldset';
import { InputText } from 'primereact/inputtext';
import axios from 'axios';
import { Toast } from 'primereact/toast';

let minutos='';
const Player = (props) => {

  const videoPlayerRef = useRef(null);
  const toast = useRef(null);
  const [rate, setRate] = useState(1);
  const [buttonDisabled, setButtonDisable] = useState(false);
  const [visible, setVisible]=useState(false);
  const [tipoComponente, setTipoComponente]=useState(props.tipo);

    let arrayCP =[];
    if (props.cuePoints!=""){
      arrayCP=((props.cuePoints+'').slice(1, -1)).split(",")
    }
  const [cuePoint, setCuePoint] = useState(arrayCP);
  const [durationV, setDurationV]= useState(minutos);
  const [url, setUrl]=useState();
  const [videoState, setVideoState] = useState({
    playing: true,
    muted: false,
    volume: 0.5,
    playbackRate: 1,
    played: 0,
    seeking: false,
    buffer: true,
  });
  const [actualiza, setActualiza]=useState(props.actualiza);
  const formatService = new FormatService();

  let cueLimit = 1;
  // se obtiene la longitud del aray de cue points
  const cueLength = cuePoint?.length;
  // limitar cantidad de cue points que se pueden asignar a un mediastream acorde a su duración
     if (durationV >= 19 && durationV <= 28) {
       cueLimit = 2
     } else if (durationV >= 29 && durationV <= 58) {
       cueLimit = 4
     } else if (durationV >= 59 && durationV <= 78) {
       cueLimit = 6
     } else if (durationV >= 79 && durationV <= 98) {
       cueLimit = 8
     } else if (durationV >= 99 && durationV <= 118) {
       cueLimit = 10
     } else if (durationV >= 119 && durationV <= 138) {
       cueLimit = 12
     } else if (durationV >= 139 && durationV <= 158) {
       cueLimit = 14
     } else if (durationV >= 159) {
       cueLimit = 16
     }

// detectar cuendo límite de cue points permitido ha sido alcanzado
const cueLimitReached = cueLength === cueLimit;

useEffect(() => {
  asignarUrl();
}, []);


const asignarUrl = () => {
  if (actualiza){
    setUrl("https://video1.socio.gs/EstacionDigital/_definist_/mp4:"+props.nombre_archivo+"/playlist.m3u8")
  }else{
    //setUrl("https://mdstrm.com/video/63c840d79396ca08b1240525.m3u8")
    setUrl("https://mdstrm.com/video/"+props.id_video+".m3u8")
  }
};

//Metodo para obtener la duracion en minutos del video que se esta ejecutando en segundo plano
const handleLoadedMetadata = () => {
  const video = videoPlayerRef.current.getDuration();
  minutos=(video/60).toFixed();
  setDurationV(minutos);
  if (!video) return;
  //console.log(`Duracion del video: ${minutos} minutos.`);
};

const rewindHandler2 = () => {
                        //Rewinds the video player reducing 5
                        videoPlayerRef.current.seekTo(videoPlayerRef.current.getCurrentTime() - 2);
};

const handleFastFoward2 = () => {
                        //FastFowards the video player by adding 10
                        videoPlayerRef.current.seekTo(videoPlayerRef.current.getCurrentTime() + 2);
};

const rewindHandler5 = () => {
                        //Rewinds the video player reducing 5
                        videoPlayerRef.current.seekTo(videoPlayerRef.current.getCurrentTime() - 5);
};

const handleFastFoward5 = () => {
                        //FastFowards the video player by adding 10
                        videoPlayerRef.current.seekTo(videoPlayerRef.current.getCurrentTime() + 5);
};

const speedUp = () => {
                        //FastFowards the video player by adding 10
                        let newRate= videoState.playbackRate+0.25;
                        videoState.playbackRate=newRate;
                        setRate(newRate)
                        //console.log(newRate);

};

const speedDown = () => {
                        //FastFowards the video player by adding 10
                        let newRate= videoState.playbackRate-0.25;
                        videoState.playbackRate=newRate;
                        setRate(newRate)
                        //console.log(newRate);

};

const normalSpeed = () => {
                        //FastFowards the video player by adding 10
                        let newRate= 1;
                        videoState.playbackRate=newRate;
                        setRate(newRate)
                        //console.log(newRate);

};

const capturaCuePoint = () => {
                        //Rewinds the video player reducing 5
                        setCuePoint([...cuePoint, formatService.formatTime(videoPlayerRef.current.getCurrentTime())])
                        videoPlayerRef.current.getCurrentTime();
                        setVisible(true);

};

useEffect(()=>{
  if(cuePoint.length>0){

    setButtonDisable(false)
  }else{

    setButtonDisable(true)

  }

},[cuePoint]);

const DeleteCuePoint = (indexItem) => {
                        if(indexItem===0){
                          setVisible(false);
                        }
                        setCuePoint((prevState) =>
                        prevState.filter((cuePoint, index) => index !== indexItem)
                        );
};

const PlayCuePoint = (indexItem) => {
                        let segundos=(formatService.formatSec(indexItem));
                        videoPlayerRef.current.seekTo(segundos);
 };

const saveCuePoints  = async (cuePoints) => {
  if(actualiza === true){
    try{
      const data= {cuePoints: '['+cuePoint+']'}
      const response = await axios.put('https://10.126.65.29/vidig-vod/actualizaCuePoints/' + props.id_video, data);
      //console.log(response);
      toast.current.show({ severity: 'success', summary: 'Exito!', detail: 'Se guardaron los CuePoints!', life: 5000 });
    }catch{
      toast.current.show({ severity: 'error', summary: 'Error!', detail: 'Ha ocurrido un error, intentalo mas tarde.', life: 5000 });
      //console.log('something went wrong :(');
    }
  }else {
    try{

      props.passData(cuePoint);
      toast.current.show({ severity: 'success', summary: 'Exito!', detail: 'Se guardaron los CuePoints!', life: 5000 });
    }catch{

      toast.current.show({ severity: 'error', summary: 'Error!', detail: 'Ha ocurrido un error, intentalo mas tarde.', life: 5000 });
    }
  }

}

  return (
    <div>
        <div className="formgrid grid">
            <div className="field col" >
            <Toast ref={toast} />
                <Fieldset legend="Video">
                    <ReactPlayer
                    ref={videoPlayerRef}
                    className="player"
                    onLoadedMetadata={handleLoadedMetadata}
                    url={url}
                    width="640px"
                    height="360px"
                    controls={true}
                    playing ={true}
                    playbackRate={rate}/><br/>
                    <div className="button-demo" style={{width: "640px"}}>
                      <Button key={"1"} onClick={rewindHandler5} style={{ marginLeft: "4px", marginRight: "13px", height: "15px", width: "80px"}} className="p-button-rounded p-button-secondary" label="<< 5s"></Button>
                      <Button key={"2"} onClick={rewindHandler2} style={{marginRight: "13px", height: "15px", width: "80px"}} className="p-button-rounded p-button-secondary" label="<< 2s"></Button>
                      <Button key={"3"} onClick={speedDown} style={{marginRight: "13px", height: "15px", width: "75px"}} icon="pi pi-minus" className="p-button-success"></Button>
                      <Button key={"4"} onClick={normalSpeed} style={{marginRight: "13px", height: "15px", width: "75px"}} className="p-button-success" label="1x"></Button>
                      <Button key={"5"} onClick={speedUp} style={{marginRight: "13px", height: "15px", width: "75px"}} icon="pi pi-plus" className="p-button-success"></Button>
                      <Button key={"6"} onClick={handleFastFoward2} style={{marginRight: "13px", height: "15px", width: "80px"}} className="p-button-rounded p-button-secondary" label=">> 2s"></Button>
                      <Button key={"7"} onClick={handleFastFoward5} style={{marginRight: "13px", height: "15px", width: "80px"}} className="p-button-rounded p-button-secondary" label=">> 5s"></Button><br/><br/>
                      {cueLimitReached ? (
                        <div>
                          {visible &&<p style={{marginLeft: "25px", height: "25px"}} className="p-error block"><i className="pi pi-exclamation-circle" />  Has alcanzado el máximo de Cue Points para esta media.</p>}
                        </div>) :
                        (tipoComponente && <Button key={"8"} onClick={capturaCuePoint} style={{height: "25px", width: "640px"}} className="p-button p-button-primary" label="CAPTURAR CUE POINT"></Button>)}
                    </div>
                </Fieldset>
            </div>
            {tipoComponente &&
            <div className="field col" >
                <Fieldset legend="CuePoints" style={{width: "300px"}}>
                    {cuePoint.sort().map((item, index)=>{
                      return( <div key={"div"+index}>
                        <InputText key={"cue"+item} value={item} disabled style={{marginRight: "10px", width: "120px", height: "30px"}}/>
                        {tipoComponente && <Button key={"btn-del"+item} style={{ marginRight: "10px", width: "30px", height: "30px"}} onClick={() => DeleteCuePoint(index)} icon="pi pi-trash" className="p-button-rounded p-button-danger"/>}
                          <Button key={"btn-play"+item} style={{ width: "30px", height: "30px"}} onClick={() => PlayCuePoint(item)} icon="pi pi-play" className="p-button-rounded p-button-info"/>   <br/><br/></div>
                      )
                    })}
                    <Button label="Guardar" disabled={buttonDisabled}  style={{width: "120px", height: "30px"}} className="p-button-success" onClick={() => saveCuePoints("["+cuePoint+"]")}/>
                </Fieldset>
            </div>}

            {tipoComponente ||
            <div className="field col" >
                <Fieldset legend="CuePoints" style={{width: "300px"}}>
                    {cuePoint.sort().map((item, index)=>{
                      return( <div key={"div"+index}>
                        <InputText key={"cue"+item} value={item} disabled style={{marginRight: "10px", width: "120px", height: "30px"}}/>
                        {tipoComponente && <Button key={"btn-del"+item} style={{ marginRight: "10px", width: "30px", height: "30px"}} onClick={() => DeleteCuePoint(index)} icon="pi pi-trash" className="p-button-rounded p-button-danger"/>}
                          <Button key={"btn-play"+item} style={{ width: "30px", height: "30px"}} onClick={() => PlayCuePoint(item)} icon="pi pi-play" className="p-button-rounded p-button-info"/>   <br/><br/></div>
                      )
                    })}
                    {visible && <Button label="Guardar"  style={{width: "120px", height: "30px"}} className="p-button-success" onClick={() => saveCuePoints("["+cuePoint+"]")}/>}
                </Fieldset>
            </div>}
        </div>
      </div>
  )
}

export default Player;
