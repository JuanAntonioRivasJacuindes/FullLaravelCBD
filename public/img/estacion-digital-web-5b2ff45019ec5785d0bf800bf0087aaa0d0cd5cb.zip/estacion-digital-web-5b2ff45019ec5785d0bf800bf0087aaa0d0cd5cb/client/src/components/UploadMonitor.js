
import React from 'react';


import { Panel } from 'primereact/panel';

import { Divider } from 'primereact/divider';


import LoaderComponent from "../components/LoaderComponent";
import { Card } from 'primereact/card';
import DownloadComponent from './DownloadComponent.js';
import SingleLoadComponent from './SingleLoadComponent';

const UploadMonitor = (vars) => {

    return (
        <div>

            <Panel header="Monitor de transferencias">
                <Card title="Pluto Tv" subTitle="Se muestra el estatus de carga de episodos a pluto tv">
                    <div>
                        <LoaderComponent></LoaderComponent>
                    </div>
                </Card>
                <Divider type="dashed" />
                <Card title="Descargas" subTitle="Descargas activas al servidor local">
                    <div>
                        <DownloadComponent></DownloadComponent>
                    </div>
                </Card>
                <Divider type="dashed" />
                <Card title="Cargas" subTitle="Cargas activas al S3">
                    <div>
                        <SingleLoadComponent></SingleLoadComponent>
                    </div>
                </Card>
            </Panel>
            <div>
            </div>
        </div>
    );

}
export default UploadMonitor