
import React, { useState, useEffect, useRef } from 'react';
import { ProgressBar } from 'primereact/progressbar';

import { TransferService } from '../service/TransferService';

import { Accordion, AccordionTab } from 'primereact/accordion';

const DownloadComponent = (vars) => {

    const interval = useRef(null);
    const [downloads, setDownloads] = useState([])
    const [activeIndex, setActiveIndex] = useState()
    const transferService = new TransferService();

    useEffect(() => {
        let mounted = true
        interval.current = setInterval(() => {
            transferService.getDownloads()
                .then((res) => {
                    if(mounted){

                        setDownloads(res.data.downloads)
                    }
                })
                .catch((err) => console.log(err))

        }, 500);
        return () => {
            clearInterval(interval.current)
             mounted = false
        }
    });

    return (
        <div>
      
                <Accordion activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
                 
                {downloads.map((key, i) =>
                    <AccordionTab key={"acorTabDl"+key.id} header={key.file_name}>
                      

                        <small>Tamaño: {key.file_size}</small>
                        <br></br>

                        <small>Origen: {key.url}</small>
                        <br></br>
                        <small>Progreso:</small>
                        <ProgressBar key={"singleDL" + key.id} value={key.progress}>d</ProgressBar>
                        <hr>
                        </hr>
                   
                    </AccordionTab>



                )}
                </Accordion>

        </div>
    );
}

export default DownloadComponent