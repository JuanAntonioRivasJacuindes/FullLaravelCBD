import React from 'react';

const Layout = ({ children }) => (
    <div className="grid">
        <div className="col-12">
            <div className="card">
                {children}
            </div>
        </div>
    </div>
);

export default Layout;
