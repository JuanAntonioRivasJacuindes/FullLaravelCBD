
import React, { useState, useEffect, useRef } from 'react';
import { TransferService } from '../service/TransferService';
import { Accordion, AccordionTab } from 'primereact/accordion';
import { ProgressBar } from 'primereact/progressbar';


const LoaderComponent = (vars) => {
    const [loads, setLoads] = useState([])
    const interval = useRef(null);
    const [activeIndex, setActiveIndex] = useState()

    const transferService = new TransferService();
    useEffect(() => {
        interval.current = setInterval(() => {

            transferService.getPlutoLoads()
                .then((res) => setLoads(res.data.loaders))
                .catch((err) => console.log(err))

        }, 5000);
        return () => {
            if (interval.current) {
                clearInterval(interval.current);
                interval.current = null;
            }
        }
    });


    return (
        <div className='bg-white  p-3 '>

            <Accordion key="Acordeom2" activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
                {loads.map((loader, i) =>
                    <AccordionTab key={i} header={loader.display_name}>
                        {loader.loads.map((load, i) =>
                            <div key={"div"+i}>
                                <small>Archivo: {load.filename}</small>
                                <ProgressBar key={"PltoLdSn" + loader.avails_id
                                    + load.id} value={load.progress}></ProgressBar>
                            </div>
                        )}
                    </AccordionTab>
                )}

            </Accordion >
        </div>

    );
}
export default LoaderComponent