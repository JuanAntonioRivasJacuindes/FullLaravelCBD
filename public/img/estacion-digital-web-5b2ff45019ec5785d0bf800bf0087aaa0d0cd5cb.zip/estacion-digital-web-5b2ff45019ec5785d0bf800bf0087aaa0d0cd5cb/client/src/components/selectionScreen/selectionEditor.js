import React, { useState, useMemo } from "react";
import { useHistory } from "react-router-dom";
import { RadioButton } from "primereact/radiobutton";
import { Button } from 'primereact/button';
import styles from "./styles.module.scss";

import { getCanales } from '../../service/EstacionDigitalServices';

const types = ["Todos los bloqueos", "Bloqueos sin media", "Bloqueos completados", "Bloqueos en proceso", "Advertencia en media", "Error en procesamiento"];

const Title = ({ text }) => (
  <div className={styles.title}>
    <p>{text}</p>
  </div>
);

const SelectionEditor = ({ channel, setChannel, type, setType }) => {
  const { localStorage } = window;
  const [canales, setCanales] = useState([]);
  // se guarda role del usuario para ruteo en confirmación
  localStorage.setItem('isEditor', 'true');
  // Obtener y memorizar la lista de canales
  useMemo(() => {
    async function getData() {
      setCanales(await getCanales())
    }
    getData();
  }, []);
  // guardar id y nombre del canal seleccionado
  const handleSelectChannel = (item) => {
    setChannel(item?.id);
    localStorage.setItem('channelID', item?.id);
    localStorage.setItem('channelName', item?.name);
  };
  const history = useHistory();
  // asignar status para filtrar la lista de bloqueos acorde a la selección y redireccionar a la lista de bloqueos
  const onSubmit = () => {
    if (type === 'Todos los bloqueos') {
      localStorage.setItem('orderType', 'all');
    } else if (type === 'Bloqueos sin media') {
      localStorage.setItem('orderType', 0);
    } else if (type === 'Bloqueos en proceso') {
      localStorage.setItem('orderType', 1);
    } else if (type === 'Advertencia en media') {
      localStorage.setItem('orderType', 2);
    } else if (type === 'Bloqueos completados') {
      localStorage.setItem('orderType', 3);
    } else if (type === 'Error en procesamiento') {
      localStorage.setItem('orderType', 4);
    }
    history.push('/schedule-editor');
  };
  // obligar a usuario a ingresar los valores requeridos para avanzar
  const isDisabled = type === '' || channel === '';
  return (
    <div className={styles.container}>
      <header className={styles.header}>
        <h3>ORDENES DE BLOQUEO</h3>
      </header>
      <form className={styles.form}>
        <div className={styles.selection}>
          <Title text="Seleccionar canal" />
          {canales?.map((item, key) => (
            <label key={key}>
              <RadioButton name="channel" value={item?.id} onChange={() => handleSelectChannel(item)} checked={channel === item?.id} required />
              <span>{item?.name}</span>
            </label>
          ))}
        </div>
        <div className={styles.selection}>
          <Title text="Seleccionar tipo" />
          {types?.map((item, key) => (
            <label key={key}>
              <RadioButton name="type" value={item} onChange={(e) => setType(e.value)} checked={type === item} required />
              <span>{item}</span>
            </label>
          ))}
        </div>
        <div className={styles.button}>
          <Button label="Ver Bloqueos" disabled={isDisabled} onClick={onSubmit} />
        </div>
      </form>
    </div>
  );
};

export default SelectionEditor;
