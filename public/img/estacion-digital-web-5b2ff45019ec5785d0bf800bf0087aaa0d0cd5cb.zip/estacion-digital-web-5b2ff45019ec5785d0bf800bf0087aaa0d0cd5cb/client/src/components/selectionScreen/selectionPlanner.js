import React, { useState, useMemo } from "react";
import { useHistory } from "react-router-dom";
import { RadioButton } from "primereact/radiobutton";
import { Calendar } from "primereact/calendar";
import { addLocale } from 'primereact/api';
import { Button } from 'primereact/button';
import styles from "./styles.module.scss";

import { getCanales } from '../../service/EstacionDigitalServices';

const Title = ({ text }) => (
  <div className={styles.title}>
    <p>{text}</p>
  </div>
);

const SelectionPlanner = ({ channel, setChannel, day, setDay }) => {
  const { localStorage } = window;
  const [canales, setCanales] = useState([]);
  // se guarda role del usuario para ruteo en confirmación
  localStorage.setItem('isEditor', 'false')
  // Obtener y memorizar la lista de canales
  useMemo(() => {
    async function getData() {
      setCanales(await getCanales())
    }
    getData();
  }, []);

  // dar el formato necesario a la fecha seleccionada
  const dateFormat = {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  };
  const formatDateValue = (value) => {
    const date = new Intl.DateTimeFormat('es-MX', dateFormat).format(value);
    return date;
  };
  // guardar id y nombre del canal seleccionado
  const handleSelectChannel = (item) => {
    setChannel(item?.id);
    localStorage.setItem('channelID', item?.id);
    localStorage.setItem('channelName', item?.name);
  };
  // guardar fecha seleccionada con el formato necesario
  const handleSelectDate = (value) => {
    setDay(formatDateValue(value));
    localStorage.setItem('selectedDate', formatDateValue(value));
  };
  // RESTRICCIÓN DE SELECCIÓN DE FECHA (comentado para propósitos de prueba)
  // let today = new Date()
  // let tomorrow = new Date(today);
  // tomorrow.setDate(today.getDate() + 1)
  // let lastDay = new Date(tomorrow);
  // lastDay.setDate(tomorrow.getDate() + 6)
  // const minDate = tomorrow;
  // const maxDate = lastDay;

  // agregar idioma español al componente de calendario
  addLocale('es', {
    firstDayOfWeek: 1,
    dayNames: ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'],
    dayNamesShort: ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'],
    dayNamesMin: ['D', 'L', 'M', 'X', 'J', 'V', 'S'],
    monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
    monthNamesShort: ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'],
    today: 'Hoy',
    clear: 'Limpiar'
  });
  // Obligar al usuario a seleccionar los valores necesarios para avanzar
  const isDisabled = day === '' || channel === '';
  // redireccionar a la carta de programación
  const history = useHistory();
  const onSubmit = () => {
    history.push('/schedule');
  };
  console.log(canales);
  return (
    <div className={styles.container}>
      <header className={styles.header}>
        <h3>CARTA DE PROGRAMACIÓN</h3>
      </header>
      <form className={styles.form}>
        <div className={styles.selection}>
          <Title text="Seleccionar canal" />
          {canales?.map((item, key) => (
            <label key={key}>
              <RadioButton name="channel" value={item?.id} onChange={() => handleSelectChannel(item)} checked={channel === item?.id} required />
              <span>{item?.name}</span>
            </label>
          ))}
        </div>
        <div className={styles.selection}>
          <Title text="Seleccionar fecha" />
          {/* // Calendario con restricción de fecha habilitada
            <Calendar dateFormat="dd/mm/yy" minDate={minDate} maxDate={maxDate} onChange={e => setDay(e.value)} locale="es" showIcon required />
          */}
          <Calendar dateFormat="dd/mm/yy" onChange={e => handleSelectDate(e.value)} locale="es" showIcon required />
        </div>
        <div className={styles.button}>
          <Button label="Ver/Editar" disabled={isDisabled} onClick={onSubmit} />
        </div>
      </form>
    </div>
  );
};

export default SelectionPlanner;
