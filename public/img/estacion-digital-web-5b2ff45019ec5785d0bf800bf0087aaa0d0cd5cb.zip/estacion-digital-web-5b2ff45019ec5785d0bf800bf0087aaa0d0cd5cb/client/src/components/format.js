export class FormatService {

  formatTime = (time) => {
    //formarting duration of video
    if (isNaN(time)) { return "00:00:00"; }
    const date = new Date(time * 1000);
    const hours = date.getUTCHours().toString().padStart(2, "00");
    const minutes = date.getUTCMinutes().toString().padStart(2, "00");
    const seconds = date.getUTCSeconds().toString().padStart(2, "00");
    const pviFrames = Math.round(((date.getMilliseconds()).toString().padStart(3, "000")*30)/1000).toString().padStart(2, "00");
     return `${hours}:${minutes}:${seconds};${pviFrames}`;
  };

  formatSec = (time) => {
    //formarting duration of video
    const splitString = time.split(":");
    let horas=splitString[0];
    let minutos=splitString[1];
    let s = splitString[2].split(";");
    let sec = Math.round(s[0]);
    let mSec = Math.round(((s[1]).toString().padStart(3, "000")*1000)/30).toString().padStart(3, "000");
    let totalSeg = (horas*3600)+(minutos*60)+(sec);

    return `${totalSeg}.${mSec}`;
  }
  
  formatTimeMediaStream = (time) => { 
    //formarting duration of video 
    if (isNaN(time)) { return "00:00:00"; } 
    const date = new Date(time * 1000); 
    const hours = date.getUTCHours().toString().padStart(2, "00"); 
    const minutes = date.getUTCMinutes().toString().padStart(2, "00"); 
    const seconds = date.getUTCSeconds().toString().padStart(2, "00"); 
     return `${hours}:${minutes}:${seconds}`; 
  };
}


  
