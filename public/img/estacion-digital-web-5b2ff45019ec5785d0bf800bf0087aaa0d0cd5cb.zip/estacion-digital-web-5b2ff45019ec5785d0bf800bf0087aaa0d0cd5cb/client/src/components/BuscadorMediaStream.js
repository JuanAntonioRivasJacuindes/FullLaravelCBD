 
import React, { useState, useEffect, useRef } from 'react';
import Axios from "axios";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { FormatService } from "./format";

import { Fieldset } from 'primereact/fieldset';

const BuscadorMediaStream = (props) => {
    const { localStorage } = window;

    const toSeconds = (time) => {
        if(time){

            const timeArray = time.split(":")
            return (parseInt(timeArray[0]) * 3600) + (parseInt(timeArray[1]) * 60) + (parseInt(timeArray[2]))
        }
    }


    let parameters = {
        'titulo': '',
        'minDuration': '',
        'maxDuration': ''
    }

    let min = 0;
    let max = 0;

    const formato = [
        { name: 'Segundos', code: 's' },
        { name: 'Minutos', code: 'm' },
        { name: 'Horas', code: 'h' },
    ];

    const [videos, setVideos] = useState([]);
    const [selectedVideos, setSelectedVideos] = useState([]);
    const [search, setSearch] = useState(parameters);
    const [formatos, setFormatos] = useState('s');
    const [minDuration, setMinDuration] = useState(toSeconds(localStorage.getItem('orderMinDuration')));
    const [maxDuration, setMAxDuration] = useState(toSeconds(localStorage.getItem('orderMaxDuration')));
    const formatService = new FormatService();

    const onSelectionChange = (event) => {
        setSelectedVideos(event.value);

        props.passData(event.value);
     
    }

    const thumbBodyTemplate = (rowData) => {

        if (rowData['preview']) {
            return (
                <div className='w-10 p-0 m-0'>

                    {/* <Image  width="80" height="60"  src={rowData['thumbnails'][0]['url']} alt="Image Text" /> */}
                    <video 
                    onMouseOver={(e) => { e.target.play() }} 
                    onMouseOut={(e) => { e.target.pause() }} 
                    className='p-0 m-0' width={300} src={rowData['preview']['mp4']}></video>

                    {/* <Image  width="80" height="60"  src={rowData['thumbnails'][0]['url']} alt="Image Text" /> */}
                </div>
            )

        }
        else {
            return (
                <div className='w-12  p-0 m-0'>
                    {/* <Image  width="80" height="60"  src={rowData['thumbnails'][0]['url']} alt="Image Text" /> */}
                    <p>No preview</p>
                    {/* <Image  width="80" height="60"  src={rowData['thumbnails'][0]['url']} alt="Image Text" /> */}
                </div>
            )
        }


    }

    const infoTemplate = (rowData) => {

        return (
            <div className="field">
              
                <b><strong>{rowData.title}</strong></b>  <br />
                <b><strong>Duración: </strong></b>  <label>{formatService.formatTimeMediaStream(rowData.duration)}</label><br />
                <b><strong>Descripción: </strong></b>  <label>{rowData.description} segundos.</label>
            </div>
        )

    }

    const onInputChange = (e, name) => {
        const val = (e.target && e.target.value) || '';
        let _parameter = { ...search };
        _parameter[`${name}`] = val;
        setSearch(_parameter);
    }

    const buscarMedia = async (e) => {
        if (e === 'Enter') {
            //Valida el formato que se eligio s,m,h      
            min = minDuration
            max = maxDuration
    
            if (formatos.code === 'm') {
                if ((minDuration) * 60 === 0) {
                    setMinDuration('')
                } else {
                    min = minDuration * 60;
                }
                if ((maxDuration) * 60 === 0) {
                    setMAxDuration('')
                } else {
                    max = maxDuration * 60;
                }
      
            }
            else if (formatos.code === 'h') {
                if ((minDuration) * 3600 === 0) {
                    setMinDuration('')
                } else {
                    min = minDuration * 3600;
                
                }
                if ((maxDuration) * 3600 === 0) {
                    setMAxDuration('')
                } else {
                    max = maxDuration * 3600;
            
                }
              
            }
            Axios({
                url: "https://platform.mediastre.am/api/media?status=OK&all=true&sort=-date_created&limit=12&skip=0&query=" + search.titulo + "&without_category=false&title-rule=contains&published=&min_duration=" + min + "&max_duration=" + max + "&tags-rule=in_any&categories-rule=in_any&lite=true&include_images=false",
                //url: "https://platform.mediastre.am/api/media?status=OK&all=true&sort=-date_created&limit=12&skip=0&query="+titulo,
                headers: {
                    'X-API-Token': 'e9cf05fa95d03fa9665643a9ca98dae1'
                }
            })
                .then((response) => {
                  
                    setVideos(response.data.data);
                })
                .catch((error) => {
                    console.log(error);
                });
        }
    }

    const onFormatChange = (e) => {
        setFormatos(e.value);
    }

    return (
        <div>
            <span className="p-input-icon-left flex">
                <i className="pi pi-search" />
                <InputText id="search" className='w-full' onKeyPress={(e) => buscarMedia(e.key)} placeholder="Buscar..." onChange={(e) => onInputChange(e, 'titulo')} />
            <Button icon="pi pi-search" onClick={() => (buscarMedia('Enter'))} className="p-button-success" /><br /><br />
            </span>

            <Fieldset legend="Busqueda Avanzada" collapsed={true} toggleable>
                
            <Dropdown value={formatos} options={formato} onChange={onFormatChange} optionLabel="name" placeholder="Segundos" />
            <InputText value={minDuration} type="number" style={{ marginLeft: "13px", marginRight: "13px", width: "80px" }} id="minDuration" placeholder="Min" onChange={(e) => setMinDuration(e.target.value)} />
            <InputText value={maxDuration} type="number" style={{ marginLeft: "4px", marginRight: "13px", width: "80px" }} id="maxDuration" placeholder="Max" onChange={(e) => setMAxDuration(e.target.value)} />
            </Fieldset>

            <DataTable value={videos} filterDisplay="row" emptyMessage="Nada que mostrar" responsiveLayout="scroll" paginator rows={10} selection={selectedVideos} onSelectionChange={onSelectionChange}>
                <Column selectionMode="single"></Column>
                <Column body={thumbBodyTemplate} onMouseOver={thumbBodyTemplate}></Column>
                <Column body={infoTemplate} ></Column>
            </DataTable>
        </div>
    );
}

export default BuscadorMediaStream
