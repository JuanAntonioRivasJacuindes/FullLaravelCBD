import React, { Fragment } from 'react';
import axios from 'axios';
import https from 'https';
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; 

class FileIUpload extends React.Component {

    state = {
        selectedFile: null
    }


    handleImage = (e) => {
        this.setState({
            selectedFile: e.target.files[0]
        })
    }







    handleSubmit = (e) => {
        e.preventDefault();
        // console.log('posted ', this.state.selectedFile);
        let formData = new FormData();
        formData.append('file', this.state.selectedFile)

        let url = 'https://10.64.17.97/vidig-s3/upload';   
        axios.put(url, 
            formData ,{
            headers: {
                "Access-Control-Allow-Origin":"*",
            },
            responseType: 'json',
            httpsAgent: new https.Agent({ rejectUnauthorized: false })
        })
            .then(function (response) { console.log(response) })
    }
    // const instance = axios.create({
    //     httpsAgent: new https.Agent({  
    //       rejectUnauthorized: false
    //     })
    //   });   
    // instance.post(url, {
    //     headers: {
    //         'Content-Type': 'multipart/form-data',
    //     }
    // })
    




render() {
    return (
        <Fragment>
            
            <form>

                <input name='photo' type="file" onChange={e => this.handleImage(e)} />
                <button onClick={e => this.handleSubmit(e)}>Crea</button>
            </form>
        </Fragment>
    )
}
}
export default FileIUpload