import React, { useState, useEffect, useRef } from 'react';
import Axios from "axios";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';

const TxtGenerator = (vars) => {

    const [videos, setVideos] = useState([]);
    const [selectedVideos, setSelectedVideos] = useState([]);
    const dt = useRef(null);
    const [buttonDisable, setButtonDisable] = useState(true)
    const cols = [
        { field: 'programa', header: 'Programa' },
        { field: 'episode_name', header: 'Titulo del Episodio' },
        { field: 'episode_number', header: 'Número de Episodio' },
        { field: 'season_number', header: 'Temporada' },
        { field: 'duration', header: 'Duración' },
        { field: 'id_video', header: 'Id Video' },
    ];

    const headers = ['duration', 'episode_title', 'episode_number', 'code', 'series_title', 'season_number'];
    const exportColumns = cols.map(col => ({ title: col.header, dataKey: col.field }));


    const onSelectionChange = (event) => {
        const value = event.value;
        setSelectedVideos(value);

        if (event.value.length === 0) {
            setButtonDisable(true)
        } else {
            setButtonDisable(false)

        }
    }


    const exportCSV = (selectionOnly) => {

        var data = selectedVideos;
        var csvContent = "data:text/csv;charset=utf-8,";;
        csvContent += headers.join(",") + "\n";

        data.forEach(function (index) {
            index = Object.values(index)
           
            const dataString = index.join(",");
            csvContent += dataString + "\n";
        }); 


        var encodedUri = encodeURI(csvContent);
        var link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "generated.csv");
        document.body.appendChild(link);

        link.click();
 
    }

    useEffect(() => {
        Axios({
            url: "https://10.126.65.29/vidig-s3-gate/episode/txt",
        })
            .then((response) => {
             
                setVideos(response.data);
            })
            .catch((error) => {
                console.log(error);
            });
    }, [setVideos]);


    return (
        <div>
            <Button disabled={buttonDisable} label="Generar TXT" type="button" icon="pi pi-file" onClick={() => exportCSV()} className="fixed z-1 bottom-0 mb-5 mr-6 right-0" data-pr-tooltip="CSV" />
            <DataTable ref={dt} value={videos} filterDisplay="row" responsiveLayout="scroll"
                paginator rows={10} rowsPerPageOptions={[5, 10, 25]}
                selection={selectedVideos} onSelectionChange={onSelectionChange}   >
                <Column selectionMode="multiple" headerStyle={{ width: '3em' }}></Column>
                {cols.map(col => (<Column sortable key={col.field} field={col.field} header={col.header}  ></Column>))}
            </DataTable>

        </div>
    );
}

export default TxtGenerator
