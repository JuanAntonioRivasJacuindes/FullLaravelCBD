
import React, { useState, useEffect, useRef } from 'react';
import { ProgressBar } from 'primereact/progressbar';
import axios from "axios";
import https from 'https';

const LoadMonitor = (vars) => {
    const [value1, setValue1] = useState(0);
    const [filename, setfilename] = useState("Cargando...");
    const interval = useRef(null);
    useEffect(() => {
        let val =0;
        let filename ="";
        const httpsAgent = new https.Agent({
            rejectUnauthorized: false, // (NOTE: this will disable client verification)
          })
              
        interval.current = setInterval(() => {
                 axios
            .get(vars.baseUrl+"/loaders/"+vars.avails_id+"/"+vars.index_id, httpsAgent)
            .then(res => {
                val = res.data.progress;
                filename = res.data.filename;
                setValue1( val );
                setfilename( filename )
            })
            .catch(console.log);
            if (val >= 100) {
                val = 100;
                // toast.current.show({ severity: 'success', summary: 'Carga Terminada', detail: 'Archivo: '+filename });
                clearInterval(interval.current);
            }

            setValue1(val);
        }, 5000);
        return () => {
            if (interval.current) {
                clearInterval(interval.current);
                interval.current = null;
            }
        }
    }, []);

    return (
        <div>
            {/* <Toast ref={toast}></Toast> */}
                <span className='col-sm'>{filename}</span>
                <ProgressBar  className='col-sm' value={value1}></ProgressBar>              

          
        </div>
    );
}

export default LoadMonitor