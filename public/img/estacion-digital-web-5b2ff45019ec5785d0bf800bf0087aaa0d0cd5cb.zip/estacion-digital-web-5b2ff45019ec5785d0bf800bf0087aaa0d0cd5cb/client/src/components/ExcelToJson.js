import React, { useState, useEffect, useRef } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { FileUpload } from 'primereact/fileupload';
import axios from "axios";
import readXlsxFile from 'read-excel-file';


const ExcelToJson = () => {

    const uploadOptions = { label: 'Uplaod', icon: 'pi pi-upload', className: 'p-button-success' };
    const toast = useRef(null);
    const [order, setOrder] = useState([])
    const [mediaOrderId, setMediaOrderId] = useState("undefined")
    const [dynamicColumns, setDynamicColumns] = useState()
    const [selectedFile, setSelectedFile] = useState(null)
    const dictionary = ["partner_due_date_to_lab", "lab_due_date_to_pluto", "status", "pluto_avails_id", "series_title", "episode_title", "season_number", "episode_number", "duration_mo", "hd_sd", "rating", "genre", "sub_genre", "category", "sub_category", "linear_start", "linear_end", "linear_play_limits", "avod_start", "avod_end", "avod_play_limits", "undefined", "territories_include", "territories_exclude", "language", "captions_required", "associated_channel_name", "associated_channel_id", "undefined", "undefined", "undefined", "undefined", "undefined", "undefined", "approved_devices", "undefined", "undefined", "region", "service_tier", "cc_service", "artwork_screenshots", "other", "partner_code", "metadata"]
    function send() {
        console.log("enviando")
        console.log(order)
    }

    function insert() {
        axios.post('https://10.126.65.29/vidig-s3-gate/media-order', order)
            .then(function (response) {
                console.log(response);
                toast.current.show({ severity: 'success', summary: 'Exito!', detail: "se insertaron " + response.data.inserted + " registros en la base de datos", life: 5000 });
                //alert("se insertaron "+ response.data.inserted+" registros en la base de datos")
                //toast.current.show({severity: 'success', summary: 'Success Message', detail: 'Order submitted'});
            })
            .catch(function (error) {
                console.log(error);
            });
    }

    useEffect(() => {

        let index = [4, 5, 3, 0, 1, 2, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 22, 23, 24, 25, 26, 27, 34, 37, 38, 39, 40, 41, 42, 43]
        if (selectedFile != null) {
            let data = []
            readXlsxFile(selectedFile).then(function (rows) {
                setMediaOrderId(rows[1][4])

                let header_index = 0
                let rows_length = rows.length
                let valid = false
                for (var i = 0; i < rows.length; i++) {

                    if (rows[i][0] === "Partner Due Date to Lab") {
                        header_index = i;
                        valid = true
                        break
                    }
                }
                if (valid) {
                    let data_first_row = header_index + 1;
                    let data_last_row = rows_length - 1
                    for (let i = data_first_row; i <= data_last_row; i++) {
                        var aux = {};
                        for (let j = 0; j < index.length; j++) {
                            if (rows[i][index[j]]) {

                                aux[dictionary[index[j]]] = String(rows[i][index[j]])
                            }

                        }
                        data.push(aux)
                    }

                    setOrder(data)
                    console.log(order)
                    setDynamicColumns(index.map((col) => {

                        return <Column className='p-10' key={dictionary[col]} field={dictionary[col]} header={dictionary[col]} />;
                    }))




                } else {
                    toast.current.show({ severity: 'error', summary: 'Error!', detail: 'Ha ocurrido un error, intentalo mas tarde.', life: 5000 });

                }
            })
        }


    }, [selectedFile]); // eslint-disable-line react-hooks/exhaustive-deps


    function changeHandler(event) {
        setSelectedFile(event.files[0])
    }
    return (
        <div>
            <Toast ref={toast} />
            <div>
                <div className="card">

                    <div>
                        <div className="flex">
                           
                                <FileUpload className='m-1'  uploadHandler={send}  name="file" url="./upload" chooseLabel="Seleccionar" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" mode="basic" onSelect={changeHandler} />
                                <Button  className='m-1' onClick={insert} label="Cargar" />
                            
                        </div>
                        <h5>Media Order Id : {mediaOrderId}</h5>

                    </div>


                    <div>
                        <DataTable value={order} responsiveLayout="scroll" >
                            {dynamicColumns}
                        </DataTable>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default React.memo(ExcelToJson)