import React, { useState, useEffect, useRef } from 'react';
import Axios from "axios";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';

const TxtGenerator = (vars) => {

    useEffect(() => {
        Axios({
            url: "https://10.126.65.29/vidig-vod/JsonList",})
            .then((response) => {
                 console.log(response.data)
                 setVideos(response.data);
            })
            .catch((error) => {
                console.log(error);
            });
    }, [setVideos]);

    const [videos, setVideos] = useState([]);
    const [selectedVideos, setSelectedVideos] = useState([]);
    const dt = useRef(null);
    const cols = [
                    { field: 'id_programa', header: 'Id Programa' },
                    { field: 'nombre_programa', header: 'Nombre del Programa' },
                    { field: 'num_episodios', header: 'Número de Episodios' }
                 ];

    const headers = ['id_programa','nombre_programa','num_episodios'];
    const exportColumns = cols.map(col => ({ title: col.header, dataKey: col.field }));


    const onSelectionChange = (event) => {
        const value = event.value;
        //console.log(value);
        setSelectedVideos(value);
    }


    const exportCSV = async (selectionOnly) => {
       
        var data = selectedVideos;
        // console.log(selectedVideos)
        let prg_id=data[0].id_programa;
        let nombre=data[0].nombre_programa;

        //se manda peticion de Axios para generar JSON
        const json = await Axios.get('https://10.126.65.29/vidig-s3-gate/programs?prg_id=' + prg_id);

        let json_file=JSON.stringify(json["data"]);

        const a = document.createElement("a");
        const archivo = new Blob([json_file], { type: '.json' });
        const url = URL.createObjectURL(archivo);
        a.href = url;
        a.download = nombre+".json";
        a.click();
        URL.revokeObjectURL(url);

    }

    


    return (
       <div>
            <Button type="button" label="Generar Json y subir archivos al S3" icon="pi pi-file" onClick={() => exportCSV()} className="p-button-success" data-pr-tooltip="CSV" /><br/><br/>
            <DataTable ref={dt} value={videos}  filterDisplay="row" responsiveLayout="scroll" paginator rows={10} selection={selectedVideos} onSelectionChange={onSelectionChange}>
                <Column selectionMode="multiple" headerStyle={{ width: '3em' }}></Column>
                {cols.map(col => (<Column key={col.field} field={col.field} header={col.header}></Column>))}
            </DataTable>
        </div>
    );
}

export default TxtGenerator
