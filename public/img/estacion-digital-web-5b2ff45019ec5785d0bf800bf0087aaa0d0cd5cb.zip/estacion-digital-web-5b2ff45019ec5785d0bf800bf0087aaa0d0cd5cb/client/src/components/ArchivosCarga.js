import React, { useState, useEffect, useRef } from 'react';
import axios from "axios";
import https from 'https';
import { Panel } from 'primereact/panel';
import { Button } from 'primereact/button';
import { Accordion, AccordionTab } from 'primereact/accordion';
import { Toast } from 'primereact/toast';

const ArchivosCarga = (vars) => {
    const toast = useRef(null);
    const [archivos, setArchivos] = useState([]);
    const [activeIndex, setActiveIndex] = useState();
    const baseUrl = "https://10.126.65.29/vidig-vod/MediaToUploadList";

    useEffect(() => {
        const httpsAgent = new https.Agent({
            rejectUnauthorized: false, // (NOTE: this will disable client verification)
        })
        axios
            .get(baseUrl, httpsAgent)
            .then(res => {

                if (res.data) {

                    setArchivos(res.data)
                } else {
                    console.log("no data")
                }

            })
            .catch(console.log);
    }, [])

    const exportCSV = async (prg_id, nombre) => {

        //console.log("Clickeaste el boton: " + prg_id );
        //se manda peticion de Axios para generar JSON
        const getjson = await axios.get('https://10.126.65.29/vidig-s3-gate/program/' + prg_id + "/upload");

        let json_file = JSON.stringify(getjson["data"]);

        const regi = getjson['data']['data'][0];
        if (regi['episodes'] !== "error" || regi['episodes'] !== "error") {
            const a = document.createElement("a");
            const archivo = new Blob([json_file], { type: '.json' });
            const url = URL.createObjectURL(archivo);
            a.href = url;
            a.download = nombre + ".json";
            a.click();
            URL.revokeObjectURL(url);
            toast.current.show({ severity: 'success', summary: 'Hecho', detail: 'Se generó exitosamente' });
            console.log(prg_id)
            var bodyFormData = new FormData();
            bodyFormData.append("avails_id", prg_id);

            axios({
                method: "post",
                url: 'https://10.126.65.29/vidig-s3-gate/loader' ,
                data: bodyFormData,
                headers: { "Content-Type": "multipart/form-data" }
            })
                .then((response) => {
                    
                    console.log(response.data)
                    toast.current.show({ severity: 'success', summary: 'Hecho', detail: response.data['message'] });
                })
                .catch(function (error) {
                    console.log(error);
                });

        } else {
            toast.current.show({ severity: 'error', summary: 'Error', detail: 'Falta información' });
        }

    }

    return (
        <div>
            <Toast ref={toast} />
            <Panel header="Archivos para subir a S3">
                <Accordion activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
                    {Object.keys(archivos).map((key, i) =>
                        <AccordionTab key={key} header={key} >
                            {archivos[key].map((key2, i2) =>
                                <div key={key2["nombre_video"]} className="card">
                                    <b><strong>Episodio:   <label>{key2["episode_name"]}</label></strong></b><br />
                                    <label>---------------------------------------------------------------------------------</label><br />
                                    <b>Nombre del Video:</b>  <label>{key2["nombre_video"]}</label><br />
                                    <b>Poster:</b>  <label>{key2["poster"]}</label><br />
                                    <b>Featured Image:</b>  <label>{key2["featured_image"]}</label><br />
                                    <b>Tile:</b>  <label>{key2["tile"]}</label><br />
                                    <b>Screenshot 16_9:</b><label>{key2["screenshot16_9"]}</label><br />
                                    <b>Screenshot 4_3:</b><label>{key2["screenshot4_3"]}</label><br />
                                </div>
                            )}
                            <Button icon={<i className="pi pi-cloud-upload" style={{ 'fontSize': '2em' }}></i>} label={"Generar JSON y subir a S3"} style={{ height: '40px', width: '270px' }} className="p-button-success" key={"btn"} onClick={(e) => exportCSV((archivos[key][0]["id_programa"]), archivos[key][0]["nombre_programa"])}></Button>
                        </AccordionTab>
                    )}
                </Accordion>
            </Panel>
        </div>
    );

}
export default ArchivosCarga