
import React, { useState ,forwardRef,useImperativeHandle} from 'react';
import OrderDetail from '../media/orderDetail';
import AssignMedia from '../media/assignMedia';
import { TabView, TabPanel } from 'primereact/tabview';

import styles from './BlockOrder.module.css';
 
const BlockOrderComponent = forwardRef((vars,ref) => {
    const selectedOrder = vars.order
    const { localStorage } = window;
    const [activeIndex, setActiveIndex] = useState(vars.activeIndex);
    const [verificationTab,setVerificationTab]=useState()
    const [confirmationTab,setConfirmationTab]=useState()
    useImperativeHandle(ref, () => ({
        next(varss) {
       
            setActiveIndex(varss)
       
        }
      }))

    const callback =(index)=>{
        setActiveIndex(index)
    }


    const next = () => {
        setActiveIndex(activeIndex + 1)
    }

    const handleTabChange =(e)=>{
        setActiveIndex(e)
        vars.callback()
    }
    return (
        <div>
           
            <TabView className={styles.tab} activeIndex={activeIndex} onTabChange={(e) => handleTabChange(e.index)}>
                <TabPanel className="w-full" disabled={true}>
                    <OrderDetail callback={callback} changeButtonStatus={vars.changeButtonStatus} orderId={selectedOrder} />
                  
                </TabPanel>
                <TabPanel className="w-full"  disabled={true}>
                    <AssignMedia updateOrderSuccess={vars.updateOrderSuccess} setConfirmationTab={setConfirmationTab} setVerificationTab={setVerificationTab} changeButtonStatus={vars.changeButtonStatus} orderId={selectedOrder} />
                 
                </TabPanel>
                <TabPanel  className="w-full" disabled={true}>
                    {verificationTab}
                </TabPanel>
                <TabPanel  className="w-full" disabled={true}>
                    {confirmationTab}
                </TabPanel>
            </TabView>
        </div>
    );
})

export default BlockOrderComponent