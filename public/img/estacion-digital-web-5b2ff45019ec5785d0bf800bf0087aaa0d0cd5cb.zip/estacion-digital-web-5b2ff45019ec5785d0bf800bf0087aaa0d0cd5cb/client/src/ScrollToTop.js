import { useEffect } from 'react';
import { useLocation, withRouter } from 'react-router-dom';

const ScrollToTop = (props) => {

  let location = useLocation();
  const { localStorage } = window;
  // obtener el la posición de scroll guardada y convertirla en número
  const scrollPosition = parseFloat(localStorage.getItem('scrollPosition'));
  // detectar si la posición de scroll guardada es válida y diferente a cero
  // eslint-disable-next-line use-isnan
  const verticalScroll = scrollPosition !== NaN && scrollPosition !== 0 ? scrollPosition : 0;
  useEffect(() => {
    if (verticalScroll !== 0) {
      setTimeout(() => {
        window.scrollTo(0, verticalScroll);
      }, 1000);
    } else {
      window.scrollTo(0, 0);
    }
  }, [location, verticalScroll]);

  return props.children;
}

export default withRouter(ScrollToTop);
