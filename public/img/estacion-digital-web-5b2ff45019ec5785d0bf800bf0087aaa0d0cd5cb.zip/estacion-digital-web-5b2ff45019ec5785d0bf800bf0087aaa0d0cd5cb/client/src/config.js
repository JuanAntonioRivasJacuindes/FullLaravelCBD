module.exports = {
    secret: 'r3G4yr3C5apCeLd4rUdO14m4rz0@05',
    algorithms : 'HS256',
}

module.exports.getAgent = () => {
    let agent = navigator.userAgent
    return agent;
}
