import jwt from "jwt-simple";
import config from "./config";

export const getEncript = (data) => {
  let result = jwt.encode(data, config.secret, config.algorithms);
  try {
    //console.log(result);
    return result;
  } catch (error) {
    //console.log(error);
    return error
  }
};

export const getDencript = (data) => {
  let result = jwt.decode(data, config.secret, config.secret);
  try {
    //console.log(result);
    return result;
  } catch (error) {
    //console.log(error);
    return error
  }
};
