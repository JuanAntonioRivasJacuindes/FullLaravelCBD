import * as path2 from 'path';
import { fileURLToPath } from 'url';
import express from 'express'
import session from 'express-session'
import passport from 'passport'
import https from 'https'
import fs from 'fs'
import  { Strategy } from 'passport-saml';
import dotenv from "dotenv"

dotenv.config()
const config = {
    saml: {
        cert: process.env.CERT,
        entryPoint: process.env.ENTRYPOINT,
        issuer: process.env.ISSUER,
        decryptionPvk: process.env.DECRYPTIONPVK,
        options: {
            failureRedirect: process.env.FAILURE_REDIRECT,
            failureFlash: true
        }
    },
    server: {
        port: process.env.PORT|| 443,
        client_uri: process.env.CLIENT_URI,
        transport_cert: process.env.TRANSPORT_CERT
    },
    session: {
        resave: false,
        secret: process.env.TOKEN,
        saveUninitialized: true
    }
}
const savedUsers = [];
passport.serializeUser((expressUser, done) => {
    done(null, expressUser);
});
passport.deserializeUser((expressUser, done) => {
    done(null, expressUser);
});

passport.use(
    new Strategy(
        {
            issuer: config.saml.issuer,
            callbackUrl: '/login/callback',
            path: '/login/callback',
            entryPoint: config.saml.entryPoint,
            cert: fs.readFileSync(config.saml.cert, 'utf-8'),
            decryptionPvk: fs.readFileSync(config.saml.decryptionPvk, 'utf-8')
        },
        (expressUser, done) => {

            if (!savedUsers.includes(expressUser)) {
                savedUsers.push(expressUser);
            }

            return done(null, expressUser);
        }
    )
);

const __filename = fileURLToPath(import.meta.url);

const __dirname = path2.dirname(__filename);

const PORT = process.env.PORT || 443;

const app = express();

app.use(session(config.session));
app.use(passport.initialize());
app.use(passport.session());
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', req.header('origin'));
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Allow-Credentials', 'true');

    if (req.method == 'OPTIONS') {
        res.header('Access-Control-Allow-Methods', 'POST,GET');
        return res.status(200).json({});
    }

    next();
});

app.use(express.static(path2.join(__dirname, '../build')));

app.get("/api", (req, res) => {
    res.json({ message:[ process.env.SSL_CERT,process.env.DECRYPTIONPVK,process.env.TRANSPORT_CERT,process.env.ENTRYPOINT,process.env.TOKEN] });
});

app.get('/login', passport.authenticate('saml', config.saml.options), (req, res, next) => {
    return res.redirect('/');
});

app.post('/login/callback', passport.authenticate('saml', config.saml.options), (req, res, next) => {
    res.cookie('estacion','prueba')
    res.cookie('nombre', req.user.Nombre)
    return res.redirect('/');
});

app.get('/whoami', (req, res, next) => {
    if (!req.isAuthenticated()) {
        return res.status(401).json({
            message: 'Unauthorized'
        });
    } else {
        return res.status(200).json({ user: req.user });
    }
});

app.get('*', (req, res) => {
    res.sendFile(path2.join(__dirname, '../build', 'index.html'));
});
app.post('/', passport.authenticate('saml', config.saml.options), (req, res, next) => {

    return res.redirect('/#/');
});
https.createServer({
    cert : fs.readFileSync(config.server.transport_cert, 'utf-8'),
    key : fs.readFileSync(config.saml.decryptionPvk, 'utf-8')
}, app).listen(PORT, () => { console.log("Server started on port " + PORT) })
