# React Okta

* Add project in client folder


User : developer@gmail.com
Pass : admin2022#




.env 

```
TOKEN='53cr3t4rqu1t3ctur4'
CERT='./saml.pem'
DECRYPTIONPVK='./arquitectura.pem'
TRANSPORT_CERT='./arquitectura.crt'
ISSUER='React'
ENTRYPOINT='https://dev-64173813.okta.com/app/dev-64173813_react_1/exk5z287guGY8Ag9D5d7/sso/saml'
```

